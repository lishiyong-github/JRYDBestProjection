//
//  UIImage+Color.h
//  JXYD
//
//  Created by shiyong_li on 2017/8/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Color)
+ (UIImage *)imageWithColor:(UIColor *)color;
@end
