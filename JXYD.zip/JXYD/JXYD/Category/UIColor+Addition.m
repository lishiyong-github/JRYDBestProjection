//
//  UIColor+Addition.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "UIColor+Addition.h"

@implementation UIColor (Addition)
+ (UIColor *)mainColor
{
    return [UIColor colorWithRed:0.1725 green:0.5686 blue:0.5333 alpha:1];
}
+ (UIColor *)blueColor
{
    return [UIColor colorWithRed:0.0/255 green:146.0/255 blue:243.0/255 alpha:1.0f];
}

+ (UIColor *)headerColor
{
    return [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1];
}
@end
