//
//  UIViewController+Login.m
//  JXYD
//
//  Created by csh on 2017/8/2.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "UIViewController+Login.h"

@implementation UIViewController (Login)
/*
- (RACSignal *)loginWithUsername:(NSString *)userName password:(NSString *)password
{
    @weakify(self);
    return [RACSignal startEagerlyWithScheduler:[RACScheduler scheduler] block:^(id<RACSubscriber> subscriber) {
        NSString *url = [JXApiHelper apiLogin];
        NSString *params = [NSString stringWithFormat:@"username=%@,password=%@,supervise",userName,password];
        params = [DES encryptUseDES:params key:DESkey];
        url = [url stringByAppendingString:params];
        @strongify(self);
        [(SHNetWorkViewController *)self postUrl:url success:^(NSDictionary *json) {
            SHBaseResponseModel *response = [SHBaseResponseModel mj_objectWithKeyValues:json];
            NSLog(@"loginlogin************************************%@",json);
            if (response.success) {
                NSString *ticket = [json objectForKey:kTicket];
                ticket = [ticket stringByReplacingOccurrencesOfString:@"=" withString:@"=="];
                [UserDefaults setObject:ticket forKey:kTicket];
                [UserDefaults synchronize];
                [subscriber sendNext:@1];
            }else{
                [subscriber sendNext:@2];
            }
            [subscriber sendCompleted];
        } failed:^{
            [subscriber sendError:nil];
        }];
    }];
}*/

//- (RACSignal *)deviceLoginWithURL:(NSString *)url param:(NSDictionary *)param
//{
//    @weakify(self);
//    return [RACSignal startEagerlyWithScheduler:[RACScheduler scheduler] block:^(id<RACSubscriber> subscriber) {
////        url = [url stringByAppendingString:param];
//        @strongify(self);
//        [(SHNetWorkViewController *)self postUrl:url  param:param success:^(NSDictionary *json) {
//            @strongify(self);
//            if ([[json objectForKey:@"result"] isEqualToString:@"-1"]) {
//                
//            } else if ([[json objectForKey:@"result"] isEqualToString:@"0"]) {
//                
//            } else if ([[json objectForKey:@"result"] isEqualToString:@"1"]) {
//                return ;
//            }
//        } failed:^{
//            
//        }];
//        
//    }];
//}

@end
