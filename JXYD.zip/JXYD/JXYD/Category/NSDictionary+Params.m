//
//  NSDictionary+Params.m
//  JXYD
//
//  Created by shiyong_li on 2017/8/15.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "NSDictionary+Params.h"

@implementation NSDictionary (Params)

- (NSString *)urlEncodedString
{
    NSMutableArray *parts = [NSMutableArray array];
    for (id key in self) {
        id value = [self objectForKey: key];
        NSString *part = [NSString stringWithFormat: @"%@=%@", key, value];
        [parts addObject: part];
    }
    return [parts componentsJoinedByString: @"&"];
}
@end
