//
//  UIViewController+Login.h
//  JXYD
//
//  Created by csh on 2017/8/2.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Login)
- (RACSignal *)loginWithUsername:(NSString *)userName password:(NSString *)password;
//- (RACSignal *)deviceLoginWithURL:(NSString *)url param:(NSDictionary *)param;
@end
