//
//  NSDictionary+Params.h
//  JXYD
//
//  Created by shiyong_li on 2017/8/15.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Params)
- (NSString *)urlEncodedString;
@end
