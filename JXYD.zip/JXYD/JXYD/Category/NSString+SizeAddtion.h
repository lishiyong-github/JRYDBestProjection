//
//  NSString+SizeAddtion.h
//  nbOneMap
//
//  Created by shiyong_li on 17/4/17.
//  Copyright © 2017年 dist. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SizeAddtion)
/***************根据字号大小获取文字宽高***********************/
- (CGSize)sizeWithFont:(UIFont *)font;
- (CGSize)sizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size;
@end
