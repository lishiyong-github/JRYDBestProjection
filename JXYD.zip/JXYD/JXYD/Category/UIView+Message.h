//
//  UIView+Message.h
//  TJYD
//
//  Created by 吴定如 on 17/4/27.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Message)

/** 显示提示信息 */
+ (void)showMessage:(NSString *)message;

@end
