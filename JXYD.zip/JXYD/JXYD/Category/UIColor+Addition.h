//
//  UIColor+Addition.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Addition)
+ (UIColor *)mainColor;
+ (UIColor *)blueColor;
+ (UIColor *)headerColor;
@end
