//
//  JXTabBarController1.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTabBarController.h"
#import "RootViewController.h"
#import "MainViewController.h"
#import "NewsViewController.h"
#import "MoreViewController.h"
#import "DocDetailViewController.h"
#import "PTreeViewController.h"
#import "JXDocumentPageViewController.h"
#import "JXApprovalPageViewController.h"

#import "JXHomeViewController.h"//主页
//#import "UITabBarController+FXCustomTabBar.h"

@implementation JXTabBarController

+ (UITabBarController *)controllerWithCenterItemAndTitles {
    
    //主页——新闻公告
    JXHomeViewController *home          = [[JXHomeViewController alloc] init];
    UINavigationController *naviHome    = [[UINavigationController alloc] initWithRootViewController:home];
    home.title                        = @"主页";
    home.tabBarItem                   = [[UITabBarItem alloc] initWithTitle:@"主页"
                                                                        image:[UIImage imageNamed:@"main_normal"]
                                                                selectedImage:[UIImage imageNamed:@"main_selected"]];
    
    //审批
    JXApprovalPageViewController *approvalVC = [[JXApprovalPageViewController alloc] init];
    UINavigationController *naviApproval = [[UINavigationController alloc] initWithRootViewController:approvalVC];
    approvalVC.title = @"审批";
    approvalVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"审批"
                                                          image:[UIImage imageNamed:@"approval_normal"]
                                                  selectedImage:[UIImage imageNamed:@"approval_selected"]];
    
    //在办公文
    JXDocumentPageViewController *documentVC = [[JXDocumentPageViewController alloc] init];
    UINavigationController *naviDocment = [[UINavigationController alloc] initWithRootViewController:documentVC];
    documentVC.title = @"公文";
    documentVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"公文"
                                                          image:[UIImage imageNamed:@"document_normal"]
                                                  selectedImage:[UIImage imageNamed:@"document_selected"]];
    
    //更多
    MoreViewController *moreVC = [[MoreViewController alloc] init];
    UINavigationController *naviSetting = [[UINavigationController alloc] initWithRootViewController:moreVC];
    moreVC.title = @"更多";
    moreVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"更多"
                                                      image:[UIImage imageNamed:@"more_normal"]
                                              selectedImage:[UIImage imageNamed:@"more_selected"]];
    
    UITabBarController *tabBarController = [[UITabBarController alloc] init];
    
//    [tabBarController setViewControllers:@[naviNews, naviApproval, naviDocment, naviSetting]];
    [tabBarController setViewControllers:@[naviHome,naviApproval,naviDocment, naviSetting]];
    [tabBarController.tabBar setTintColor:[UIColor mainColor]];
    [tabBarController.tabBar setBackgroundColor:[UIColor whiteColor]];
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    //    [tabBarController fx_setupCenterItemWithImage:[UIImage imageNamed:@"add"] title:@"add"];
    
    return tabBarController;
}

@end
