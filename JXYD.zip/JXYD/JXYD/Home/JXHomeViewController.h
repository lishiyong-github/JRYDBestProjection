//
//  JXHomeViewController.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHBaseViewController.h"

@interface JXHomeViewController : SHBaseViewController

@end
