//
//  JXHomeViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXHomeViewController.h"
#import "CustomCollectionViewCell.h"
#import "JXProjectSearchViewController.h"
#import "JXProjectCountViewController.h"
#import "JXApprovalSearchViewController.h"

@interface JXHomeViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property (nonatomic,strong) UICollectionView  *collectionView;
@property (nonatomic,strong) NSArray *imageArray;
@property (nonatomic,strong) NSArray *textArray;
@end

@implementation JXHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //set title
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:[UIColor mainColor]] forBarMetrics:UIBarMetricsDefault];
    self.title                              = @"主页";
    self.imageArray                         = @[@"gwbl",@"xmsp",@"xmcx",@"gwcx",@"xmtj",@"oneMap"];
    self.textArray                          = @[@"项目审批",@"公文办理",@"项目查询",@"公文查询",@"项目统计",@"一张图"];
    
    [self configCollectionView];
    
    // Do any additional setup after loading the view.
}

- (void)configCollectionView{
    
    //添加flowLayout
    UICollectionViewFlowLayout *flowLayout  = [[UICollectionViewFlowLayout alloc] init];
//    flowLayout.minimumInteritemSpacing      = 20.0f;
//    flowLayout.minimumLineSpacing           = 20.0f;

    //添加collectionView
    _collectionView                         = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    _collectionView.backgroundColor         = [UIColor whiteColor];
    _collectionView.delegate                = self;
    _collectionView.dataSource              = self;
    [self.view addSubview:self.collectionView];
    [self.view setNeedsUpdateConstraints];
    
    //注册
    [_collectionView registerClass:[CustomCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
}

#pragma mark - UICollection delegate
#pragma UICollectionView delegate/datasource
//cell的点击事件
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
   NSLog(@"******************************************cell 点击");
    
    switch (indexPath.row) {
        case 0:
            self.tabBarController.selectedIndex = 1;
            [JXLogManager WriteLog:@"项目审批" logLevel:@1];
            break;
        case 1:
        {
            self.tabBarController.selectedIndex = 2;
            [JXLogManager WriteLog:@"公文办理" logLevel:@1];
        }
            break;
        case 2:
        {
            JXApprovalSearchViewController *controller = [[JXApprovalSearchViewController alloc] init];
            controller.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:controller animated:YES];
            [JXLogManager WriteLog:@"项目查询" logLevel:@1];
        }
            break;
        case 3:
        {
            JXProjectSearchViewController *controller = [[JXProjectSearchViewController alloc]init];
            controller.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:controller animated:YES];
            [JXLogManager WriteLog:@"公文查询" logLevel:@1];
        }
            break;
        case 4:
        {
            JXProjectCountViewController *controller = [[JXProjectCountViewController alloc] init];
            controller.hidesBottomBarWhenPushed = YES;
            controller.title = @"项目统计";
            [self.navigationController pushViewController:controller animated:YES];
            [JXLogManager WriteLog:@"项目统计" logLevel:@1];
        }
            break;
        case 5:
        {
            NSString *openID = @"jiaxingMap";
            BOOL canOpen = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:[openID stringByAppendingString:@"://"]]];
            if (canOpen) {
                NSString *userName = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
                NSString *passWord = [[NSUserDefaults standardUserDefaults] objectForKey:kPassWord];
                userName = [userName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                passWord = [passWord stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                NSString *url = [NSString stringWithFormat:@"%@://%@/%@/",openID,userName,passWord];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
            }else{
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.distmobile.win/appstore/jiaxing"]];
            }
            [JXLogManager WriteLog:@"一张图" logLevel:@1];
        }
            break;
        default:
            break;
    }
    
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.imageArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
    CustomCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        cell.backgroundImageView.image = [UIImage imageNamed:self.imageArray[indexPath.row]];
        cell.bottomLable.text = self.textArray[indexPath.row];
    return cell;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

#pragma UICollectionViewdelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(86, 100);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(20, 20, 20, 20);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 40.0f;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 150.0f;
}

//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
//    return CGSizeMake(SCREEN_WIDTH, 20);
//}
//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section{
//    return CGSizeMake(SCREEN_WIDTH, 20);
//}


#pragma mark - override
- (void)myUpdateViewConstraints
{
    [self.collectionView autoSetDimensionsToSize:CGSizeMake(700, 350)];
    [self.collectionView autoCenterInSuperview];
}

@end
