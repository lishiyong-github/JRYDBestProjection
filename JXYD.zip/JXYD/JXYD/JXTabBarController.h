//
//  JXTabBarController1.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>
@class UITabBarController;

@interface JXTabBarController : NSObject
+ (UITabBarController *)controllerWithCenterItemAndTitles;
+ (UITabBarController *)controllerWithCenterItemAndNoTitle;
+ (UITabBarController *)controllerWithCenterItemAndNoTitles;
@end
