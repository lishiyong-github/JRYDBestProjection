//
//  JXEmptyView.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/13.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXEmptyView.h"

@interface JXEmptyView ()
@property (nonatomic,strong) UIImageView *imageView;
@end
@implementation JXEmptyView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.imageView];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void)myUpdateViewConstraints
{
    [self.imageView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
}

- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [UIImageView newAutoLayoutView];
        [_imageView setImage:[UIImage imageNamed:@"empty_data"]];
    }
    return _imageView;
}

@end
