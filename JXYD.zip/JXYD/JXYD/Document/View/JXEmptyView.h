//
//  JXEmptyView.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/13.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXEmptyView : UIView

@end
