//
//  JXReadModel.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JXProjectProtocol.h"
@interface JXReadModel : NSObject<JXProjectProtocol>
@property (nonatomic,strong) NSString *bh;
@property (nonatomic,strong) NSString *forwardId;
@property (nonatomic,strong) NSString *forwardItemId;
@property (nonatomic,strong) NSString *gwlx;
@property (nonatomic,strong) NSString *mc;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *owner;
@property (nonatomic,strong) NSString *resourcetype;
@property (nonatomic,strong) NSString *rn;
@property (nonatomic,strong) NSString *state;
@property (nonatomic,strong) NSString *time;
@end


/*
 bh = "\U5e02SW201708250010";
 forwardId = 1812;
 forwardItemId = 33705;
 gwlx = "\U884c\U653f\U6536\U6587";
 mc = "\U5609\U5174\U5e02\U5efa\U59d4\U5173\U4e8e\U67e5\U5efa\U7965\U540c\U5fd7\U514d\U804c\U7684\U901a\U77e5";
 name = "\U5609\U5174\U5e02\U5efa\U59d4\U5173\U4e8e\U67e5\U5efa\U7965\U540c\U5fd7\U514d\U804c\U7684\U901a\U77e5";
 owner = 638968;
 resourcetype = 1;
 rn = 5;
 state = 1;
 time = "2017-08-25 10:08";
 */
