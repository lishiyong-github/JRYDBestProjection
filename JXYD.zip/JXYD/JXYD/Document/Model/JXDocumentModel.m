//
//  JXDocumentModel.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXDocumentModel.h"

@implementation JXDocumentModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID":@"id",
             @"wfWorkItemId":@"wfWorkItemID"};
}
- (NSString *)xmbh
{
    return self.totalSerialNo;
}

- (NSString *)projectId
{
    return self.ID;
}

- (NSString *)slbh
{
    return self.projectNo;
}

//- (NSString *)wfWorkItemID

@end
