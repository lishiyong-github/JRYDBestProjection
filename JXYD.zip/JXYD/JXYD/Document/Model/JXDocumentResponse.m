//
//  JXDocumentResponse.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXDocumentResponse.h"

@implementation JXDocumentResponse
+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"result":@"JXDocumentModel"};
}
@end
