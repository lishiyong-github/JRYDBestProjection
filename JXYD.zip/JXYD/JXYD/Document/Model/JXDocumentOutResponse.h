//
//  JXDocumentOutResponse.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/16.
//  Copyright © 2017年 shiyong_li. All rights reserved.
// 发文

#import <Foundation/Foundation.h>

@interface JXDocumentOutResponse : NSObject
@property (nonatomic,strong) NSString *rn;
@property (nonatomic,strong) NSString *projectId;
@property (nonatomic,strong) NSString *blzt;
@property (nonatomic,strong) NSString *fwdbh;
@property (nonatomic,strong) NSString *fwwh;
@property (nonatomic,strong) NSString *fwdw;
@property (nonatomic,strong) NSString *fwbt;
@property (nonatomic,strong) NSString *ztc;
@property (nonatomic,strong) NSString *fwlx;
@property (nonatomic,strong) NSString *ngks;
@property (nonatomic,strong) NSString *ngr;
@property (nonatomic,strong) NSString *dqblr;

@property (nonatomic,assign) BOOL isStartActivity;
@end



//{"success":"true","result":{"rn":"1","projectId":"638962","blzt":"在办","fwdbh":"南FW201708250002","fwwh":"","fwdw":"嘉兴市规划管理局南湖区分局","fwbt":"关于强强餐饮外立面装修未经审批的函","ztc":"强强餐饮 外立面装修 未批审批","fwlx":"函","ngks":"南湖分局规划科","ngr":"朱琼浩","dqblr":"郑戚良"}}
