//
//  JXReadModel.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXReadModel.h"

@implementation JXReadModel
- (NSString *)projectName
{
    return self.name;
}

- (NSString *)xmbh
{
    return self.bh;
}

- (NSString *)currentOffice
{
    return self.gwlx;
}

- (NSString *)projectId
{
    return self.bh;
}

- (NSString *)slbh
{
    return self.bh;
}

- (NSString *)wfWorkItemId
{
    return self.owner;
}
@end
