//
//  JXDocumentResponse.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHListResponseModel.h"
#import "JXDocumentModel.h"
@interface JXDocumentResponse : SHListResponseModel

@end
