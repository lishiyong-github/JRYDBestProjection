//
//  JXDocumentInResponse.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/16.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JXDocumentInResponse : NSObject
@property (nonatomic,strong) NSString *rn;
@property (nonatomic,strong) NSString *projectId;
@property (nonatomic,strong) NSString *blzt;
@property (nonatomic,strong) NSString *swh;
@property (nonatomic,strong) NSString *sfjj;
@property (nonatomic,strong) NSString *lwlx;
@property (nonatomic,strong) NSString *lwbt;
@property (nonatomic,strong) NSString *lwdw;
@property (nonatomic,strong) NSString *lwbh;
@property (nonatomic,strong) NSString *bwyw;
@property (nonatomic,strong) NSString *swrq;
@property (nonatomic,strong) NSString *fwrq;
@property (nonatomic,strong) NSString *dqblr;

@property (nonatomic,assign) BOOL isStartActivity;
@end


//{"success":"true","result":{"rn":"1","projectId":"638968","blzt":"在办","swh":"市SW201708250010","sfjj":"否","lwlx":"建委文件","lwbt":"嘉兴市建委关于查建祥同志免职的通知","lwdw":"委组织人事处","lwbh":"嘉建委组〔2017〕282 号","bwyw":"阅文","swrq":"2017/8/25 0:00:00","fwrq":"2017/8/21 0:00:00","dqblr":"林海"}}
