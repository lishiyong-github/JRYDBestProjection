//
//  JXDocumentModel.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JXProjectProtocol.h"
@interface JXDocumentModel : NSObject<JXProjectProtocol>
@property (nonatomic,strong) NSString *activityName;
@property (nonatomic,strong) NSString *activityTimeLimit;
@property (nonatomic,strong) NSString *buildAddress;
@property (nonatomic,strong) NSString *businessId;
@property (nonatomic,strong) NSString *businessName;
@property (nonatomic,strong) NSString *currentOffice;
@property (nonatomic,strong) NSString *currentUser;
@property (nonatomic,strong) NSString *flowLeftTime;
@property (nonatomic,strong) NSString *flowTime;
@property (nonatomic,strong) NSString *headId;
@property (nonatomic,strong) NSString *ID;
@property (nonatomic,strong) NSString *isCollected;
@property (nonatomic,strong) NSString *isPromise;
@property (nonatomic,strong) NSString *isTime;
@property (nonatomic,strong) NSString *processingUser;
@property (nonatomic,strong) NSString *projectArea;
@property (nonatomic,strong) NSString *projectName;
@property (nonatomic,strong) NSString *projectNo;
@property (nonatomic,strong) NSString *projectTimeLimit;
@property (nonatomic,strong) NSString *receiveTime;
@property (nonatomic,strong) NSString *receiveUser;
@property (nonatomic,strong) NSString *registerTime;
@property (nonatomic,strong) NSString *state;
@property (nonatomic,strong) NSString *stateName;
@property (nonatomic,strong) NSString *superintendCount;
@property (nonatomic,strong) NSString *theoryEndTime;
@property (nonatomic,strong) NSString *totalSerialNo;
@property (nonatomic,strong) NSString *wfProcessInstanceId;
@property (nonatomic,strong) NSString *wfProcessInstanceState;
@property (nonatomic,strong) NSString *wfWorkItemId;
@property (nonatomic,strong) NSString *wfWorkItemState;
@end

/*
 activityName = "\U5206\U5c40\U5206\U53d1";
 activityTimeLimit = 0;
 buildAddress = "\U5426";
 businessId = 101;
 businessName = "\U884c\U653f\U6536\U6587";
 currentOffice = "\U79c0\U6d32\U5206\U5c40\U7efc\U5408\U79d1";
 currentUser = "\U5f20\U658c";
 flowLeftTime = "\U8d85\U671f30\U59295.6\U5c0f\U65f6";
 flowTime = 3;
 headId = 5581;
 id = 637187;
 isCollected = 0;
 isPromise = 1;
 isTime = 1;
 processingUser = "\U5f20\U658c,\U9ec4\U6167\U8273";
 projectArea = "\U5e02\U5c40";
 projectName = "\U5609\U5174\U5e02\U5efa\U59d4\U5173\U4e8e\U5370\U53d12017\U5e74\U53bf\U5e02\U533a\U6d4b\U7ed8\U4e0e\U5730\U7406\U4fe1\U606f\U5de5\U4f5c\U8003\U6838\U529e\U6cd5\U7684\U901a\U77e5  ";
 projectNo = "\U5e02SW201707200022";
 projectTimeLimit = 10;
 receiveTime = "2017/7/25 15:52:34";
 receiveUser = 72;
 registerTime = "2017/7/20 15:10:06";
 state = "\U5728\U529e";
 stateName = "\U5206\U5c40\U516c\U6587\U8d1f\U8d23\U4eba\U5206\U53d1";
 superintendCount = 0;
 theoryEndTime = "2017/8/3 15:10:06";
 totalSerialNo = BG201702514;
 wfProcessInstanceId = 34516da503f1441aad2d465c69c6eb4b;
 wfProcessInstanceState = 0;
 wfWorkItemID = 89fff9414c18430b99b79e8bab6f03a8;
 wfWorkItemState = 1;
 */
