//
//  JXApprovalViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXApprovalViewController.h"
//model
#import "DocumentTableViewCellItem.h"
#import "JXApprovalListReponse.h"
//view
//controller
#import "JXApprovalDetailPageViewController.h"
@interface JXApprovalViewController ()<UISearchBarDelegate>
@property (nonatomic,strong) JXApprovalListReponse *model;

@end

@implementation JXApprovalViewController
@dynamic model;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //set placeholder
    self.searchBar.placeholder = @"请输入项目名称或项目编号";
    // Do any additional setup after loading the view.
}
- (void)selectedCellWithProjectModel:(id <JXProjectProtocol>)projectModel
{
    JXApprovalModel *model = (JXApprovalModel *)projectModel;
    JXApprovalDetailPageViewController *controller = [[JXApprovalDetailPageViewController alloc] init];
    controller.hidesBottomBarWhenPushed = YES;
    controller.model = model;
    controller.title =  @"项目详情";
    controller.type = [@(self.index) stringValue];
    [self.navigationController pushViewController:controller animated:YES];
    [JXLogManager WriteLog:@"项目详情"  logLevel:@1];
}

#pragma mark - override
- (Class)resultClass
{
    return [JXApprovalListReponse class];
}

- (NSString *)getRequestURL
{
    return [JXApiHelper serverAddress];
}

- (NSDictionary *)getParams
{
    NSDictionary *param = @{@"type":@"smartplan",
                            @"action":@"workitem",
                            @"user":[MainModel sharedInstances].userID,
                            @"pagesize":self.pageSize,
                            @"pageindex":self.pageIndex,
                            @"boxtype":@(self.index+1),
                            @"businessTypes":@"0",
                            @"key":self.searchText
                            };
    return param;
}

@end
