//
//  JXDocumentDetailPageViewController.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//公文详情

#import "SHPageViewController.h"
#import "JXDocumentModel.h"
@interface JXDocumentDetailPageViewController : SHPageViewController
@property (nonatomic,strong) JXDocumentModel *model;
@property (nonatomic,assign) NSInteger type;//0-收文 1-发文
@end
