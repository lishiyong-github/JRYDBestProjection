//
//  JXDocumentDetailPageViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXDocumentDetailPageViewController.h"
//controller
#import "JXDocumentDetailViewController.h"
#import "JXMaterialViewController.h"

@interface JXDocumentDetailPageViewController ()

@end

@implementation JXDocumentDetailPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

//- (NSArray *)titles
//{
//    
//}
//
//- (UIViewController *)viewPager:(MBViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index
//{
//    if (index == 0) {
//        JXDocumentDetailViewController *controller = [[JXDocumentDetailViewController alloc]init];
//        controller.documentModel                    = self.model;
//        controller.nav           = self.navigationController;
//        controller.type = self.type;
//        return controller;
//    }else{
//        JXMaterialViewController *controller = [[JXMaterialViewController alloc]init];
//        controller.slbh = self.model.projectNo;
//        return controller;
//    }
//}

@end
