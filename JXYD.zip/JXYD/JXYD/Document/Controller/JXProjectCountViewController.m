//
//  JXProjectCountViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/13.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXProjectCountViewController.h"
#import <AFNetworking/UIWebView+AFNetworking.h>
@interface JXProjectCountViewController ()
@property (nonatomic,strong) UIWebView *webView;
@end

@implementation JXProjectCountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.webView];
    [self requestData];
    
}

- (void)requestData
{
    NSString *url = [NSString stringWithFormat:@"%@%@",[JXApiHelper serverAddress],@"type=smartplan&action=GetRunQianUrl"];
    @weakify(self);
    [self postUrl:url success:^(NSDictionary *json) {
        @strongify(self);
        if ([json[@"success"] isEqualToString:@"true"]) {
            [self loadWebViewWithUrl:json[@"result"]];
        }else{
            [self showEmptyView];
        }
    } failed:^{
        
    }];
}

- (void)loadWebViewWithUrl:(NSString *)url
{
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] progress:nil success:^NSString * _Nonnull(NSHTTPURLResponse * _Nonnull response, NSString * _Nonnull HTML) {
        
        return @"";
    } failure:^(NSError * _Nonnull error) {
        
    }];
}

- (void)myUpdateViewConstraints
{
    [self.webView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
}
- (UIWebView *)webView
{
    if (!_webView) {
        _webView = [UIWebView newAutoLayoutView];
        _webView.scalesPageToFit = YES;
    }
    return _webView;
}

@end
