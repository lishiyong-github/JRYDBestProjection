//
//  JXDocumentPageViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/13.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXDocumentPageViewController.h"
#import "JXDocumentViewController.h"
#import "JXProjectSearchViewController.h"
#import "JXReadViewController.h"
@interface JXDocumentPageViewController ()
@property (nonatomic,strong) UIButton *searchButton;
@end

@implementation JXDocumentPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:[UIColor mainColor]] forBarMetrics:UIBarMetricsDefault];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.searchButton];
    
    self.title = @"公文";
    // Do any additional setup after loading the view.
}

- (UIButton *)searchButton
{
    if (!_searchButton) {
        _searchButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, 30)];
        [_searchButton setTitle:@"搜索" forState:UIControlStateNormal];
        @weakify(self);
        [[_searchButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            JXDocumentViewController *controller = (JXDocumentViewController *)[self getCurrentControllerAtIndex:self.currentIndex];
            [controller startSearch];
        }];
    }
    return _searchButton;
}

#pragma mark - override
- (NSArray *)titles
{
    return @[@"收文",@"发文",@"阅文"];
}

- (UIViewController *)viewPager:(MBViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index
{
    if (index<2) {
        
        JXDocumentViewController *controller = [[JXDocumentViewController alloc]init];
        controller.nav = self.navigationController;
        controller.type = index;
        return controller;
    }else{
        JXReadViewController *controller = [[JXReadViewController alloc]init];
        controller.nav = self.navigationController;
        return controller;
    }
}

- (void)viewPager:(MBViewPagerController *)viewPager didChangeTabToIndex:(NSUInteger)index
{
    if (index == 2) {
        [self.searchButton setHidden:YES];
    }else{
        [self.searchButton setHidden:NO];
    }
}



@end
