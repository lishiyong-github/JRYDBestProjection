//
//  JXDocumentDetailViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXDocumentDetailViewController.h"
#import "DocDetailTableViewCellItem.h"
//response
#import "JXDocumentOutResponse.h"
#import "JXDocumentInResponse.h"
#import "JXReadModel.h"
//view
#import "JXSendBottomView.h"

@interface JXDocumentDetailViewController ()
@property (nonatomic,strong) JXDocumentOutResponse *documentOutResponse;
@property (nonatomic,strong) JXDocumentInResponse *documentInResponse;
@property (nonatomic,strong) JXSendBottomView *finishReadView;
@end

@implementation JXDocumentDetailViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self.view addSubview:self.tableView];
//    self.manager = [[RETableViewManager alloc]initWithTableView:self.tableView];
//    // Do any additional setup after loading the view.
//     self.manager[@"DocDetailTableViewCellItem"]     = @"DocDetailTablevViewCell";
//    [self configTable];
//    self.type = @"3";
    if (self.type.integerValue == 4) {
        [self.view addSubview:self.finishReadView];
        [self.btmView setHidden:YES];
    }
}

- (void)configTable
{
    if (self.type.integerValue != 4) {
        [self.btmView setHidden:NO];
    }
    
    RETableViewSection *section = [[RETableViewSection alloc]init];
    [self.manager addSection:section];
    
    if (self.type.integerValue == 3) {
        [section addItemsFromArray:[self getDocumentOut]];
    }else {
        [section addItemsFromArray:[self getDocumentIn]];
    }
    [section addItemsFromArray:[self getOpinionCellItems]];
    
    if ([self.model respondsToSelector:@selector(typeSearch)]) {
        [self.btmView setHidden:YES];
        [self.finishReadView setHidden:YES];
    }else{
        [section addItem:self.inputItem];
        if (self.type.integerValue == 4){
            self.inputItem.inputText = @"已阅。";
        }
    }
    [self.tableView reloadData];
    
    
    
}


/**
 收文itam array
 
 阅文
 */
- (NSArray *)getDocumentIn
{
    NSMutableArray *items = [NSMutableArray array];
    NSArray *titleArray = @[@"来文标题",@"来文单位",@"来文编号",@"来文类型",@"收文号"];
    NSArray *detailArray = @[self.documentInResponse.lwbt,
                             self.documentInResponse.lwdw,
                             self.documentInResponse.lwbh,
                             self.documentInResponse.lwlx,
                             self.documentInResponse.swh];
    for (NSInteger i = 0; i<titleArray.count; i++) {
        [items addObject:[self getTitleItemWith:titleArray[i] detailTitle:detailArray[i]]];
    }
    return items;
}

/**
发文itam array
 */
- (NSArray *)getDocumentOut
{
    NSArray *titleArray = @[@"发文标题",@"发文单位",@"发文编号",@"主题词",@"发文类型",@"拟稿人",@"发文号"];
    NSMutableArray *items = [NSMutableArray array];
    NSArray *detailArray = @[self.documentOutResponse.fwbt,
                             self.documentOutResponse.fwdw,
                             self.documentOutResponse.fwdbh,
                             self.documentOutResponse.ztc,
                             self.documentOutResponse.fwlx,
                             self.documentOutResponse.ngr,
                             self.documentOutResponse.fwwh];
    for (NSInteger i = 0; i<titleArray.count; i++) {
        [items addObject:[self getTitleItemWith:titleArray[i] detailTitle:detailArray[i]]];
    }
    return items;
}

- (DocDetailTableViewCellItem *)getTitleItemWith:(NSString *)title detailTitle:(NSString *)detailTitle
{
    @weakify(self);
    DocDetailTableViewCellItem *item = [DocDetailTableViewCellItem item];
    item.leftText = title;
    item.rightText = detailTitle;
    item.selectionHandler = ^(id item) {
        @strongify(self);
        [self.view endEditing:YES];
    };
    return item;
}

#pragma mark - requestData
- (void)requestData{
    NSString *url = [JXApiHelper serverAddress];
    NSNumber *sfType = self.type.integerValue == 3?@1:@0;
    NSString *wh;
    if (self.type.integerValue == 4) {
        JXReadModel *model = (id)self.model;
        wh = model.bh;
    }else{
        JXDocumentModel *model = (JXDocumentModel *)self.model;
        wh = model.projectNo;
    }
    NSDictionary *param = @{@"type":@"smartplan",
                            @"action":@"officalbaseinfo",
                            @"sfType":sfType,
                            @"wh":wh,
                            @"wfWorkItemId":checkNullString(self.model.wfWorkItemId),
                            @"projectId":self.model.projectId};
    //收文
    //    url = @"http://192.168.2.239/jxyd/serviceProvider.ashx?type=smartplan&action=officalbaseinfo&sfType=0";
    //    param = @{@"wh":@"市SW201708250010"};
    //发文
//    url = @"http://192.168.2.239/jxyd/serviceProvider.ashx?type=smartplan&action=officalbaseinfo&sfType=1";
//    param = @{@"wh":@"南FW201708250002"};//@lisy test
    @weakify(self);
//    [MBProgressHUD showMessage:@"加载中……" toView:self.view];
    [self postUrl:url param:param success:^(NSDictionary *json) {
        @strongify(self);
        if ([json[@"success"] isEqualToString:@"true"]) {
            if (self.type.integerValue == 3) {
                self.documentOutResponse = [JXDocumentOutResponse mj_objectWithKeyValues:json[@"result"]];
            }else{
                self.documentInResponse = [JXDocumentInResponse mj_objectWithKeyValues:json[@"result"]];
            }
            self.btmView.rightButton.enabled = ![json[@"result"][@"isStartActivity"] boolValue];
            [self configTable];
        }
    } failed:^{
        
    } showIndicator:YES];
}

/**
 完成传阅
 */
- (void)finishRead{
     [JXLogManager WriteLog:@"已阅"  logLevel:@1];
    JXReadModel *model = (id)self.model;
    NSString *url = [JXApiHelper serverAddress];
    NSDictionary *params = @{@"type":@"smartplan",
                             @"action":@"FinishForwardItem",
                             @"id":model.forwardItemId,
                             @"opinion":checkNullString(self.inputItem.inputText)};
    @weakify(self);
    [MBProgressHUD showMessage:@"提交中……" toView:self.view];
    [self postUrl:url param:params success:^(NSDictionary *json) {
        @strongify(self);
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        if ([json[@"success"] isEqualToString:@"true"]) {
            [MBProgressHUD showSuccess:@"完成传阅" toView:self.view];
            [[NSNotificationCenter defaultCenter] postNotificationName:SendSuccessNotification object:nil];
            [self.navigationController popViewControllerAnimated:YES];
        }
    } failed:^{
        [MBProgressHUD hideHUDForView:self.view animated:NO];
    }];
}
#pragma mark - 
- (void)myUpdateViewConstraints
{
    [super myUpdateViewConstraints];
    if (_finishReadView) {
        [self.finishReadView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
        [self.finishReadView autoSetDimension:ALDimensionHeight toSize:70];
    }
}
#pragma mark - getter

- (JXSendBottomView *)finishReadView
{
    if (!_finishReadView) {
        _finishReadView = [JXSendBottomView newAutoLayoutView];
        _finishReadView.button.enabled = YES;
        [_finishReadView.button setTitle:@"已阅" forState:UIControlStateNormal];
        @weakify(self);
        [[_finishReadView.button addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self finishRead];
        }];
    }
    return _finishReadView;
}

@end
