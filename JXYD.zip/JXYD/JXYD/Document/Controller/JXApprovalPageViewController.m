//
//  JXApprovalViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/13.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXApprovalPageViewController.h"
#import "JXDocumentViewController.h"
#import "JXProjectSearchViewController.h"
#import "JXApprovalViewController.h"
@interface JXApprovalPageViewController ()
@property (nonatomic,strong) UIButton *searchButton;
@end

@implementation JXApprovalPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:[UIColor mainColor]] forBarMetrics:UIBarMetricsDefault];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:self.searchButton];
    self.title = @"审批";
    // Do any additional setup after loading the view.
}

- (UIButton *)searchButton
{
    if (!_searchButton) {
        _searchButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, 30)];
        [_searchButton setTitle:@"搜索" forState:UIControlStateNormal];
        @weakify(self);
        [[_searchButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            JXApprovalViewController *controller = (JXApprovalViewController *)[self getCurrentControllerAtIndex:self.currentIndex];
            [controller startSearch];
        }];
    }
    return _searchButton;
}

#pragma mark - override
- (NSArray *)titles
{
    return @[@"在办箱",@"已办箱"];
}

- (UIViewController *)viewPager:(MBViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index
{
    JXApprovalViewController *controller = [[JXApprovalViewController alloc]init];
    controller.nav = self.navigationController;
    controller.index = index;
    return controller;
}

@end
