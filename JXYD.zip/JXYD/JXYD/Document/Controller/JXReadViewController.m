//
//  JXReadViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXReadViewController.h"
//model
#import "JXReadResponse.h"
#import "DocumentTableViewCellItem.h"
//controller
#import "JXApprovalDetailPageViewController.h"
@interface JXReadViewController ()
@property (nonatomic,strong) JXReadResponse *model;
@end

@implementation JXReadViewController
@dynamic model;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.searchBar.placeholder = [NSString stringWithFormat:@"请输入公文名称或公文编号"];
}

- (void)selectedCellWithProjectModel:(id <JXProjectProtocol>)projectModel
{
    //    JXDocumentModel *model = (JXDocumentModel *)projectModel;
    JXApprovalDetailPageViewController *controller = [[JXApprovalDetailPageViewController alloc]init];
    controller.model = projectModel;
    controller.hidesBottomBarWhenPushed = YES;
    controller.title = @"阅文";
    controller.type = @"4";
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - override
- (Class)resultClass
{
    return [JXReadResponse class];
}

- (NSDictionary *)getParams
{
    NSDictionary *param = @{
                            @"type":@"smartplan",
                            @"user":[MainModel sharedInstances].userID,
                            @"pagesize":self.pageSize,
                            @"pageindex":self.pageIndex,
                            @"action":@"cyqylist",
                            @"forwardType":@0,
                            @"resourceType":@1,
                            @"isLoadToMe":@"true"
                            };
    return param;
}

@end
