//
//  JXBusinessTypeCell.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/20.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXBusinessTypeItem.h"
@interface JXBusinessTypeCell : RETableViewCell
@property (nonatomic,strong) UIButton *openButton;
@property (nonatomic,strong) UIButton *selectedButton;
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) JXBusinessTypeItem *item;
@property (nonatomic,strong) NSLayoutConstraint *leftConstraint;
@end
