//
//  JXFilterTableView.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/19.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXFilterTableView.h"
#import "JXBusinessTypeItem.h"
@interface JXFilterTableView ()
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) RETableViewManager *manager;
@property (nonatomic,strong) UIButton *okButton;
@property (nonatomic,strong) UIButton *clearButton;
@property (nonatomic,strong) NSMutableArray *selectedArray;
@end

@implementation JXFilterTableView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.tableView];
        [self setBackgroundColor:[UIColor whiteColor]];
        [self addSubview:self.okButton];
        [self addSubview:self.clearButton];
        [self configButton:self.okButton];
        [self configButton:self.clearButton];
        self.selectedArray = [NSMutableArray array];
        
        //add border
        [self.layer setBorderWidth:2];
        self.layer.borderColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.3].CGColor;
        
        //config manager
        self.manager = [[RETableViewManager alloc]initWithTableView:self.tableView];
        self.manager[@"JXBusinessTypeItem"] = @"JXBusinessTypeCell";
    }
    return self;
}

- (void)setTreeModel:(id<JXBusinessProtocol>)treeModel
{
    _treeModel = treeModel;
    self.treeModel.open = YES;
    [self configTreeTableView];
}

- (void)setDataSources:(NSArray *)dataSources
{
    _dataSources = dataSources;
    [self configDataSourcesTable];
}

- (void)configDataSourcesTable
{
    [self.manager removeAllSections];
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    for (NSString *name in self.dataSources) {
        JXBusinessTypeItem *item = [[JXBusinessTypeItem alloc]init];
        item.hideButton = YES;
        item.name = name;
        item.level = -1;
        if ([name isEqualToString:self.currentName]) {
            item.selected = YES;
        }
        @weakify(self);
        item.clicked = ^{
            @strongify(self);
            self.currentName = name;
            self.hideClicked();
            [self configDataSourcesTable];
        };
        [item setSelectionHandler:^(JXBusinessTypeItem *item){
            item.clicked();
        }];
        [section addItem:item];
    }
    [self.tableView reloadData];
}

- (void)configTreeTableView
{
    [self.manager removeAllSections];
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    
    [section addItemsFromArray:[self getItemsWithTreeModel:self.treeModel]];
    [self.tableView reloadData];
}

- (NSArray *)getItemsWithTreeModel:(id<JXBusinessProtocol>)treeModel
{
    NSMutableArray *items = [NSMutableArray array];
    @weakify(self);
    if (treeModel.children.count) {
        JXBusinessTypeItem *item = [[JXBusinessTypeItem alloc]initWithModel:treeModel];
        [items addObject:item];
        [item setClicked:^{
            @strongify(self);
            treeModel.selected = !treeModel.selected;
            if (treeModel.selected){
                [self dealWithTreeModel:treeModel selected:YES];
            }
            [self dealWithSuperTreeModel:treeModel];
//            [self configTreeTableView];
        }];
        [item setSelectionHandler:^(JXBusinessTypeItem *item){
            @strongify(self);
            treeModel.open = !treeModel.open;
            [self configTreeTableView];
        }];
        if (treeModel.open) {
            for (id<JXBusinessProtocol>model in treeModel.children) {
                model.superModel = treeModel;
                model.level = treeModel.level+1;
                [items addObjectsFromArray:[self getItemsWithTreeModel:model]];
            }
        }
    }else{
        JXBusinessTypeItem *item = [[JXBusinessTypeItem alloc]initWithModel:treeModel];
        item.level = treeModel.level-1;
        item.hideButton = YES;
        [items addObject:item];
        @weakify(self);
        item.clicked = ^{
            @strongify(self);
            treeModel.selected = !treeModel.selected;
            [self dealWithSuperTreeModel:treeModel];
        };
        [item setSelectionHandler:^(JXBusinessTypeItem *item){
            item.clicked();
        }];
    }
    return items;
}
#pragma mark - set data

#pragma mark - config
- (void)myUpdateViewConstraints
{
    [self.tableView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(0, 0, 40, 0)];
    
    [@[self.okButton,self.clearButton] autoAlignViewsToAxis:ALAxisHorizontal];
    [@[self.okButton,self.clearButton] autoSetViewsDimension:ALDimensionHeight toSize:30];
    [@[self.okButton,self.clearButton] autoMatchViewsDimension:ALDimensionWidth];
    
    [self.okButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.clearButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.clearButton autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.okButton withOffset:10];
    [self.okButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
}

- (void)configButton:(UIButton *)button
{
    [button setTintColor:[UIColor whiteColor]];
    [button setBackgroundColor:[UIColor blueColor]];
    [button.layer setMasksToBounds:YES];
    [button.layer setCornerRadius:5];
}

#pragma mark - getter
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
        _tableView.tableFooterView = [UIView new];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}

- (UIButton *)clearButton
{
    if (!_clearButton) {
        _clearButton = [UIButton newAutoLayoutView];
        [_clearButton setTitle:@"清除" forState:UIControlStateNormal];
        @weakify(self);
        [[_clearButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self clear];
        }];
    }
    return _clearButton;
}

- (UIButton *)okButton
{
    if (!_okButton) {
        _okButton = [UIButton newAutoLayoutView];
        [_okButton setTitle:@"确定" forState:UIControlStateNormal];
        @weakify(self);
        [[_okButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            if (self.clicked) {
                self.clicked(self.selectedArray);
            }
        }];
    }
    return _okButton;
}

#pragma mark - selected & unselected
- (void)clear
{
    self.currentName = @"";
    [self dealWithTreeModel:self.treeModel selected:NO];
}

- (void)dealWithTreeModel:(id<JXBusinessProtocol>)treeModel selected:(BOOL)selected
{
    if (treeModel.children.count) {
        treeModel.selected = selected;
        for (id <JXBusinessProtocol> model in treeModel.children) {
            [self dealWithTreeModel:model selected:selected];
        }
    }else{
        treeModel.selected = selected;
    }
}

- (void)dealWithSuperTreeModel:(id<JXBusinessProtocol>)treeModel
{
    if (treeModel.superModel) {
        NSInteger count = 0;
        for (id<JXBusinessProtocol>model in treeModel.superModel.children) {
            if (model.selected) {
                count++;
            }
        }
        if (count == treeModel.superModel.children.count) {
            treeModel.superModel.selected = YES;
        }else{
            treeModel.superModel.selected = NO;
        }
        [self dealWithSuperTreeModel:treeModel.superModel];
    }
}


#pragma mark - out
- (void)hideButton

{
    [self.okButton setHidden:YES];
    [self.clearButton setHidden:YES];
}

- (NSArray *)getValueWith:(id<JXBusinessProtocol>)treeModel
{
    NSMutableArray *array = [NSMutableArray array];
    if (treeModel.children.count) {
        for (id model in treeModel.children) {
            [array addObjectsFromArray:[self getValueWith:model]];
        }
    }else{
        if (treeModel.selected) {
            [array addObject:treeModel.name];
        }
    }
    return array;
}

- (NSArray *)getParams
{
    return [self getValueWith:self.treeModel];
}

- (void)setHidden:(BOOL)hidden
{
    [super setHidden:hidden];
    if (hidden == NO) {
        [self.superview bringSubviewToFront:self];
    }
}
@end
