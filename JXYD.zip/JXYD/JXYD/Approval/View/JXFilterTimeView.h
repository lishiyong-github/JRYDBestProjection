//
//  NBFilterTimeView.h
//  nbOneMap
//
//  Created by shiyong_li on 2017/7/31.
//  Copyright © 2017年 dist. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXFilterTimeView : UIView
@property (nonatomic,copy) void (^searchTimeHandler)(NSString *from,NSString *to);
- (void)setTitle:(NSString *)title;
- (BOOL)isFirstResponder;
- (void)setFrom:(NSString *)from to:(NSString *)to;
@end
