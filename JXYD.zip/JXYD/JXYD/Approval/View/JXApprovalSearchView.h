//
//  JXApprovalSearchView.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/18.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//
#import "JXBusinessProtocol.h"
@interface JXApprovalSearchView : UIView
@property (nonatomic,strong) UIButton *searchButton;
@property (nonatomic,strong) UIButton *highSearchButton;
@property (nonatomic,strong) id<JXBusinessProtocol> treeModel;
@property (nonatomic,copy) void (^searchBlock)(NSDictionary *param);
- (void)hideSearchTableView;
- (void)setTreeModel:(id<JXBusinessProtocol>)treeModel;
- (void)setAreaModel:(id<JXBusinessProtocol>)treeModel;
@end
