//
//  JXBusinessTypeCell.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/20.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXBusinessTypeCell.h"
#import "UIView+Line.h"
@implementation JXBusinessTypeCell
@dynamic item;
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.openButton];
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.selectedButton];
        [self setNeedsUpdateConstraints];
        [self.contentView addBottomLine];
        self.leftConstraint =  [self.openButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    }
    return self;
}


- (void)cellWillAppear
{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self.titleLabel setText:self.item.name];
    self.openButton.selected = self.item.open;
    self.openButton.hidden = self.item.hideButton;
    self.selectedButton.hidden = self.item.hideSelectedButton;
    
    self.leftConstraint.constant = 15+self.item.level*25;
    @weakify(self);
    [[RACObserve(self.item, selected) takeUntil:[self rac_prepareForReuseSignal]] subscribeNext:^(id x) {
        @strongify(self);
        self.selectedButton.selected = [x boolValue];
    }];
}

- (void)myUpdateViewConstraints
{
//    [self.openButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.openButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.openButton autoSetDimensionsToSize:CGSizeMake(20, 20)];
    
    [self.titleLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.openButton withOffset:10];
    [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.selectedButton autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.titleLabel withOffset:6];
    
    [self.selectedButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.selectedButton autoSetDimensionsToSize:CGSizeMake(26, 26)];
    [self.selectedButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
}

- (UIButton *)openButton
{
    if (!_openButton) {
        _openButton = [UIButton newAutoLayoutView];
        UIImage *image = [UIImage imageNamed:@"ptree_right"];
        image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [_openButton setImage:image forState:UIControlStateNormal];
        
        UIImage *simage = [UIImage imageNamed:@"ptree_down"];
        simage = [simage imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [_openButton setImage:simage forState:UIControlStateSelected];
        [_openButton setTintColor:[UIColor grayColor]];
        _openButton.userInteractionEnabled = NO;
    }
    return _openButton;
}

- (UIButton *)selectedButton
{
    if (!_selectedButton) {
        _selectedButton = [UIButton newAutoLayoutView];
        [_selectedButton setImage:[UIImage imageNamed:@"tree_unselected"] forState:UIControlStateNormal];
        [_selectedButton setImage:[UIImage imageNamed:@"tree_selected"] forState:UIControlStateSelected];
        @weakify(self);
        [[_selectedButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            if (self.item.clicked) {
                self.item.clicked();
            }
        }];
    }
    return _selectedButton;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [UILabel newAutoLayoutView];
        [_titleLabel setFont:[UIFont systemFontOfSize:16]];
    }
    return _titleLabel;
}

@end
