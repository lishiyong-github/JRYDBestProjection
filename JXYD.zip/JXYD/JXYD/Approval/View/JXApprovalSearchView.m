//
//  JXApprovalSearchView.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/18.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXApprovalSearchView.h"
#import "JXTitleFieldView.h"
#import "JXFilterTimeView.h"
#import "JXFilterTableView.h"

@interface JXApprovalSearchView ()
@property (nonatomic,strong) JXTitleFieldView *projectNameView;
@property (nonatomic,strong) JXTitleFieldView *buileAddressView;
@property (nonatomic,strong) JXTitleFieldView *fileNoView;
@property (nonatomic,strong) JXTitleFieldView *projectNoView;
@property (nonatomic,strong) JXTitleFieldView *cardNoView;
@property (nonatomic,strong) JXTitleFieldView *buildTypeView;
@property (nonatomic,strong) JXTitleFieldView *statusView;
@property (nonatomic,strong) JXTitleFieldView *areaView;
@property (nonatomic,strong) JXTitleFieldView *timeFromView;
@property (nonatomic,strong) JXTitleFieldView *timeToView;

@property (nonatomic,strong) JXFilterTableView *areaTableView;
@property (nonatomic,strong) JXFilterTableView *statusTableView;
@property (nonatomic,strong) JXFilterTableView *businessTableView;

@property (nonatomic,strong) NSLayoutConstraint *areaHeightConstraints;
@property (nonatomic,strong) NSLayoutConstraint *statusHeightConstraints;
@property (nonatomic,strong) NSLayoutConstraint *businessHeightConstraints;

@property (nonatomic,strong) UIButton *resetButton;
@end
@implementation JXApprovalSearchView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubView];
        
        [self setBackgroundColor:[UIColor whiteColor]];
        [self setNeedsUpdateConstraints];
        
        @weakify(self);
        [[[[NSNotificationCenter defaultCenter] rac_addObserverForName:UIKeyboardWillShowNotification object:nil]takeUntil:[self rac_willDeallocSignal]] subscribeNext:^(id x) {
            @strongify(self);
            [self hideSearchTableView];
        }];
    }
    return self;
}

- (void)addSubView
{
    //line1
    [self addSubview:self.projectNameView];
    [self addSubview:self.areaView];
    [self addSubview:self.buileAddressView];
    [self addSubview:self.buildTypeView];
    
    //line2
    [self addSubview:self.fileNoView];
    [self addSubview:self.projectNoView];
    [self addSubview:self.statusView];
    [self addSubview:self.cardNoView];
    //line3
    [self addSubview:self.timeFromView];
    [self addSubview:self.timeToView];
    [self addSubview:self.searchButton];
    [self addSubview:self.highSearchButton];
    [self addSubview:self.resetButton];
    //        [self addSubview:self.timeView];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self  addSearchTableView];
    });
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self endEditing:YES];
    [self hideSearchTableView];
}

- (void)addSearchTableView
{
    //add tableview
    [self.superview addSubview:self.areaTableView];
    [self.superview addSubview:self.statusTableView];
    [self.superview addSubview:self.businessTableView];

    self.areaHeightConstraints = [self.areaTableView autoSetDimension:ALDimensionHeight toSize:0];
    self.statusHeightConstraints = [self.statusTableView autoSetDimension:ALDimensionHeight toSize:0];
    self.businessHeightConstraints = [self.businessTableView autoSetDimension:ALDimensionHeight toSize:400];
    
    //add search tableview
    [self.areaTableView autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self withOffset:40];
//    [self.areaTableView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:+60+20+40];
    [self.areaTableView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:267];
    [self.areaTableView autoSetDimension:ALDimensionWidth toSize:244];
    
    [self.statusTableView autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self withOffset:40+60];
//    [self.statusTableView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:64+60+20+40+60];
    [self.statusTableView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:619];
    [self.statusTableView autoSetDimension:ALDimensionWidth toSize:144];
    
    [self.businessTableView autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self withOffset:40];
//    [self.businessTableView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:64+60+20+40];
    [self.businessTableView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:620];
    [self.businessTableView autoSetDimension:ALDimensionWidth toSize:394];
}

- (void)setTreeModel:(id<JXBusinessProtocol>)treeModel
{
    _treeModel = treeModel;
    [self.businessTableView setTreeModel:treeModel];
}
- (void)setAreaModel:(id<JXBusinessProtocol>)treeModel
{
    _treeModel = treeModel;
    [self.areaTableView setTreeModel:treeModel];
}


- (void)myUpdateViewConstraints
{
    [super myUpdateViewConstraints];
    NSArray *array1 = @[self.projectNameView,self.areaView,self.buileAddressView,self.buildTypeView];
    [array1 autoAlignViewsToAxis:ALAxisHorizontal];
    [array1 autoMatchViewsDimension:ALDimensionWidth];
    [array1 autoSetViewsDimension:ALDimensionHeight toSize:40];
    [array1 autoDistributeViewsAlongAxis:ALAxisHorizontal alignedTo:ALAttributeHorizontal withFixedSpacing:10];
    [self.projectNameView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.projectNameView autoPinEdgeToSuperviewEdge:ALEdgeTop];
    [self.buildTypeView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    
    NSArray *array2 = @[self.fileNoView,self.projectNoView,self.statusView,self.cardNoView];
    [array2 autoAlignViewsToAxis:ALAxisHorizontal];
    [array2 autoMatchViewsDimension:ALDimensionWidth];
    [array2 autoSetViewsDimension:ALDimensionHeight toSize:40];
    [array2 autoDistributeViewsAlongAxis:ALAxisHorizontal alignedTo:ALAttributeHorizontal withFixedSpacing:10];
    [self.cardNoView autoPinEdge:ALEdgeRight toEdge:ALEdgeRight ofView:self.buildTypeView];
    [self.fileNoView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.projectNameView withOffset:20];
    //set timeView
    
    [@[self.projectNameView,self.timeFromView] autoAlignViewsToEdge:ALEdgeLeft];
    [self.fileNoView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    
    [self.timeFromView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.fileNoView withOffset:20];
    [self.timeFromView autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.fileNoView];
    [self.timeFromView autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.fileNoView];
    
    [self.timeToView autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.timeFromView];
    [self.timeToView autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.timeFromView withOffset:10];
    
    [@[self.timeFromView,self.timeToView,self.resetButton,self.searchButton,self.highSearchButton] autoAlignViewsToAxis:ALAxisHorizontal];
    [@[self.timeFromView,self.timeToView] autoMatchViewsDimension:ALDimensionWidth];
    [@[self.resetButton,self.searchButton,self.highSearchButton] autoMatchViewsDimension:ALDimensionHeight];
    [self.searchButton autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.resetButton withOffset:10];
    [self.highSearchButton autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.searchButton withOffset:10];
    [self.highSearchButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.searchButton autoSetDimension:ALDimensionHeight toSize:40];
    [self.searchButton autoSetDimension:ALDimensionWidth toSize:60];
    [self.resetButton autoSetDimension:ALDimensionWidth toSize:60];
    
}

- (void)animationLayout
{
//    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    [self.superview setNeedsUpdateConstraints];
    [self.superview updateConstraintsIfNeeded];
    [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        [self.superview layoutIfNeeded]; // this is what actually causes the views to animate to their new layout
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark - getter
- (JXTitleFieldView *)projectNameView
{
    if (!_projectNameView) {
        _projectNameView = [JXTitleFieldView newAutoLayoutView];
        [_projectNameView setTitle:@"项目名称："];
    }
    return _projectNameView;
}

- (JXTitleFieldView *)areaView
{
    if (!_areaView) {
        _areaView = [JXTitleFieldView newAutoLayoutView];
        [_areaView setFieldType:JXFiledTypeMenu];
        [_areaView setTitle:@"所属区域："];
        [_areaView setText:@"所有区域"];
        @weakify(self);
        _areaView.clicked = ^{
            @strongify(self);
            [self hideAreatableView:!self.areaTableView.hidden];
            [self hideStatusTableView:YES];
            [self hideBusinessTableView:YES];
            [self animationLayout];
        };
    }
    return _areaView;
}
- (JXTitleFieldView *)buileAddressView
{
    if (!_buileAddressView) {
        _buileAddressView = [JXTitleFieldView newAutoLayoutView];
        [_buileAddressView setTitle:@"建设地址："];
    }
    return _buileAddressView;
}
- (JXTitleFieldView *)buildTypeView
{
    if (!_buildTypeView) {
        _buildTypeView = [JXTitleFieldView newAutoLayoutView];
        [_buildTypeView setTitle:@"业务类型："];
        [_buildTypeView setFieldType:JXFiledTypeMenu];
        [_buildTypeView setText:@"所有业务"];
        @weakify(self);
        _buildTypeView.clicked = ^{
            @strongify(self);
            [self hideBusinessTableView:!self.businessTableView.hidden];
            [self hideAreatableView:YES];
            [self hideStatusTableView:YES];
            [self animationLayout];
        };
    }
    return _buildTypeView;
}
#pragma mark - line 2
- (JXTitleFieldView *)fileNoView
{
    if (!_fileNoView ) {
        _fileNoView = [JXTitleFieldView newAutoLayoutView];
        [_fileNoView setTitle:@"案卷编号："];
    }
    return _fileNoView ;
}
- (JXTitleFieldView *)projectNoView
{
    if (!_projectNoView) {
        _projectNoView = [JXTitleFieldView newAutoLayoutView];
        [_projectNoView setTitle:@"项目编号："];
    }
    return _projectNoView;
}
- (JXTitleFieldView *)statusView
{
    if (!_statusView) {
        _statusView = [JXTitleFieldView newAutoLayoutView];
        [_statusView setTitle:@"办理状态："];
        [_statusView setFieldType:JXFiledTypeMenu];
        [_statusView setText:@"全部"];
        @weakify(self);
        _statusView.clicked = ^{
            @strongify(self);
            [self hideStatusTableView:!self.statusTableView.hidden];
            [self hideAreatableView:YES];
            [self hideBusinessTableView:YES];
            [self animationLayout];
        };
    }
    return _statusView;
}
- (JXTitleFieldView *)cardNoView
{
    if (!_cardNoView) {
        _cardNoView = [JXTitleFieldView newAutoLayoutView];
        [_cardNoView setTitle:@"证号："];
    }
    return _cardNoView;
}

- (JXTitleFieldView *)timeFromView
{
    if (!_timeFromView) {
        _timeFromView = [JXTitleFieldView newAutoLayoutView];
        [_timeFromView setTitle:@"登记日期："];
        _timeFromView.textField.placeholder = @"开始日期";
        [_timeFromView setFieldType:JXFiledTypeTime];
    }
    return _timeFromView;
}

- (JXTitleFieldView *)timeToView
{
    if (!_timeToView) {
        _timeToView = [JXTitleFieldView newAutoLayoutView];
        [_timeToView setTitle:@"～"];
        _timeToView.textField.placeholder = @"截止日期";
        [_timeToView setFieldType:JXFiledTypeTime];
    }
    return _timeToView;
}

- (UIButton *)resetButton
{
    if (!_resetButton) {
        _resetButton = [UIButton newAutoLayoutView];
        [_resetButton setTitle:@" 重置 " forState:UIControlStateNormal];
        [_resetButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_resetButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
        [_resetButton setBackgroundImage:[UIImage imageWithColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.3]] forState:UIControlStateNormal];
        [_resetButton setBackgroundImage:[UIImage imageWithColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]] forState:UIControlStateHighlighted];
        [_resetButton.layer setMasksToBounds:YES];
        [_resetButton.layer setCornerRadius:5];
        @weakify(self);
        [[_resetButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self endEditing:YES];
            [self resetParam];
        }];
    }
    return _resetButton;
}

- (UIButton *)searchButton
{
    if (!_searchButton) {
        _searchButton = [UIButton newAutoLayoutView];
        [_searchButton setTitle:@" 搜索 " forState:UIControlStateNormal];
        [_searchButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_searchButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
        [_searchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.3]] forState:UIControlStateNormal];
        [_searchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]] forState:UIControlStateHighlighted];
        [_searchButton.layer setMasksToBounds:YES];
        [_searchButton.layer setCornerRadius:5];
        @weakify(self);
        [[_searchButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self endEditing:YES];
            if (self.searchBlock) {
                self.searchBlock([self getParams]);
            }
        }];
    }
    return _searchButton;
}

- (UIButton *)highSearchButton
{
    if (!_highSearchButton) {
        _highSearchButton = [UIButton newAutoLayoutView];
        [_highSearchButton setTitle:@" 隐藏高级搜索 " forState:UIControlStateNormal];
        [_highSearchButton setTitle:@" 隐藏高级搜索 " forState:UIControlStateHighlighted];
        [_highSearchButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_highSearchButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
        [_highSearchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]] forState:UIControlStateHighlighted];
        [_highSearchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]] forState:UIControlStateNormal];
        [_highSearchButton.layer setMasksToBounds:YES];
        [_highSearchButton.layer setCornerRadius:5];
    }
    return _highSearchButton;
}

#pragma mark - search  area tableview
- (JXFilterTableView *)areaTableView
{
    if (!_areaTableView) {
        _areaTableView = [JXFilterTableView newAutoLayoutView];
        [_areaTableView setHidden:YES];
//        [_areaTableView setDataSources:@[@"市局",@"南湖分局",@"秀洲分局",@"经开分局"]];
        @weakify(self);
        _areaTableView.clicked = ^(NSArray *textArray) {
            @strongify(self);
            if (textArray.count) {
                NSString *text = [textArray componentsJoinedByString:@","];
                self.areaView.textField.text = text;
            }
            [self hideAreatableView:YES];
            [self animationLayout];
        };
    }
    return _areaTableView;
}

- (void)hideAreatableView:(BOOL)hide
{
    if (!hide) {
        self.areaTableView.hidden = NO;
        self.areaHeightConstraints.constant = 300;
    }else{
        NSString *text = [[self.areaTableView getParams] componentsJoinedByString:@","];
        if (text) {
            [self.areaView setText:text];
        }else{
            [self.areaView setText:@"所有区域"];
        }
        self.areaHeightConstraints.constant = 0;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.areaTableView.hidden = YES;
        });
    }
}

- (void)hideSearchTableView
{
    [self hideAreatableView:YES];
    [self hideStatusTableView:YES];
    [self hideBusinessTableView:YES];
    [self animationLayout];
}

- (void)removeSearchTableView
{
    [self.statusTableView removeFromSuperview];
    [self.businessTableView removeFromSuperview];
    [self.areaTableView removeFromSuperview];
}

#pragma mark - getter
- (JXFilterTableView *)statusTableView
{
    if (!_statusTableView) {
        _statusTableView = [JXFilterTableView newAutoLayoutView];
        [_statusTableView setHidden:YES];
        [_statusTableView hideButton];
        _statusTableView.currentName = @"全部";
        [_statusTableView setDataSources:@[@"全部",@"在案",@"结案",@"申请上会中",@"暂停",@"补件",@"退件"]];
        @weakify(self);
        _statusTableView.clicked = ^(NSArray *textArray) {
            @strongify(self);
            if (textArray.count) {
                NSString *text = [textArray componentsJoinedByString:@","];
                self.statusView.textField.text = text;
            }
            [self hideStatusTableView:YES];
            [self animationLayout];
        };
        
        _statusTableView.hideClicked = ^{
            @strongify(self);
            [self hideStatusTableView:YES];
            [self.statusView setText:self.statusTableView.currentName];
        };
    }
    return _statusTableView;
}

- (void)hideStatusTableView:(BOOL)hide
{
    if (!hide) {
        self.statusTableView.hidden = NO;
        self.statusHeightConstraints.constant = 400;
    }else{
        [self.statusView setText:self.statusTableView.currentName];
        self.statusHeightConstraints.constant = 0;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.statusTableView.hidden = YES;
        });
    }
}

- (JXFilterTableView *)businessTableView
{
    if (!_businessTableView) {
        _businessTableView = [JXFilterTableView newAutoLayoutView];
        [_businessTableView setHidden:YES];
        @weakify(self);
        _businessTableView.clicked = ^(NSArray *textArray) {
            @strongify(self);
            if (textArray.count) {
                NSString *text = [textArray componentsJoinedByString:@","];
                self.buildTypeView.textField.text = text;
            }
            [self hideBusinessTableView:YES];
            [self animationLayout];
        };
    }
    return _businessTableView;
}

- (void)hideBusinessTableView:(BOOL)hide
{
    if (!hide) {
        self.businessTableView.hidden = NO;
        self.businessHeightConstraints.constant = 500;
    }else{
        NSString *text = [[self.businessTableView getParams] componentsJoinedByString:@","];
        if (text) {
            [self.buildTypeView setText:text];
        }else{
            [self.buildTypeView setText:@"所有业务"];
        }
        self.businessHeightConstraints.constant = 0;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.businessTableView.hidden = YES;
        });
    }
}

#pragma mark - deal with param

- (void)resetParam
{
    self.projectNameView.text = nil;
    [self.areaTableView clear];
    self.buileAddressView.text = nil;
    [self.businessTableView clear];
    self.fileNoView.text = nil;
    self.projectNoView.text = nil;
    [self.statusTableView clear];
    self.timeFromView.text = nil;
    self.timeToView.text = nil;
//    self.areaView.text = @"所有区域";
//    self.buildTypeView.text = @"所有业务";
//    self.statusView.text = @"全部";
    
    self.areaView.text = @"";
    self.buildTypeView.text = @"";
    self.statusView.text = @"";
}

- (NSDictionary *)getParams
{
    NSArray *regionArray = [self.areaTableView getParams];
    NSArray *businessTypeArray = [self.businessTableView getParams];
    NSString *region = [regionArray componentsJoinedByString:@"-"];
    NSString *business = [businessTypeArray componentsJoinedByString:@"-"];
    
    NSDictionary *params = @{@"projectName":checkNullString(self.projectNameView.text),
                             @"projectRegion":region,
                             @"buildAddress":checkNullString(self.buileAddressView.text),
                             @"businessType":business,
                             @"projectNo":checkNullString(self.fileNoView.text),
                             @"xmbh":checkNullString(self.projectNoView.text),
                             @"blzt":self.statusTableView.currentName,
                             @"zh":checkNullString(self.cardNoView.text),
                             @"startRegisTime":checkNullString(self.timeFromView.text),
                             @"endRegisTime":checkNullString(self.timeToView.text)
                             };
    return params;
}

@end
