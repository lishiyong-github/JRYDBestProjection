//
//  NBFilterTimeView.m
//  nbOneMap
//
//  Created by shiyong_li on 2017/7/31.
//  Copyright © 2017年 dist. All rights reserved.
//

#import "JXFilterTimeView.h"
@interface JXFilterTimeView ()<UITextFieldDelegate>
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UITextField *fromField;
@property (nonatomic,strong) UITextField *toField;
@property (nonatomic,strong) UILabel *centerLabel;
@property (nonatomic,strong) UIDatePicker *datePicker;
@end
@implementation JXFilterTimeView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.fromField];
        [self addSubview:self.toField];
        [self addSubview:self.titleLabel];
        [self addSubview:self.centerLabel];
        [self setNeedsUpdateConstraints];
        
        Method m1 = class_getInstanceMethod([UITextField class], @selector(canPerformAction:withSender:));
        Method m2 = class_getInstanceMethod([JXFilterTimeView class], @selector(empty));
        method_exchangeImplementations(m1, m2);
    }
    return self;
}
- (BOOL)empty{
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    if (menuController)
    {
        [UIMenuController sharedMenuController].menuVisible = NO;
    }
    return NO;
}

- (void)myUpdateViewConstraints
{
    [self.titleLabel autoSetDimension:ALDimensionWidth toSize:100];
    [self.titleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft];
    
    [@[self.titleLabel,self.fromField,self.toField,self.centerLabel] autoAlignViewsToAxis:ALAxisHorizontal];
    [self.fromField autoPinEdgeToSuperviewEdge:ALEdgeTop];
    
    [@[self.fromField,self.toField] autoMatchViewsDimension:ALDimensionHeight];
    [@[self.fromField,self.toField] autoMatchViewsDimension:ALDimensionWidth];
    
    [self.toField autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.fromField withOffset:10];
    [self.toField autoPinEdgeToSuperviewEdge:ALEdgeRight];
    [self.fromField autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.titleLabel];
    [self.centerLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.fromField];
    
}

- (void)setTitle:(NSString *)title
{
    [self.titleLabel setText:title];
}
#pragma mark - delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (!textField.text.length) {
        [self setDateStringWith:[[NSDate alloc] init]];
    }
    [self.datePicker setDate:[self getDateWithString:textField.text] animated:YES];
}

- (void)configField:(UITextField *)field
{
//    [field setBackgroundColor:kBackgroundColor];
    [field setTextAlignment:NSTextAlignmentCenter];
    [field setInputView:self.datePicker];
    field.delegate = self;
    [field setTintColor:[UIColor blueColor]];
    field.layer.cornerRadius = 5;
    field.layer.masksToBounds = YES;
}
- (BOOL)isFirstResponder
{
    return self.fromField.isFirstResponder||self.toField.isFirstResponder;
}
#pragma mark - getter
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [UILabel newAutoLayoutView];
        [_titleLabel setFont:[UIFont systemFontOfSize:18]];
        [_titleLabel setTintColor:[UIColor blackColor]];
        [_titleLabel setTextAlignment:NSTextAlignmentCenter];
    }
    return _titleLabel;
}
- (UITextField *)fromField
{
    if (!_fromField) {
        _fromField = [UITextField newAutoLayoutView];
        [self configField:_fromField];
        [_fromField setPlaceholder:@"起始时间"];
    }
    return _fromField;
}

- (UITextField *)toField
{
    if (!_toField) {
        _toField = [UITextField newAutoLayoutView];
        [self configField:_toField];
        [_toField setPlaceholder:@"截止时间"];
    }
    return _toField;
}

- (UILabel *)centerLabel
{
    if (!_centerLabel) {
        _centerLabel = [UILabel newAutoLayoutView];
        [_centerLabel setText:@"~"];
        [_centerLabel setTextColor:[UIColor lightGrayColor]];
    }
    return _centerLabel;
}
- (UIDatePicker *)datePicker
{
    if (!_datePicker) {
        _datePicker = [[UIDatePicker alloc]init];
        _datePicker.datePickerMode = UIDatePickerModeDate;
        @weakify(self);
        [[_datePicker rac_newDateChannelWithNilValue:nil] subscribeNext:^(NSDate *date) {
            @strongify(self);
            [self setDateStringWith:date];
        }];
    }
    return _datePicker;
}

#pragma mark - gettemethod
- (void)setDateStringWith:(NSDate *)date
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd"]; //yyyy- 年  HH:mm
    NSString *dateString = [formatter stringFromDate:date];
    if ([self.fromField isFirstResponder]) {
        self.fromField.text = dateString;
    }else{
        self.toField.text = dateString;
    }
}

- (NSDate *)getDateWithString:(NSString *)time
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd"]; //yyyy- 年  HH:mm
    NSDate *date = [formatter dateFromString:time];
    return date;
}

- (void)search
{
    [self endEditing:YES];
    if (!self.fromField.text.length && !self.toField.text.length) {
        self.searchTimeHandler(self.fromField.text, self.toField.text);
        return;
    }
    BOOL pass = [self compareDate];
    if (pass) {
        if (self.searchTimeHandler) {
            self.searchTimeHandler(self.fromField.text, self.toField.text);
        }
    }
    else{
        
        if (self.isFirstResponder) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                [self showAlert];
            });
        }else{
            [self showAlert];
        }
    }
}

- (void)showAlert
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"您选择的‘起始时间’大于‘截止时间’，请重新选择" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alert show];
}



- (BOOL)compareDate
{
//    2017-02-01
    NSString *fromStr = [self.fromField.text stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSString *toStr = [self.toField.text stringByReplacingOccurrencesOfString:@"-" withString:@""];
    if ([fromStr integerValue]>[toStr integerValue] && toStr.length>0) {
        return NO;
    }
    return YES;
}

- (void)setFrom:(NSString *)from to:(NSString *)to
{
    [self.fromField setText:from];
    [self.toField setText:to];
}
@end
