//
//  JXFilterTableView.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/19.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXBusinessProtocol.h"
typedef  void (^Clicked)(NSArray *textArray);
@interface JXFilterTableView : UIView
@property (nonatomic,copy) Clicked clicked;
@property (nonatomic,strong) NSArray *dataSources;
@property (nonatomic,strong) NSString *currentName;//status view

@property (nonatomic,strong) id<JXBusinessProtocol> treeModel;
@property (nonatomic,copy) void (^hideClicked)();
//+ (void)showDataSources:(NSArray *)dataSources
- (void)hideButton;
- (NSArray *)getParams;
- (void)clear;
@end
