//
//  JXTitleFieldView.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/19.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger,JXFiledType){
    JXFiledTypeDefault = 0,
    JXFiledTypeMenu,
    JXFiledTypeTime
};
@interface JXTitleFieldView : UIView
@property (nonatomic,strong) UITextField *textField;
@property (nonatomic,assign) JXFiledType fieldType;
@property (nonatomic,strong) NSString *text;
@property (nonatomic,copy) void (^clicked)();
//set title
- (void)setTitle:(NSString *)title;
- (void)setText:(NSString *)text;

@end
