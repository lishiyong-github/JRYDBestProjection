//
//  JXApprovalSearchHeaderView.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/18.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXApprovalSearchHeaderView.h"

@implementation JXApprovalSearchHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.textField];
        [self addSubview:self.searchButton];
        [self addSubview:self.highSearchButton];
        [self setBackgroundColor:[UIColor whiteColor]];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void)myUpdateViewConstraints
{
    [@[self.textField,self.searchButton,self.highSearchButton] autoAlignViewsToAxis:ALAxisHorizontal];
    [self.textField autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
    [self.textField autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    
    [@[self.textField,self.searchButton,self.highSearchButton] autoSetViewsDimension:ALDimensionHeight toSize:40];
//    [self.textField autoSetDimension:ALDimensionHeight toSize:30];
    [self.searchButton autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.textField withOffset:15];
    [self.highSearchButton autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.searchButton withOffset:15];
    [self.highSearchButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    
    [self.searchButton autoSetDimension:ALDimensionWidth toSize:80];
    [self.highSearchButton autoSetDimension:ALDimensionWidth toSize:80];
}

#pragma mark - getter
- (UITextField *)textField
{
    if (!_textField) {
        _textField = [UITextField newAutoLayoutView];
        _textField.borderStyle = UITextBorderStyleRoundedRect;
        _textField.placeholder = @"请输入项目名称、案卷编号、项目编号";
    }
    return _textField ;
}

- (UIButton *)searchButton
{
    if (!_searchButton) {
        _searchButton = [UIButton newAutoLayoutView];
        [_searchButton setTitle:@" 搜索 " forState:UIControlStateNormal];
        [_searchButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_searchButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
        [_searchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.3]] forState:UIControlStateNormal];
        [_searchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]] forState:UIControlStateHighlighted];
        [_searchButton.layer setMasksToBounds:YES];
        [_searchButton.layer setCornerRadius:5];
    }
    return _searchButton;
}

- (UIButton *)highSearchButton
{
    if (!_highSearchButton) {
        _highSearchButton = [UIButton newAutoLayoutView];
        [_highSearchButton setTitle:@" 高级搜索 " forState:UIControlStateNormal];
        [_highSearchButton setTitle:@" 隐藏高级搜索 " forState:UIControlStateSelected];
        [_highSearchButton setTitle:@" 高级搜索 " forState:UIControlStateHighlighted];
        [_highSearchButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_highSearchButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
        [_highSearchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.3]] forState:UIControlStateNormal];
        [_highSearchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]] forState:UIControlStateHighlighted];
        [_highSearchButton setBackgroundImage:[UIImage imageWithColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]] forState:UIControlStateSelected];
        [_highSearchButton.layer setMasksToBounds:YES];
        [_highSearchButton.layer setCornerRadius:5];
        [_highSearchButton setHidden:YES];
    }
    return _highSearchButton;
}

@end
