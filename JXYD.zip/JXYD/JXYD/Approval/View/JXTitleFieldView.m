//
//  JXTitleFieldView.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/19.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTitleFieldView.h"

@interface JXTitleFieldView ()<UITextFieldDelegate>
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UIImageView *imageView;
@property (nonatomic,strong) UIDatePicker *datePicker;
@end
@implementation JXTitleFieldView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.titleLabel];
        [self addSubview:self.textField];
        [self addSubview:self.imageView];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void)setTitle:(NSString *)title
{
    [self.titleLabel setText:title];
}

- (NSString *)text
{
    return self.textField.text;
}

- (void)setText:(NSString *)text
{
    self.textField.text = text;
}

- (void)setFieldType:(JXFiledType)fieldType
{
    _fieldType = fieldType;
    if (fieldType == JXFiledTypeMenu) {
        [self.imageView setHidden:NO];
    }else if (fieldType == JXFiledTypeTime){
        [self.textField setTextAlignment:NSTextAlignmentCenter];
        [self.textField setInputView:self.datePicker];
    }
    
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (self.fieldType == JXFiledTypeMenu){
        [textField resignFirstResponder];
        [self.superview endEditing:YES];
        if (self.clicked) {
            self.clicked();
        }
        return NO;
    }
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (self.fieldType == JXFiledTypeTime) {
        [self setDateStringWith:[[NSDate alloc] init]];
        Method m1 = class_getInstanceMethod([UITextField class], @selector(canPerformAction:withSender:));
        Method m2 = class_getInstanceMethod([self class], @selector(empty));
        method_exchangeImplementations(m1, m2);
    }else if (self.fieldType == JXFiledTypeMenu){
        [textField resignFirstResponder];
        [self.superview endEditing:YES];
    }
}

- (BOOL)empty{
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    if (menuController)
    {
        [UIMenuController sharedMenuController].menuVisible = NO;
    }
    return NO;
}

- (void)myUpdateViewConstraints
{
    [self.titleLabel autoSetDimension:ALDimensionWidth toSize:100];
    [self.titleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft];
    [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    
    [@[self.titleLabel,self.textField,self.imageView] autoAlignViewsToAxis:ALAxisHorizontal];
    
    [self.textField autoPinEdgeToSuperviewEdge:ALEdgeRight];
    [self.textField autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.titleLabel];
//    [self.textField autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.textField autoSetDimension:ALDimensionHeight toSize:40];
    [self.imageView autoPinEdge:ALEdgeRight toEdge:ALEdgeRight ofView:self.textField withOffset:-10];
    [self.imageView autoSetDimensionsToSize:CGSizeMake(10, 10)];
}

#pragma mark - getter
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [UILabel newAutoLayoutView];
        [_titleLabel setFont:[UIFont systemFontOfSize:18]];
        [_titleLabel setTintColor:[UIColor blackColor]];
        [_titleLabel setTextAlignment:NSTextAlignmentCenter];
    }
    return _titleLabel;
}

- (UITextField *)textField
{
    if (!_textField) {
        _textField = [UITextField newAutoLayoutView];
        [_textField setBorderStyle:UITextBorderStyleRoundedRect];
        _textField.delegate = self;
        [_textField setFont:[UIFont systemFontOfSize:16]];
    }
    return _textField;
}

- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [UIImageView newAutoLayoutView];
        UIImage *image = [UIImage imageNamed:@"doc_filter_s"];
        image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [_imageView setTintColor:[UIColor grayColor]];
        [_imageView setImage:image];
        [_imageView setHidden:YES];
    }
    return _imageView;
}

- (UIDatePicker *)datePicker
{
    if (!_datePicker) {
        _datePicker = [[UIDatePicker alloc]init];
        _datePicker.datePickerMode = UIDatePickerModeDate;
        @weakify(self);
        [[_datePicker rac_newDateChannelWithNilValue:nil] subscribeNext:^(NSDate *date) {
            @strongify(self);
            [self setDateStringWith:date];
        }];
    }
    return _datePicker;
}

#pragma mark - gettemethod
- (void)setDateStringWith:(NSDate *)date
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd"]; //yyyy- 年  HH:mm
    NSString *dateString = [formatter stringFromDate:date];
    self.textField.text = dateString;
}

@end
