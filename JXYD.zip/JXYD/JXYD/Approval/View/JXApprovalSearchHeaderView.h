//
//  JXApprovalSearchHeaderView.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/18.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXApprovalSearchHeaderView : UIView
@property (nonatomic,strong) UITextField *textField;
@property (nonatomic,strong) UIButton *searchButton;
@property (nonatomic,strong) UIButton *highSearchButton;
@end
