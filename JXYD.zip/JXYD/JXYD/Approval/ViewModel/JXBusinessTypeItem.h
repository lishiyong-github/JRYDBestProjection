//
//  JXBusinessTypeItem.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/20.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//
#import "JXBusinessProtocol.h"
@interface JXBusinessTypeItem : RETableViewItem
@property (nonatomic,assign) BOOL hideButton;
@property (nonatomic,assign) BOOL hideSelectedButton;
@property (nonatomic,assign) BOOL open;
@property (nonatomic,assign) BOOL selected;
@property (nonatomic,assign) NSInteger level;
@property (nonatomic,copy) void (^clicked)();
- (instancetype)initWithModel:(id<JXBusinessProtocol>)model;
@end
