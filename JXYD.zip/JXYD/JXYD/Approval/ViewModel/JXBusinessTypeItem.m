//
//  JXBusinessTypeItem.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/20.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXBusinessTypeItem.h"

@implementation JXBusinessTypeItem
- (instancetype)initWithModel:(id<JXBusinessProtocol>)model
{
    self = [super init];
    if (self) {
        self.cellIdentifier = @"JXBusinessTypeCell";
        self.name = model.name;
        self.open = model.open;
        RACChannelTo(self,selected) = RACChannelTo(model,selected);
//        self.selected = model.selected;
        self.level = model.level;
    }
    return self;
}
@end
