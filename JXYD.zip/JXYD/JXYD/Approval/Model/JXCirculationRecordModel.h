//
//  JXCirculationRecordModel.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/21.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXBusinessTreeModel.h"

@interface JXCirculationRecordModel : JXBusinessTreeModel

@end
