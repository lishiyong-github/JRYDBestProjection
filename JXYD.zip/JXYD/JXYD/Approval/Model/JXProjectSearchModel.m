//
//  JXProjectSearchModel.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/21.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXProjectSearchModel.h"

@implementation JXProjectSearchModel
- (NSString *)projectNo
{
    return self.wh;
}

- (NSString *)slbh
{
    return self.wh;
}

- (NSString *)typeSearch
{
    return @"1";
}

- (NSString *)wfWorkItemId
{
    return @"";
}

@end
