//
//  JXProjectAreaModel.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/20.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXProjectAreaModel.h"

@implementation JXProjectAreaModel
@synthesize name = _name;

+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"children":@"JXProjectAreaModel"};
}

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID":@"id",
             @"children":@"dictionaryValue"};
}

- (NSString *)name
{
    if (!_name) {
        return _Name;
    }
    return _name;
}
@end
