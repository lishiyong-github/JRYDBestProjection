//
//  JXProjectSearchModel.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/21.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JXProjectProtocol.h"
@interface JXProjectSearchModel : NSObject<JXProjectProtocol>
@property (nonatomic,strong) NSString *projectId;
@property (nonatomic,strong) NSString *businessName;
@property (nonatomic,strong) NSString *blzt;
@property (nonatomic,strong) NSString *wh;
@property (nonatomic,strong) NSString *currentUser;
@property (nonatomic,strong) NSString *bt;

//收文字段
@property (nonatomic,strong) NSString *sfjj;
@property (nonatomic,strong) NSString *lwlx;
@property (nonatomic,strong) NSString *lwdw;
@property (nonatomic,strong) NSString *bwyw;
@property (nonatomic,strong) NSString *swrq;
@property (nonatomic,strong) NSString *fwrq;

//发文字段
@property (nonatomic,strong) NSString *fwwh;
@property (nonatomic,strong) NSString *fwdw;
@property (nonatomic,strong) NSString *ztc;
@property (nonatomic,strong) NSString *fwlx;
@property (nonatomic,strong) NSString *ngks;
@property (nonatomic,strong) NSString *ngr;
@end
