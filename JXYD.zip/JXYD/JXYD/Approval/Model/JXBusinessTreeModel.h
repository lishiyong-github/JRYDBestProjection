//
//  JXBusinessTreeModel.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/20.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JXBusinessProtocol.h"
@interface JXBusinessTreeModel : NSObject<JXBusinessProtocol>
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *isBusinessGroup;
@property (nonatomic,strong) NSString *ID;
@property (nonatomic,strong) NSString *enabled;
@property (nonatomic,strong) NSArray *children;
@property (nonatomic,assign) NSInteger level;
@property (nonatomic,assign) BOOL open;
@property (nonatomic,assign) BOOL selected;
@property (nonatomic,strong) JXBusinessTreeModel *superModel;
@end
