//
//  JXProjectAreaModel.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/20.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JXBusinessTreeModel.h"
@interface JXProjectAreaModel : JXBusinessTreeModel<JXBusinessProtocol>
@property (nonatomic,strong) NSString *SortId;
@property (nonatomic,strong) NSString *Name;


@end
