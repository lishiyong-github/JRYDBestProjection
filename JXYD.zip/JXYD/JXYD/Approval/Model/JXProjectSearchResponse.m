//
//  JXProjectSearchResponse.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/21.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXProjectSearchResponse.h"

@implementation JXProjectSearchResponse
+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"result":@"JXProjectSearchModel"};
}
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"count":@"recoedCount"};
}
@end
