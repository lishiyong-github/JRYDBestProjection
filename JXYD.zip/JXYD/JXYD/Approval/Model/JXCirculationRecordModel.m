//
//  JXCirculationRecordModel.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/21.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXCirculationRecordModel.h"

@implementation JXCirculationRecordModel

+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"children":@"JXCirculationRecordModel"};
}
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"name":@"historydiscrption",
             @"children":@"files"};
}
@end
