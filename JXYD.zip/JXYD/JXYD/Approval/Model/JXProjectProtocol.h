//
//  JXProjectProtocol.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol JXProjectProtocol <NSObject>

@optional
@property (nonatomic,strong) NSString *projectName;
@property (nonatomic,strong) NSString *currentOffice;
@property (nonatomic,strong) NSString *xmbh;//项目编号
@property (nonatomic,strong) NSString *slbh;
@property (nonatomic,strong) NSString *projectId;
@property (nonatomic,strong) NSString *wfWorkItemId;
@property (nonatomic,strong) NSString *projectNo;
@property (nonatomic,strong) NSString *typeSearch;



@end
