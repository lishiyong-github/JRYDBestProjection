//
//  JXCirculationRecordViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/18.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXCirculationRecordViewController.h"
#import "JXCirculationRecordModel.h"
#import "JXBusinessTypeItem.h"
@interface JXCirculationRecordViewController ()
@property (nonatomic,strong) JXCirculationRecordModel *model;
@end

@implementation JXCirculationRecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"传阅记录";
    self.manager[@"JXBusinessTypeItem"] = @"JXBusinessTypeCell";
    [self requestData];
}

- (void)requestData
{
    NSString *url = [JXApiHelper serverAddress];
    NSDictionary *params = @{@"type":@"smartplan",
                             @"action":@"forwardhistory",
                             @"sourceId":self.projectID,
                             @"sourceType":@1,
                             @"forwardType":@0};
    @weakify(self);
    [self postUrl:url param:params success:^(NSDictionary *json) {
        @strongify(self);
        if ([json[@"success"] isEqualToString:@"true"] && [json[@"result"] firstObject]) {
            self.model = [JXCirculationRecordModel mj_objectWithKeyValues:[json[@"result"] firstObject]];
            [self configTableView];
        }else{
            [self showEmptyView];
        }
    } failed:^{
        [self showEmptyView];
    }];
}

- (void)configTableView
{
    //默认展开第一层
    self.model.open = YES;
    
    [self.manager removeAllSections];
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    [section addItemsFromArray:[self getItemsWithTreeModel:self.model]];
    [self.tableView reloadData];
}

- (NSArray *)getItemsWithTreeModel:(id<JXBusinessProtocol>)treeModel
{
    NSMutableArray *items = [NSMutableArray array];
    @weakify(self);
    if (treeModel.children.count) {
        JXBusinessTypeItem *item = [[JXBusinessTypeItem alloc]initWithModel:treeModel];
        item.hideSelectedButton = YES;
        [items addObject:item];
        [item setSelectionHandler:^(JXBusinessTypeItem *item){
            @strongify(self);
            treeModel.open = !treeModel.open;
            [self configTableView];
        }];
        if (treeModel.open) {
            for (id<JXBusinessProtocol>model in treeModel.children) {
                model.level = treeModel.level+1;
                [items addObjectsFromArray:[self getItemsWithTreeModel:model]];
            }
        }
    }else{
        JXBusinessTypeItem *item = [[JXBusinessTypeItem alloc]initWithModel:treeModel];
        item.hideSelectedButton = YES;
        item.level = treeModel.level-1;
        item.hideButton = YES;
        [items addObject:item];
    }
    return items;
}

@end
