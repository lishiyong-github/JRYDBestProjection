//
//  JXApprovalSearchViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/18.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXApprovalSearchViewController.h"
#import "JXApprovalSearchHeaderView.h"
#import "JXApprovalSearchView.h"
#import "JXBusinessTreeModel.h"
#import "JXProjectAreaModel.h"
#import "JXApprovalListReponse.h"
#import "DocumentTableViewCellItem.h"
#import "JXApprovalDetailPageViewController.h"
@interface JXApprovalSearchViewController ()
@property (nonatomic,strong) JXApprovalListReponse *model;
@property (nonatomic,strong) JXApprovalSearchHeaderView *headerView;
@property (nonatomic,strong) JXApprovalSearchView *searchView;
@property (nonatomic,strong) NSLayoutConstraint *searchViewTopConstraints;//20 -320
@property (nonatomic,strong) JXBusinessTreeModel *treeModel;
@property (nonatomic,strong) JXProjectAreaModel *areaModel;
@property (nonatomic,assign) BOOL showHighSearch;
@property (nonatomic,strong) NSString *firstQuery;
@property (nonatomic,strong) NSDictionary *highSearchParam;
@property (nonatomic,strong) dispatch_group_t group;
@end

@implementation JXApprovalSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"项目查询";
    
    [self.view addSubview:self.headerView];
    [self.view addSubview:self.searchView];
    self.searchViewTopConstraints = [self.searchView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:-170];
//    [self.searchView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.view withOffset:-160];
    self.manager[@"DocumentTableViewCellItem"] = @"DocumentTableViewCell";
    [self requestData];
}

- (void)requestData
{
    dispatch_group_t group = dispatch_group_create();
    self.group = group;
    
    dispatch_group_enter(group);
    [self requestBusinessTree];
    
    dispatch_group_enter(group);
    [self requestProjectArea];
    
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        self.headerView.highSearchButton.hidden = NO;
    });
}

- (void)requestBusinessTree
{
    NSString *url = [JXApiHelper serverAddress];
    NSDictionary *params = @{@"type":@"smartplan",
                             @"action":@"GetBusinessTree",
                             @"userId":[MainModel sharedInstances].userID};
    //
    @weakify(self);
    [self postUrl:url param:params success:^(NSDictionary *json) {
        @strongify(self);
        if ([json[@"success"] isEqualToString:@"true"]) {
            dispatch_group_leave(self.group);
            self.treeModel = [JXBusinessTreeModel mj_objectWithKeyValues:json[@"result"]];
            [self.searchView setTreeModel:self.treeModel];
        }
    } failed:^{
        
    }];
}

- (void)requestProjectArea
{
    NSString *url = [JXApiHelper serverAddress];
    NSDictionary *params = @{@"type":@"smartplan",
                             @"action":@"projectArea"};
    //[MainModel sharedInstances].userID
    @weakify(self);
    [self postUrl:url param:params success:^(NSDictionary *json) {
        @strongify(self);
        if ([json[@"success"] isEqualToString:@"true"]) {
            dispatch_group_leave(self.group);
            self.areaModel = [JXProjectAreaModel mj_objectWithKeyValues:json[@"result"]];
            [self.searchView setAreaModel:self.areaModel];
        }
    } failed:^{
        
    }];
}

- (void)configTable
{
    [self.manager removeAllSections];
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    
    //注册item、cell
    @weakify(self);
    //添加item
    for (JXApprovalModel *model in self.model.result) {
        //创建item
        DocumentTableViewCellItem *item = [DocumentTableViewCellItem itemWithTitle:nil accessoryType:UITableViewCellAccessoryNone selectionHandler:^(RETableViewItem *item) {
            [item deselectRowAnimated:YES];
            @strongify(self);
            [self.searchView hideSearchTableView];
            JXApprovalDetailPageViewController *controller = [[JXApprovalDetailPageViewController alloc] init];
            controller.model = model;
            controller.type = @"1";
            controller.title = @"项目详情";
            [self.navigationController pushViewController:controller animated:YES];
             [JXLogManager WriteLog:@"搜索项目详情"  logLevel:@2];
        }];
        item.leftImage = @"eventIcon";
        item.leftUpText = model.projectName;
        item.leftBottomtext = model.xmbh;
        item.rightBottomText = model.hjjs;
        item.cellHeight = 60;
        [section addItem:item];
    }
    [self.tableView reloadData];
}

- (Class)resultClass
{
    return [JXApprovalListReponse class];
}

- (NSDictionary *)getParams
{
    NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithDictionary:@{@"type":@"smartplan",
                                                                                   @"action":@"getadvancequery",
                                                                                   @"pagesize":self.pageSize,
                                                                                   @"pageindex":self.pageIndex}];
    if (!self.showHighSearch) {
        [params addEntriesFromDictionary:@{@"firstQuery":checkNullString(self.firstQuery)}];
    }else{
        [params addEntriesFromDictionary:self.highSearchParam];
    }
    return params;
}


- (void)myUpdateViewConstraints
{
    [self.headerView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
    [self.headerView autoSetDimension:ALDimensionHeight toSize:60];
    
    [self.searchView autoPinEdgeToSuperviewEdge:ALEdgeRight];
    [self.searchView autoPinEdgeToSuperviewEdge:ALEdgeLeft];
    [self.searchView autoSetDimension:ALDimensionHeight toSize:160];
    
    [self.tableView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
    [self.tableView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.searchView withOffset:70];
}

#pragma mark - getter
- (JXApprovalSearchHeaderView *)headerView
{
    if (!_headerView) {
        _headerView = [JXApprovalSearchHeaderView newAutoLayoutView];
        @weakify(self);
        [[_headerView.highSearchButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self.headerView endEditing:YES];
            self.showHighSearch = YES;
            self.searchViewTopConstraints.constant = 10;
            [self animateLayout];
        }];
        
        [[_headerView.searchButton addAction] subscribeNext:^(id x) {
           @strongify(self);
            [self.view endEditing:YES];
            self.firstQuery = self.headerView.textField.text;
            [self beginRefreshing];
        }];
    }
    return _headerView;
}

- (JXApprovalSearchView *)searchView
{
    if (!_searchView) {
        _searchView = [JXApprovalSearchView newAutoLayoutView];
        @weakify(self);
        [[_searchView.highSearchButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            self.showHighSearch = NO;
            self.searchViewTopConstraints.constant = -170;
            //隐藏搜索弹出来的下拉框
            [self.searchView hideSearchTableView];
            //隐藏键盘
            [self.searchView endEditing:YES];
            [self animateLayout];
        }];
        
        [_searchView setSearchBlock:^(NSDictionary *param){
            @strongify(self);
            self.highSearchParam = param;
            [self beginRefreshing];
        }];
    }
    return _searchView;
}

@end
