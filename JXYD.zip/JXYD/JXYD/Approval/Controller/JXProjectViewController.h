//
//  JXProjectViewController.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHRefreshViewController.h"
#import "JXProjectProtocol.h"
@interface JXProjectViewController : SHRefreshViewController
@property (nonatomic,strong) UINavigationController *nav;

@property (nonatomic,strong) UISearchBar  *searchBar;
@property (nonatomic,assign) BOOL          isSearch;
@property (nonatomic,strong) NSString *searchText;
//add cell
- (NSArray *)getItemArray;

/**
 点击某一行的事件处理
 
 @param projectModel JXProjectProtocol
 */
- (void)selectedCellWithProjectModel:(id <JXProjectProtocol>)projectModel;
/**
 开始搜索
 */
- (void)startSearch;
/**
 结束搜索
 */
- (void)endSearch;
@end
