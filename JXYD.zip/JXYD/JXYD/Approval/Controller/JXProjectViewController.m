//
//  JXProjectViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXProjectViewController.h"
#import "DocumentTableViewCellItem.h"
@interface JXProjectViewController ()<UISearchBarDelegate>
@end

@implementation JXProjectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.manager[@"DocumentTableViewCellItem"] = @"DocumentTableViewCell";
    //init search text
    self.searchText = @"";
    @weakify(self);
    [[[[NSNotificationCenter defaultCenter] rac_addObserverForName:SendSuccessNotification object:nil] takeUntil:[self rac_willDeallocSignal]] subscribeNext:^(id x) {
        @strongify(self);
        [self refreshForNotification];
    }];
}

- (void)configTable
{
    [self.manager removeAllSections];
    RETableViewSection *section = [RETableViewSection section];
    //    self.isSearch = YES;
    if (self.isSearch) {
        section.headerHeight = 40;
        section.headerView = self.searchBar;
    }else{
        section.headerView = nil;
        section.headerHeight = 0;
    }
    [self.manager addSection:section];
    
    [section addItemsFromArray:[self getItemArray]];
    [self.tableView reloadData];
}

- (NSArray *)getItemArray
{
    NSMutableArray *items = [NSMutableArray array];
    //注册item、cell
    @weakify(self);
    //添加item
    for (id<JXProjectProtocol> model in self.model.result) {
        //创建item
        DocumentTableViewCellItem *item = [[DocumentTableViewCellItem alloc]initWithModel:model];
        [item setSelectionHandler:^(DocumentTableViewCellItem *item){
            [item deselectRowAnimated:YES];
            @strongify(self);
            [self selectedCellWithProjectModel:model];
        }];
        [items addObject:item];
    }
    return items;
}

- (void)selectedCellWithProjectModel:(id <JXProjectProtocol>)projectModel;
{
    
}

- (void)startSearch
{
    [JXLogManager WriteLog:@"点击搜索" logLevel:@1];
    if (self.isSearch) {
        if (self.searchText.length) {
            self.searchText = @"";
            [self beginRefreshing];
        }
        [self endSearch];
    }else{
        self.isSearch = YES;
        [self.searchBar becomeFirstResponder];
    }
    [self configTable];
}

- (void)endSearch
{
    self.isSearch = NO;
    [self.searchBar resignFirstResponder];
}
#pragma mark - getter
- (UISearchBar *)searchBar
{
    if (!_searchBar) {
        _searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 40)];
        _searchBar.returnKeyType = UIReturnKeySearch;
        _searchBar.delegate = self;
    }
    return _searchBar;
}

- (UINavigationController *)navigationController
{
    return self.nav;
}

#pragma mark - delegate
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    if (![self.searchText isEqualToString:searchBar.text]) {
        [self beginRefreshing];
    }
    self.searchText = searchBar.text;
}

@end
