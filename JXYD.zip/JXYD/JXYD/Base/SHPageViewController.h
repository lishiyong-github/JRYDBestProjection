//
//  SHPageViewController.h
//  GZYD
//
//  Created by shiyong_li on 2017/5/19.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import "MBViewPagerController.h"

@interface SHPageViewController : MBViewPagerController

/**
 requir be overide
 */
- (UIViewController *)viewPager:(MBViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index;
- (NSArray *)titles;
/**
 optional be overide
 */
- (CGFloat)viewPager:(MBViewPagerController *)viewPager valueForOption:(ViewPagerOption)option withDefault:(CGFloat)value;
- (void)viewPager:(MBViewPagerController *)viewPager didChangeTabToIndex:(NSUInteger)index;
@end
