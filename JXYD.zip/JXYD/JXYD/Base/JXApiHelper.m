//
//  JXApiHelper.m
//  GZYD
//
//  Created by shiyong_li on 2017/5/25.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import "JXApiHelper.h"
@implementation JXApiHelper
+ (NSString *)getPGYID
{
#if DEBUG
    return @"9be8b43e3da9949262de0c37753772a8";//com.dist.JXYD
#endif
    return @"36e3aa88898dbf1f546da93b53c75b5c";//com.dist.JXYDtest
}
+ (NSString *)serviceApi
{
#if DEBUG
    return @"http://58.246.138.178:8040";//公司外网
#endif
     return @"http://10.73.1.50";
}

+ (NSString *)validateApi
{
#if DEBUG
    return @"http://192.168.1.36:8084/guangzhou";//公司外网
#endif
    return @"http://10.73.1.50:8080/jiaxing";
}
+ (NSString *)serverAddress{
    return [NSString stringWithFormat:@"%@/jxyd/ServiceProvider.ashx?",[self serviceApi]];
}
/*
 wlf
 */
+ (NSString *) loginServeAddress {
    return [NSString stringWithFormat:@"%@/jxyd/service/Login.ashx?",[self serviceApi]];
}

+ (NSString *)apiValidateDevice
{
    return [NSString stringWithFormat:@"%@/mobile/app-mobileDeviceValidate.action?",[self validateApi]];
}

+ (NSString *)apiDeviceRegister
{
    return [NSString stringWithFormat:@"%@/mobile/app-mobileDeviceReg.action?",[self validateApi]];
}

+ (NSString *)apiWriteLog
{
    return [NSString stringWithFormat:@"%@/mobile/app-writeLog.action?",[self validateApi]];
}
@end
