//
//  JXApiHelper.h
//  GZYD
//
//  Created by shiyong_li on 2017/5/25.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JXApiHelper : NSObject
+ (NSString *)getPGYID;

+ (NSString *)serverAddress;
+ (NSString *) loginServeAddress;

//validate
+ (NSString *)apiValidateDevice;
+ (NSString *)apiDeviceRegister;
+ (NSString *)apiWriteLog;
@end
