//
//  NBNetWorkViewController.h
//  nbOneMap
//
//  Created by shiyong_li on 17/3/28.
//  Copyright © 2017年 dist. All rights reserved.
//

#import "SHBaseViewController.h"

typedef void(^RequestSuccessBlock)(NSDictionary *json);
typedef void(^RequestFailedBlock)();//RACTuple *result

static NSString *kMessageString = @"messageString";
static NSString *kHideIndicator = @"hideIndicator";

@interface SHNetWorkViewController : SHBaseViewController
/**
 网络请求
 
 @param param 参数包含messageString 则显示：messageString 默认显示：努力加载中……
 */
- (void)postUrl:(NSString *)url param:(NSDictionary *)param success:(RequestSuccessBlock)success failed:(RequestFailedBlock)failed;
- (void)postUrl:(NSString *)url param:(NSDictionary *)param success:(RequestSuccessBlock)success failed:(RequestFailedBlock)failed showIndicator:(BOOL)showIndicator;
- (void)postUrl:(NSString *)url success:(RequestSuccessBlock)success failed:(RequestFailedBlock)failed;
//- (void)postUrl:(NSString *)url action:(NSString *)action param:(NSDictionary *)param constructingBodyWithBlock:(void (^)(id <AFMultipartFormData> formData))block success:(RequestSuccessBlock)success failed:(RequestFailedBlock)failed;//@csh
+ (NSDictionary *)getEncodeparamsWithAction:(NSString *)action param:(NSDictionary *)param;
@end
