//
//  SHBaseTableViewCell.m
//  GZDB
//
//  Created by csh on 2017/8/10.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHBaseTableViewCell.h"
#import "UIView+Line.h"

@implementation SHBaseTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(nullable NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.detailLabel];
        [self setNeedsUpdateConstraints];
        if (![self hideBottomLine]) {
            [self addBottomLine];
        }
    }
    return self;
}

- (BOOL)hideBottomLine
{
    return NO;
}

- (void)myUpdateConstraints
{
    [self.titleLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.contentView];
    [self.titleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
//    [UIView autoSetPriority:UILayoutPriorityRequired forConstraints:^{
//        [self.titleLabel setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
//    }];
    [self.detailLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.titleLabel withOffset:10];
    [self.detailLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.detailLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.titleLabel];
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [UILabel newAutoLayoutView];
        [_titleLabel setTextAlignment:NSTextAlignmentLeft];
        [_titleLabel setTextColor:[UIColor blackColor]];
        [_titleLabel setFont:[UIFont systemFontOfSize:15]];
    }
    return _titleLabel;
}

- (UILabel *)detailLabel
{
    if (!_detailLabel) {
        _detailLabel = [UILabel newAutoLayoutView];
        [_detailLabel setTextColor:[UIColor blackColor]];
        [_detailLabel setFont:[UIFont systemFontOfSize:15]];
        _detailLabel.numberOfLines = 0;
    }
    return _detailLabel;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
