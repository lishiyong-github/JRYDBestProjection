//
//  SHListResponseModel.m
//  JXYD
//
//  Created by shiyong_li on 2017/8/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHListResponseModel.h"

@implementation SHListResponseModel

@end
