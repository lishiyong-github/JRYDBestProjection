//
//  NBNetWorkViewController.m
//  nbOneMap
//
//  Created by shiyong_li on 17/3/28.
//  Copyright © 2017年 dist. All rights reserved.
//

#import "SHNetWorkViewController.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"


static NSString *toString(id object){
    return [NSString stringWithFormat: @"%@", object];
}

static NSString *urlEncode(id object) {
    NSString *string = toString(object);
    return [string stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
}


@implementation NSDictionary (UrlEncoding)

- (NSString *)urlEncodedString{
    NSMutableArray *parts = [NSMutableArray array];
    for (id key in self) {
        id value = [self objectForKey: key];
        NSString *part = [NSString stringWithFormat: @"%@=%@", key, value];
        [parts addObject: part];
    }
    return [parts componentsJoinedByString: @"&"];
}

@end
@interface SHNetWorkViewController ()

@property(nonatomic, assign)BOOL bActionRequst;
@property(nonatomic, assign) BOOL loginError;
@property(nonatomic, assign) BOOL reLoginSuccess;

- (void)getDataWithURL:(NSString *)strURL parameters:(NSDictionary *)parameters;
- (void)dealWithSuccessResponse:(NSHTTPURLResponse *)response andResult:(id)json;
- (void)dealWithFailurResponse:(NSHTTPURLResponse *)response andError:(NSError *)error;

@end

@implementation SHNetWorkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)showMsg:(NSString *)msg
{
    onMainThread(
                 //                 [MessageLabel showMessage:msg];
//                 [MBProgressHUD showSuccess:msg toView:nil];
                 )
}
- (NSString *)messageString{
    return @"努力加载中…";
}

- (NSDictionary *)getEncodeparamsWithAction:(NSString *)action param:(NSDictionary *)param
{
    return [SHNetWorkViewController getEncodeparamsWithAction:action param:param];
}

- (void)postUrl:(NSString *)url success:(RequestSuccessBlock)success failed:(RequestFailedBlock)failed
{
    [self postUrl:url param:nil success:success failed:failed];
}

- (void)postUrl:(NSString *)url param:(NSDictionary *)param success:(RequestSuccessBlock)success failed:(RequestFailedBlock)failed
{
    [self postUrl:url param:param success:success failed:failed showIndicator:NO];
}

- (void)postUrl:(NSString *)url param:(NSDictionary *)param success:(RequestSuccessBlock)success failed:(RequestFailedBlock)failed showIndicator:(BOOL)showIndicator
{
    if (showIndicator) {
        [MBProgressHUD showMessage:@"加载中……" toView:self.view];
    }
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]init];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain",@"text/xml", nil];
    NSLog(@"qwe*********url:\n%@\n %@",url,param);
    @weakify(self);
    __block RequestSuccessBlock successBlock = success;
    [manager POST:url parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        @strongify(self);
        SHBaseResponseModel *response = [SHBaseResponseModel mj_objectWithKeyValues:responseObject];
        if (response.success) {
            successBlock(responseObject);
            //            NSLog(@"***********************success*******************\n %@",responseObject);
        }else{
            successBlock(responseObject);//@csh
            //            NSLog(@"**********************failed********************\n %@",responseObject);
        }
        [self hideHUD];
        successBlock = nil;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        @strongify(self);
        [self hideHUD];
        NSLog(@"url %@,param %@******************************************\n %@",url,param,[error description]);
    }];
}

- (void)hideHUD{
//    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    [MBProgressHUD hideHUDForView:self.view];
}

@end
