//
//  SHListResponseModel.h
//  JXYD
//
//  Created by shiyong_li on 2017/8/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHListResponseModel : NSObject
//@property (nonatomic,strong) NSString *message;
@property (nonatomic,strong) NSMutableArray *result;
@property (nonatomic,strong) NSString  *resultDisposeBox;//任务处理回退权限//@csh
@property (nonatomic,strong) NSString  *resultHelposeBox;//任务协办回退权限
@property (nonatomic,strong) NSNumber *total;
@property (nonatomic,strong) NSString *count;
//@property (nonatomic,strong) NSString *state;
//@property (nonatomic,strong) NSString *sessionState;
@end
