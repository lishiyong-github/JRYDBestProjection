//
//  SHBaseViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHBaseViewController.h"
#import "JXEmptyView.h"
@interface SHBaseViewController ()
@property (nonatomic,strong) JXEmptyView *emptyView;
@end

@implementation SHBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    //    self.automaticallyAdjustsScrollViewInsets = NO;
    self.extendedLayoutIncludesOpaqueBars = YES;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    // Do any additional setup after loading the view.
    [self.view addSubview:self.emptyView];
    
    [self.emptyView autoCenterInSuperview];
    [self.emptyView autoSetDimensionsToSize:CGSizeMake(196, 129)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (JXEmptyView *)emptyView
{
    if (!_emptyView) {
        _emptyView = [JXEmptyView newAutoLayoutView];
        [_emptyView setHidden:YES];
    }
    return _emptyView;
}

- (void)showEmptyView
{
    [self.view bringSubviewToFront:self.emptyView];
    [self.emptyView setHidden:NO];
}

- (void)hideEmptyView
{
    [self.emptyView setHidden:YES];
}

#pragma mark - animation
- (void)animateLayout
{
    [self.view setNeedsUpdateConstraints];
    [self.view updateConstraintsIfNeeded];
    [UIView animateWithDuration:0.3 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        [self.view layoutIfNeeded]; // this is what actually causes the views to animate to their new layout
    } completion:^(BOOL finished) {
        
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
