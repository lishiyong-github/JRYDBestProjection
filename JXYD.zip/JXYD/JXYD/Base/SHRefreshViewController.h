//
//  SHRefreshViewController.h
//  JXYD
//
//  Created by shiyong_li on 2017/8/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTableViewController.h"
#import "SHListResponseModel.h"

@interface SHRefreshViewController : JXTableViewController
@property (nonatomic,strong) SHListResponseModel *model;
@property (nonatomic,strong) Class resultClass;

@property (nonatomic,strong) NSNumber *pageIndex;
@property (nonatomic,strong) NSNumber *pageSize;

/**
 *  Override this block when you wan't to change the default refresh handler
 */
@property (nonatomic, copy) void (^pullToRefreshHandler)(void);
/**
 *  Override this when you wan't to change the default loadmore handler
 */
@property (nonatomic, copy) void (^pullToLoadMoreHandler)(void);

/**
 should be override custom reload tableview
 */
- (void)configTable;
- (void)refreshForNotification;

/**
 method below should be overrided by subclass

 */
- (NSString *)getRequestURL;
- (NSDictionary *)getParams;
//@csh
- (NSString *)getList;
- (void)setRefresh:(BOOL)refresh;
- (void)beginRefreshing;
@end
