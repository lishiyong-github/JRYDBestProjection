//
//  SHRefreshViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/8/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHRefreshViewController.h"
#import <MJRefresh.h>

@interface SHRefreshViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation SHRefreshViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.pageSize = @20;
    self.pageIndex = @0;
    [self setPullToRefresh];
    [self beginRefreshing];
    // Do any additional setup after loading the view.
}

#pragma mark - 设置上拉、下拉刷新 block
- (void)beginRefreshing
{
    [self.tableView.mj_header beginRefreshing];
}
- (void)setLoadMoreOn:(BOOL)on
{
    if (on) {
        [self setPullToLoadMore];
    }else{
        self.tableView.mj_footer = nil;
    }
}
- (void)setPullToRefresh
{
    @weakify(self);
    if (self.pullToRefreshHandler) {
        self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            @strongify(self);
            self.pullToRefreshHandler();
        }];
    }else{
        self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            @strongify(self);
            self.pageIndex = @0;
            [self refresh:NO];
        }];
    }
}

- (void)refreshForNotification
{
     if (self.pullToRefreshHandler) {
         self.pullToRefreshHandler();
     }else{
         self.pageIndex = @0;
         [self refresh:NO];
     }
}

- (void)setPullToLoadMore
{
    @weakify(self);
    if (self.pullToLoadMoreHandler) {
        self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            @strongify(self);
            self.pullToRefreshHandler();
        }];
    }else{
        self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            @strongify(self);
            [self refresh:YES];
        }];
    }
}

#pragma mark - 网络请求
- (void)refresh:(BOOL)loadMore
{
    [self hideEmptyView];
    //@csh
    NSString *url;
    url = [self getRequestURL];
    if (!url.length) {
        return;
    }
    @weakify(self);
    [self postUrl:url param:[self getParams] success:^(NSDictionary *json) {
        @strongify(self);
        NSLog(@"******************************************\n %@",json);
        SHListResponseModel *response = [self.resultClass mj_objectWithKeyValues:json];
        if (!loadMore) {
            self.model = response;
            if (!response.result.count) {
                [self showEmptyView];
            }
            [self.tableView.mj_header endRefreshing];
        }else{
            self.pageIndex = @(self.pageIndex.integerValue +1);
            [self.model.result addObjectsFromArray:response.result];
            [self.tableView.mj_footer endRefreshing];
        }
        BOOL loadMore = (self.pageIndex.integerValue+1) * self.pageSize.integerValue < response.count.integerValue;
        [self setLoadMoreOn:loadMore];
        [self configTable];
    } failed:^{
        
    } showIndicator:YES];
}

- (void)configTable
{
    [self.tableView reloadData];
}

- (NSString *)getRequestURL
{
    return [JXApiHelper serverAddress];
}

- (NSString *)getList
{
    return @"";
}

- (NSDictionary *)getParams
{
    return nil;
}

- (void)setRefresh:(BOOL)refresh
{
    self.tableView.mj_header = nil;
}


@end
