//
//  JXTableViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/21.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTableViewController.h"

@interface JXTableViewController ()

@end

@implementation JXTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.manager[@"RETableViewItem"] = @"RETableViewCell";
    [self.view addSubview:self.tableView];
    self.manager = [[RETableViewManager alloc]initWithTableView:self.tableView];
}

- (void)myUpdateViewConstraints
{
    [self.tableView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
        _tableView.tableFooterView = [UIView new];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}

@end
