//
//  SHBaseTableViewCell.h
//  GZDB
//
//  Created by csh on 2017/8/10.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHBaseTableViewCell : UITableViewCell

@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UILabel *detailLabel;
- (BOOL)hideBottomLine;

@end
