//
//  SHPageViewController.m
//  GZYD
//
//  Created by shiyong_li on 2017/5/19.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import "SHPageViewController.h"

@interface SHPageViewController ()<ViewPagerDelegate,ViewPagerDataSource>
@property (nonatomic, strong) NSMutableArray *arrTabView;
@property (nonatomic, strong) NSArray *arrTitle;
@property (nonatomic, assign) NSInteger pageIndex;
@end

@implementation SHPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.dataSource = self;
    self.delegate = self;
    self.pageIndex = -1;
    [self reloadData];
}
#pragma mark - getter & setter
- (NSArray *)arrTitle
{
    if (!_arrTitle) {
        _arrTitle = [self titles];
    }
    return _arrTitle;
}

- (NSArray *)titles
{
    return @[];
}
- (NSMutableArray *)arrTabView
{
    if (!_arrTabView) {
        _arrTabView = [NSMutableArray array];
        NSUInteger number = [self numberOfTabsForViewPager:self];
        for (int i=0; i<number; i++) {
            UILabel *label = [UILabel new];
            label.backgroundColor = [UIColor clearColor];
            label.font = [UIFont systemFontOfSize:15.0];
            label.textAlignment = NSTextAlignmentCenter;
            label.textColor = GRAYCOLOR_DARK;
            label.autoresizingMask = UIViewAutoresizingFlexibleWidth;
            [_arrTabView addObject:label];
        }
    }
    return _arrTabView;
}

#pragma mark -ViewPagerDataSource
- (UIViewController *)viewPager:(MBViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index
{
    return nil;
}

- (NSUInteger)numberOfTabsForViewPager:(MBViewPagerController *)viewPager
{
    return self.arrTitle.count;
}

- (UIView *)viewPager:(MBViewPagerController *)viewPager viewForTabAtIndex:(NSUInteger)index
{
    UILabel *label = [self.arrTabView objectAtIndex:index];
    label.text = self.arrTitle[index];
    [label sizeToFit];
    return label;
}

#pragma mark -ViewPagerDelegate
- (void)viewPager:(MBViewPagerController *)viewPager didChangeTabToIndex:(NSUInteger)index
{
    if (self.pageIndex != index) {
        if (self.pageIndex >=0 ) {
            UILabel *selLabel = [self.arrTabView objectAtIndex:self.pageIndex];
            [selLabel setTextColor:GRAYCOLOR_DARK];
        }
        if (index < self.arrTabView.count) {
            UILabel *label = [self.arrTabView objectAtIndex:index];
            [label setTextColor:BLUECOLOR];
        }
    }
    self.pageIndex = index;
}
- (CGFloat)viewPager:(MBViewPagerController *)viewPager valueForOption:(ViewPagerOption)option withDefault:(CGFloat)value
{
    switch (option) {
        case ViewPagerOptionTabLocation:
            return 1.0f;
            break;
        case ViewPagerOptionTabWidth:
            if ([self numberOfTabsForViewPager:viewPager]<=5) {
                return [UIScreen mainScreen].bounds.size.width/[self numberOfTabsForViewPager:viewPager];
            }else{
                return 90.0f;
            }
            break;
        case ViewPagerOptionTabHeight:
            return 45;
            break;
        default:
            break;
    }
    
    return value;
}
- (UIColor *)viewPager:(MBViewPagerController *)viewPager colorForComponent:(ViewPagerComponent)component withDefault:(UIColor *)color
{
    switch (component) {
        case ViewPagerIndicator:
            return BLUECOLOR;
        case ViewPagerTabsView:
            return [UIColor whiteColor];
        case ViewPagerContent:
            return [UIColor whiteColor];
        default:
            break;
    }
    return color;
}
@end
