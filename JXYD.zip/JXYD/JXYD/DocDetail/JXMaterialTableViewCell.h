//
//  JXProjectDetailTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXMaterialTableViewItem.h"

@interface JXMaterialTableViewCell : RETableViewCell
@property (nonatomic,strong) UIImageView *leftImageView;
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) JXMaterialTableViewItem *item;
@property (nonatomic,strong) NSLayoutConstraint *leftSpaceConstraints;
@end
