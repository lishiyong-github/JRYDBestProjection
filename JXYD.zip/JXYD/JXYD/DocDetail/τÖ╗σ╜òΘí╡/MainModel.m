//
//  LoginModel.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/4.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "MainModel.h"

@implementation MainModel
+(instancetype) sharedInstances{
    static MainModel *_sharedInstances = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (_sharedInstances == nil) {
            _sharedInstances = [[MainModel alloc] init];
        }
    });
    return _sharedInstances;
}
@end
