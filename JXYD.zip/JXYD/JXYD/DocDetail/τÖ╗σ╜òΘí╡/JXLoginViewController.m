//
//  RootViewController1.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/24.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXLoginViewController.h"
#import "JXLoginView.h"
#import "JXTabBarController.h"
#import "NewsViewController.h"
#import "MainModel.h"
#import <LSYKeyBoardManager.h>
#import <PgySDK/PgyManager.h>
#import <PgyUpdate/PgyUpdateManager.h>

//device validate
#import "JXLoginViewController+DeviceValidate.h"

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

@interface JXLoginViewController ()
@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) UIImageView  *backgroundImage;
@property (nonatomic,strong) JXLoginView *loginView;
@property (nonatomic,strong) NSTimer *timer;

@end

@implementation JXLoginViewController
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.loginView endEditing:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.scrollView];
    //设置动画
    [self addAnimation];
    
    [self.scrollView addSubview:self.backgroundImage];
    
    //添加LoginView
    [self.view addSubview:self.loginView];
    
    [self startValidate];
    
    //add keyboard
    [LSYKeyBoardManager keyboadWithObserverView:self.loginView];
    
    [[PgyUpdateManager sharedPgyManager] checkUpdate];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.timer invalidate];
}

- (JXLoginView *)loginView {
    if (!_loginView) {
        _loginView = [JXLoginView newAutoLayoutView];
        _loginView.backgroundColor = [UIColor whiteColor];
        _loginView.layer.cornerRadius = 8.0f;
        _loginView.alpha = 0.9;

        @weakify(self);
        [self.loginView.clickSignal subscribeNext:^(RACTuple *value) {
            @strongify(self);
            //调接口
            [self loginWithUserName:value.first passWord:value.second];
        }];
    }
    return _loginView;
}
- (void)loginWithUserName:(NSString *)userName passWord:(NSString *)passWord {
    NSDictionary *parama = @{
                             @"name":userName,
                             @"pwd":passWord
                             };
    @weakify(self);
    NSString *url = [JXApiHelper loginServeAddress];//@"http://58.246.138.178:8040/jxyd/service/Login.ashx?";
    [MBProgressHUD showMessage:@"正在登录……" toView:self.view];
    [self postUrl:url  param:parama success:^(NSDictionary *json) {
        @strongify(self);
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        if ([json[@"result"] isKindOfClass:[NSNull class]]) {
            [MBProgressHUD showMessage:@"登录失败" toView:self.view];
            return ;
        }
        MainModel *loginModel = [MainModel sharedInstances];
        loginModel.user = json[@"result"][@"LoginName"];
        loginModel.userID = json[@"result"][@"Id"];
        
        
        if ([[json objectForKey:@"success"] integerValue]==1) {//登录成功
            [self loginSuccess];
        }else{
            [MBProgressHUD showError:@"用户名或密码错误" toView:self.view];
        }
    } failed:^{
        @strongify(self);
        [MBProgressHUD hideHUDForView:self.view];
    }];
}

- (void)loginSuccess
{
    CATransition *transition = [CATransition animation];
    transition.duration = 1.8;
    transition.type = @"rippleEffect";
    transition.subtype = kCATransitionFromRight;
    [self.scrollView.layer addAnimation:transition forKey:nil];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (self.presentingViewController) {
            [[NSNotificationCenter defaultCenter] postNotificationName:SendSuccessNotification object:nil];
            [self dismissViewControllerAnimated:NO completion:nil];
        }else{
            [UIApplication sharedApplication].keyWindow.rootViewController = [JXTabBarController controllerWithCenterItemAndTitles];
        }
    });
    [JXLogManager WriteLog:@"登陆成功"  logLevel:@1];
}
#pragma mark - 背景动画
- (void)addAnimation {
//添加定时器每隔0.1触发一次
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(scrollAnimation) userInfo:nil repeats:YES];
}

- (void)scrollAnimation{
    static BOOL isLeft = YES;
    if (isLeft) {
        [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x+4.0, self.scrollView.contentOffset.y) animated:YES];
        if (self.scrollView.contentOffset.x >= self.scrollView.contentSize.width - SCREEN_WIDTH - 10.0){
            isLeft = NO;
        }
    }else{
        [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x-4.0, self.scrollView.contentOffset.y) animated:YES];
        if (self.scrollView.contentOffset.x<=10) {
            isLeft = YES;
        }
    }
}

- (UIScrollView*)scrollView {

    if (!_scrollView) {
        _scrollView = [UIScrollView newAutoLayoutView];
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.contentOffset = CGPointMake(0, 0);//设置scrollveiw的起始点
        _scrollView.userInteractionEnabled = NO;
        _scrollView.bounces = NO;
        _scrollView.contentSize = CGSizeMake(SCREEN_WIDTH+100, SCREEN_HEIGHT);//scrollview的可滚动的范围
    }
    return _scrollView;
}

- (UIImageView *)backgroundImage {
    if (!_backgroundImage) {
        _backgroundImage = [UIImageView newAutoLayoutView];
        _backgroundImage.image = [UIImage imageNamed:@"loginImage"];
    }
    return _backgroundImage;
}

- (void)myUpdateViewConstraints{
    //自动布局scrollview与父视图的位置关系
    [self.scrollView autoSetDimensionsToSize:CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT)];
    //添加完图片 设置其与父视图的相对位置
    [self.scrollView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0 relation:NSLayoutRelationEqual];
    [self.scrollView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0 relation:NSLayoutRelationEqual];
    [self.scrollView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [self.scrollView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0] ;
    //自动布局ImageView在scrollVoew的位置
    [self.backgroundImage autoPinEdgesToSuperviewEdges];
    
    //布局LoginView与父视图的位置
    [self.loginView autoSetDimensionsToSize:CGSizeMake(400, 400)];
    [self.loginView autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.loginView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
}

@end
