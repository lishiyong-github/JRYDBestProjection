//
//  JXLoginViewController+DeviceValidate.m
//  JXYD
//
//  Created by shiyong_li on 2017/10/16.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXLoginViewController+DeviceValidate.h"
#import "DeviceInfo.h"
#import "DistLoginValidate.h"
#import "UIView+Message.h"
@implementation JXLoginViewController (DeviceValidate)

//// 0:待审核 1.正常 2.挂失 3.禁用 -1.新设备
- (void)startValidate
{
    NSString *deviceNumber = [DeviceInfo deviceUUID];
    NSString *url = [JXApiHelper apiValidateDevice];
    NSDictionary *params = @{@"deviceNumber":deviceNumber};
    @weakify(self);
    [self postUrl:url param:params success:^(NSDictionary *json) {
        @strongify(self);
        NSString *result = json[@"result"];
        if ([result isEqualToString:@"-1"]) {
            [self addValidateView];
        }else if ([result isEqualToString:@"1"]){//do nothing
//            [self addValidateView];
        }else{
            [self addValidateViewAndShowState:YES];
        }
    } failed:nil];
}

- (void)addValidateView
{
    [self addValidateViewAndShowState:NO];
}

- (void)addValidateViewAndShowState:(BOOL)show
{
    @weakify(self);
    DistLoginValidate *validateView = [[DistLoginValidate alloc]initWithFrame:self.view.bounds];
    [validateView showInView:self.view animated:YES finish:^(NSString *text1, NSString *text2) {
        @strongify(self);
        [[self validateWithValue:text1 value2:text2] subscribeNext:^(id x) {
            [validateView showDeviceCheckState];
        }];
    }];
    if (show) {
        [validateView showDeviceCheckState];
    }
}

- (RACSignal *)validateWithValue:(NSString *)value1 value2:(NSString *)value2
{
    @weakify(self);
    return [RACSignal startEagerlyWithScheduler:[RACScheduler scheduler] block:^(id<RACSubscriber> subscriber) {
        @strongify(self);
        NSString *deviceNumber = [DeviceInfo deviceUUID];
        NSString *system = @"IOS";
        NSString *hardware = SCREEN_WIDTH > 736 ? @"Pad" : @"Phone" ;
        NSString *displaySize = [NSString stringWithFormat:@"%.1f*%.1f",SCREEN_WIDTH,SCREEN_HEIGHT];
        NSString *deviceFactory = @"apple";
        NSString *cpuSeriesNum = @"";
        NSString *phoneModel = [DeviceInfo deviceModel];
        NSString *systemVersion = [DeviceInfo deviceSystemVersion];
        NSString *userName = value1;
        NSString *phoneNumber = value2;
        
        if (!value1.length || !value2.length) {
            [UIView showMessage:@"请输入验证信息"];
            return;
        } else {
            // 设备注册
            NSDictionary *param = @{@"remark":@"remark",@"deviceNumber":deviceNumber,@"name":userName,@"system":system,@"hardware":hardware,@"cpuSeriesNum":cpuSeriesNum,@"phoneModel":phoneModel,@"displaySize":displaySize,@"deviceFactory":deviceFactory,@"systemVersion":systemVersion,@"phoneNumber":phoneNumber};
            //        NSString *str = [param urlEncodedString];
            NSString *url = [JXApiHelper apiDeviceRegister];
            [self postUrl:url param:param success:^(NSDictionary *json) {
                if (![json[@"result"] boolValue]) {
                    [UIView showMessage:@"设备申请提交成功"];
                    [subscriber sendNext:@1];
                }else {
                    [UIView showMessage:@"设备申请提交失败"];
                }
                [subscriber sendCompleted];
            } failed:^{
                [subscriber sendCompleted];
            }];
            
        }
    }];
}
@end
