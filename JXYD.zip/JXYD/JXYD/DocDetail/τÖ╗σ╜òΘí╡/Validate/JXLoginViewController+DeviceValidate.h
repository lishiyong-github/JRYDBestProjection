//
//  JXLoginViewController+DeviceValidate.h
//  JXYD
//
//  Created by shiyong_li on 2017/10/16.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXLoginViewController.h"

@interface JXLoginViewController (DeviceValidate)
- (void)startValidate;
@end
