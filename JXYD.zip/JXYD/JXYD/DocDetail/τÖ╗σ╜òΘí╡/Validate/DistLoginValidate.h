//
//  DistLoginValidate.h
//  TJYD
//
//  Created by 吴定如 on 17/4/27.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef  void (^FinishBlock)(NSString *text1,NSString *text2);
@interface DistLoginValidate : UIView
@property (nonatomic,copy) FinishBlock finishBlock;
// 初始化视图
- (void)showInView:(UIView *)superView animated:(BOOL)animated finish:(FinishBlock)finish;
// 加载/退出动画
- (void)fadeIn;
- (void)fadeOut;

- (void)screenRotation;
- (void)showDeviceCheckState;

@end
