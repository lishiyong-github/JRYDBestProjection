//
//  JXLogManager.h
//  JXYD
//
//  Created by shiyong_li on 2017/10/17.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JXLogManager : NSObject
+ (void)WriteLog:(NSString *)logType logLevel:(NSNumber *)logLevel;
@end
