//
//  JXLogManager.m
//  JXYD
//
//  Created by shiyong_li on 2017/10/17.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXLogManager.h"
#import "DeviceInfo.h"
@implementation JXLogManager
+ (void)WriteLog:(NSString *)logType logLevel:(NSNumber *)logLevel{
    // 写入日志
    NSString *deviceNumber = [DeviceInfo deviceUUID];
    NSString *userName = [UserDefaults objectForKey:kUserName];
    NSString * Level = [NSString stringWithFormat:@"LEVEL_%@",logLevel];
    NSDictionary *param = @{@"deviceNumber":deviceNumber,@"logType":logType,@"logContent":@"",@"userName":userName,@"appName":@"嘉兴移动办公",@"logLevel":Level};
    
    // Post
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]init];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain",@"text/xml", nil];
    NSString *url = [JXApiHelper apiWriteLog];
    NSLog(@"qwe*********url:\n%@\n %@",url,param);
    [manager POST:url parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if ([responseObject[@"state"] boolValue]) {
            NSLog(@"****************%@**************************\n %@",logType,@"日志写入成功");
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"url %@,param %@*********************日志写入失败*********************\n %@",url,param,[error description]);
    }];
}
@end
