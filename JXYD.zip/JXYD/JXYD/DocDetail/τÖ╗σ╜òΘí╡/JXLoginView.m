//
//  LoginView.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/24.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXLoginView.h"
#import "UIButton+Style.h"

@interface JXLoginView()<UITextFieldDelegate,UIAlertViewDelegate>
@property (nonatomic,strong) UIImageView *upImageView;
@property (nonatomic,strong) UIImageView *userNameImageView;
@property (nonatomic,strong) UITextField *usernameTextField;
@property (nonatomic,strong) UIView      *usernameLine;

@property (nonatomic,strong) UIImageView *passwordImageView;
@property (nonatomic,strong) UITextField *passwordTextField;
@property (nonatomic,strong) UIView      *passwodLine;
@property (nonatomic,strong) UIButton    *loginButton;

@property (nonatomic,strong) UIButton    *memoryPassword;
@property (nonatomic,strong) UIButton    *offLineLogin;
@property (nonatomic,strong) UIButton    *autoLogin;

@end

@implementation JXLoginView

- (instancetype) init{
    if (self = [super init]) {
        [self addSubview:self.upImageView];
        [self addSubview:self.userNameImageView];
        [self addSubview:self.usernameTextField];
        [self addSubview:self.usernameLine];
        [self addSubview:self.passwordImageView];
        [self addSubview:self.passwordTextField];
        [self addSubview:self.passwodLine];
        [self addSubview:self.memoryPassword];
        [self addSubview:self.offLineLogin];
        [self addSubview:self.autoLogin];
        [self addSubview:self.loginButton];
        [self setNeedsUpdateConstraints];
        [self reloadLocalData];
        
        @weakify(self);
        [[[self.usernameTextField rac_textSignal] distinctUntilChanged] subscribeNext:^(id x) {
            @strongify(self);
            self.loginButton.enabled = [x length];
        }];
    }
    return self;
}

#pragma mark --reload Local Data
- (void) reloadLocalData {
    NSString *userName = [[NSUserDefaults standardUserDefaults] objectForKey:kUserName];
    NSString *passWord = [[NSUserDefaults standardUserDefaults] objectForKey:kPassWord];
    NSString *autoLogin = [[NSUserDefaults standardUserDefaults] objectForKey:kAutoLogin];

    [self.usernameTextField setText:userName];
    [self.passwordTextField setText:passWord];

    if ([autoLogin boolValue] || passWord.length) {
        self.memoryPassword.selected = YES;
    }
    self.autoLogin.selected = [autoLogin boolValue];
}

- (void) saveLocalData {
    [[NSUserDefaults standardUserDefaults] setValue:self.usernameTextField.text forKey:kUserName];
    if (self.memoryPassword.selected || self.autoLogin.selected) {
        [[NSUserDefaults standardUserDefaults] setValue:self.passwordTextField.text forKey:kPassWord];
    }else{
        [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:kPassWord];
    }
    if (self.autoLogin.selected) {
        [[NSUserDefaults standardUserDefaults] setValue:@1 forKey:kAutoLogin];
    }else{
        [[NSUserDefaults standardUserDefaults] setValue:@0 forKey:kAutoLogin];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (UIButton *)loginButton
{
    if (!_loginButton) {
        _loginButton = [UIButton newAutoLayoutView];
        _loginButton.backgroundColor = [UIColor colorWithRed:0.2863 green:0.7059 blue:0.9686 alpha:1];
        [_loginButton setTitle:@"确定" forState:UIControlStateNormal];
        _loginButton.titleLabel.font = [UIFont systemFontOfSize:18.0f];
        [_loginButton.layer setCornerRadius:6.0f];
        [_loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_loginButton setBackgroundImage:[UIImage imageWithColor:[UIColor lightGrayColor]] forState:UIControlStateDisabled];
        @weakify(self);
        [[_loginButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self login];
        }];
    }
    return _loginButton;
}

- (void) login {
    [self endEditing:YES];
    [self saveLocalData];
    
    [self loginClick];
}

//待替换的提示框
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [alertView dismissWithClickedButtonIndex:buttonIndex animated:NO];
    }
}

- (RACSubject *)clickSignal
{
    if (!_clickSignal) {
        _clickSignal = [RACSubject subject];
    }
    return _clickSignal;
}

- (UIButton *) autoLogin {
    if (!_autoLogin) {
        _autoLogin = [UIButton newAutoLayoutView];
        [_autoLogin setNormalImage:@"unselect" selectedImage:@"select"];
        [_autoLogin setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 70)];
        [_autoLogin setImage:[UIImage imageNamed:@"unselect"] forState:UIControlStateNormal];
        [_autoLogin setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        [_autoLogin setTitle:@"自动登录"forState:UIControlStateNormal];
        [_autoLogin setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _autoLogin.titleLabel.font = [UIFont systemFontOfSize:12];
        @weakify(self);
        [[_autoLogin addAction] subscribeNext:^(id x) {
            @strongify(self);
            self.autoLogin.selected = !self.autoLogin.selected;
            if (self.autoLogin.selected) {
                self.memoryPassword.selected = YES;
            }
        }];
    }
    return _autoLogin;
}

- (void) loginClick {
    [self.clickSignal sendNext:RACTuplePack(self.usernameTextField.text,self.passwordTextField.text)];
}

- (UIButton *) offLineLogin {
    if (!_offLineLogin) {
        _offLineLogin = [UIButton newAutoLayoutView];
        [_offLineLogin setNormalImage:@"unselect" selectedImage:@"select"];
        [_offLineLogin setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 70)];
        [_offLineLogin setImage:[UIImage imageNamed:@"unselect"] forState:UIControlStateNormal];
        [_offLineLogin setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        [_offLineLogin setTitle:@"离线登录" forState:UIControlStateNormal];
        [_offLineLogin setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _offLineLogin.titleLabel.font = [UIFont systemFontOfSize:12];
        @weakify(self);
        [[_offLineLogin addAction] subscribeNext:^(id x) {
            @strongify(self);
            self.offLineLogin.selected = !self.offLineLogin.selected;
        }];
    }
    return _offLineLogin;
}

- (UIButton *) memoryPassword {
    if (!_memoryPassword) {
        _memoryPassword = [UIButton newAutoLayoutView];
        [_memoryPassword setNormalImage:@"unselect" selectedImage:@"select"];
        [_memoryPassword setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 70)];
        [_memoryPassword setImage:[UIImage imageNamed:@"unselect"] forState:UIControlStateNormal];
        [_memoryPassword setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        [_memoryPassword setTitle:@"记住密码" forState:UIControlStateNormal];
        [_memoryPassword setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _memoryPassword.titleLabel.font = [UIFont systemFontOfSize:12];
        @weakify(self);
        [[_memoryPassword addAction] subscribeNext:^(id x) {
            @strongify(self);
            self.memoryPassword.selected = !self.memoryPassword.selected;
        }];
    }
    return _memoryPassword;
}


- (UIView *) passwodLine{
    if (!_passwodLine) {
        _passwodLine = [UIView newAutoLayoutView];
        _passwodLine.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    }
    return _passwodLine;
}

- (UITextField *) passwordTextField {
    if (!_passwordTextField) {
        _passwordTextField = [UITextField newAutoLayoutView];
        _passwordTextField.secureTextEntry = YES;
    }
    return _passwordTextField;
}

- (UIImageView *)passwordImageView{
    if (!_passwordImageView) {
        _passwordImageView = [UIImageView newAutoLayoutView];
        _passwordImageView.image = [UIImage imageNamed:@"passWord"];
    }
    return _passwordImageView;
}

- (UIView *)usernameLine{
    if (!_usernameLine) {
        _usernameLine = [UIView newAutoLayoutView];
//        _usernameLine.backgroundColor = [UIColor colorWithRed:0.8392 green:0.8471 blue:0.8431 alpha:1];
        _usernameLine.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    }
    return _usernameLine;
}


//添加最上方的图片
- (UIImageView *) upImageView {
    if (!_upImageView) {
        _upImageView = [UIImageView newAutoLayoutView];
        _upImageView.image = [UIImage imageNamed:@"icon"];
    }
    return _upImageView;
}

//添加用户名称
- (UIImageView *) userNameImageView{
    if (!_userNameImageView) {
        _userNameImageView = [UIImageView newAutoLayoutView];
        _userNameImageView.image = [UIImage imageNamed:@"userName"];
    }
    return _userNameImageView;
}

//添加usernameTextField
- (UITextField *)usernameTextField{
    if (!_usernameTextField) {
        _usernameTextField = [UITextField newAutoLayoutView];
//        _usernameTextField.backgroundColor = [UIColor redColor];
    }
    return _usernameTextField;
}

- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self endEditing:YES];
}

- (void) myUpdateViewConstraints{
    CGFloat leftSpace = 35;
    //布局upImageView与父视图的位置
    [self.upImageView autoSetDimensionsToSize:CGSizeMake(130, 130)];
    [self.upImageView autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.upImageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
    
    //布局usernameImageView与父视图的位置
    [self.userNameImageView autoSetDimensionsToSize:CGSizeMake(20, 20)];
    [self.userNameImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:leftSpace];
    [self.userNameImageView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.upImageView withOffset:10];
    
    //布局usernameTextField与父视图的位置
    //    [self.usernameTextField autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.userNameImageView withOffset:0];
    [self.usernameTextField autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.userNameImageView withOffset:15];
    [self.usernameTextField autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:20];
    [self.usernameTextField autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.userNameImageView];
    
    //布局usernameLine与父视图的位置
    [self.usernameLine autoSetDimension:ALDimensionHeight toSize:1];
    [self.usernameLine autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.userNameImageView withOffset:-2];
    [self.usernameLine autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:leftSpace];
    [self.usernameLine autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.usernameTextField withOffset:5];
    
    //布局passwordImageView与父视图的位置
    [self.passwordImageView autoSetDimensionsToSize:CGSizeMake(20, 20)];
    [self.passwordImageView autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.userNameImageView];
    [self.passwordImageView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.userNameImageView withOffset:30];
    
    //布局passwordTextField与父视图的位置
    [self.passwordTextField autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.usernameTextField];
    [self.passwordTextField autoPinEdge:ALEdgeRight toEdge:ALEdgeRight ofView:self.usernameTextField];
    [self.passwordTextField autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.passwordImageView];
    
    //布局passwordLine与父视图的位置
    //    [self.passwodLine autoSetDimension:ALDimensionHeight toSize:1];
    [self.passwodLine autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.usernameLine];
    [self.passwodLine autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.usernameLine];
    [self.passwodLine autoPinEdge:ALEdgeRight toEdge:ALEdgeRight ofView:self.usernameLine];
    
    [self.passwodLine autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.passwordTextField withOffset:5];
    
    //布局memoryPassword与父视图的位置
    [self.memoryPassword autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.userNameImageView];
    [self.memoryPassword autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.passwodLine withOffset:25];
    [self.memoryPassword autoSetDimensionsToSize:CGSizeMake(90, 20)];
    
    [@[self.memoryPassword,self.offLineLogin,self.autoLogin] autoAlignViewsToEdge:ALEdgeTop];
    //布局离线登录与父视图的位置
    [self.offLineLogin autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.offLineLogin autoSetDimensionsToSize:CGSizeMake(90, 20)];
    
    //布局自动登录与父视图的相对位置
    [self.autoLogin autoPinEdge:ALEdgeRight toEdge:ALEdgeRight ofView:self.usernameLine];
    [self.autoLogin autoSetDimensionsToSize:CGSizeMake(90, 20)];
    
    [self.loginButton autoSetDimension:ALDimensionHeight toSize:40];
    [self.loginButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:30];
    [self.loginButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:leftSpace];
    [self.loginButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:leftSpace];
    
    _usernameTextField.delegate = self;
    _passwordTextField.delegate = self;
}

#pragma mark - delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ([textField isEqual:self.usernameTextField]){
        [textField resignFirstResponder];
        [self.passwordTextField becomeFirstResponder];
        return NO;
    }
    return YES;
}

@end
