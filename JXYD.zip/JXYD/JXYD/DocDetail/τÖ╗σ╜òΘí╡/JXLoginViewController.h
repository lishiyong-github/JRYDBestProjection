//
//  RootViewController1.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/24.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kUser @"user"
#define kID  @"ID"
@interface JXLoginViewController : SHNetWorkViewController

@end
