//
//  LoginView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/24.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
//#define kUserName @"userName"
//#define kPassWord @"passWord"
//#define kAutoLogin @"autoLogin"
@interface JXLoginView : UIView

@property (nonatomic,strong) RACSubject *clickSignal;

@end
