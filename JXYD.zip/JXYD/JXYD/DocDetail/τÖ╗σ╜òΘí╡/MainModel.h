//
//  LoginModel.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/4.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainModel : NSObject

@property (nonatomic,strong) NSString *user;
@property (nonatomic,strong) NSString *userID;
@property (nonatomic,strong) NSString *wfWorkId;
+(instancetype) sharedInstances;

@end
