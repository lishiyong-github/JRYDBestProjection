//
//  JXProjectDetailTableViewItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//


@interface JXMaterialTableViewItem : RETableViewItem
@property (nonatomic,strong) NSString *leftText;
//@property (nonatomic,strong) NSString *leftImage;
@property (nonatomic,assign) CGFloat leftConstraint;
@property (nonatomic,assign) NSInteger level;
@property (nonatomic,strong) NSString *fileType;
- (instancetype) initWithModel;
- (void)setDefaultFileType;
@end
