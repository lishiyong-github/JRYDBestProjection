//
//  JXDocumentPageViewController.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHPageViewController.h"
#import "JXProjectProtocol.h"
@interface JXApprovalDetailPageViewController : SHPageViewController
@property (nonatomic,strong) id<JXProjectProtocol> model;
@property (nonatomic,strong) NSString *type;//0-在办 1-已办 2-收文 3-发文 4阅文

@end
