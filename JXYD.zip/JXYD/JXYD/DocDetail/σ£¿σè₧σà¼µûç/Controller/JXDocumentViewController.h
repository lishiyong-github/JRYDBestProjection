//
//  DocumentViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JXProjectViewController.h"
typedef NS_ENUM(NSInteger,JXDocumentType){
    JXDocumentTypeSW=0,//收文
    JXDocumentTypeFW,//发文
    JXDocumentTypeYW//越文
};
@interface JXDocumentViewController : JXProjectViewController
@property (nonatomic,assign) JXDocumentType type;

@end
