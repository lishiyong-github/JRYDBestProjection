//
//  DocumentViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXDocumentViewController.h"
#import "DocumentTableViewCell.h"
#import "DocumentTableViewCellItem.h"
//controller
#import "DocDetailViewController.h"
#import "JXDocumentDetailPageViewController.h"
#import "JXApprovalDetailPageViewController.h"
//model
#import "JXDocumentResponse.h"
#import "MBProgressHUD+MJ.h"

@interface JXDocumentViewController ()
@property (nonatomic,strong) JXDocumentResponse *model;

@end

@implementation JXDocumentViewController
@dynamic model;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //set placeholder
    
    self.searchBar.placeholder = [NSString stringWithFormat:@"请输入%@名称或%@编号",[self getTitle],[self getTitle]];
}

- (NSString *)getTitle
{
    NSString *title;
    if (self.type == JXDocumentTypeSW) {
        title = @"收文";
    }else if (self.type == JXDocumentTypeFW){
        title = @"发文";
    }else{
        title = @"阅文";
    }
    return title;
}

- (void)selectedCellWithProjectModel:(id <JXProjectProtocol>)projectModel
{
//    JXDocumentModel *model = (JXDocumentModel *)projectModel;
    JXApprovalDetailPageViewController *controller = [[JXApprovalDetailPageViewController alloc]init];
    controller.model = projectModel;
    controller.hidesBottomBarWhenPushed = YES;
    controller.title = [self getTitle];
    controller.type = [@(self.type+2) stringValue];
    [self.navigationController pushViewController:controller animated:YES];
    
    [JXLogManager WriteLog:[self getTitle]  logLevel:@1];
}

#pragma mark - override
- (Class)resultClass
{
    return [JXDocumentResponse class];
}

- (NSDictionary *)getParams
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"type":@"smartplan",
                                                                                  @"user":[MainModel sharedInstances].userID,
                                                                                  @"pagesize":self.pageSize,
                                                                                  @"pageindex":self.pageIndex
                                                                                  }];
    if (self.type == JXDocumentTypeSW) {
//        NSDictionary *param = @{
//                                @"action":@"cyqylist",
//                                @"resourceType":@1,
//                                @"isLoadToMe":@"true",
//                                @"querystring":self.searchText
//                                };
//        [params addEntriesFromDictionary:param];
    }else if (self.type == JXDocumentTypeSW) {
        
    }else if (self.type == JXDocumentTypeYW) {//阅文查询
        /*
    forwardType:0表示传阅，1表示签阅
    resourceType:0表示项目，1表示公文
    isFinish:true表示已经阅毕（已完成），false表示还未阅毕（未完成）
    isLoadToMe:true表示别人传给我的，false表示我传给别人的
         */
//        NSDictionary *param = @{
//                                @"action":@"cyqylist",
//                                @"forwardType":@0,
//                                @"resourceType":@1,
//                                @"isLoadToMe":@"true",
//                                @"querystring":self.searchText
//                                };
//        [params addEntriesFromDictionary:param];
//        return params;
    }
    NSDictionary *param = @{@"type":@"smartplan",
                            @"action":@"GetProcessingDocumentList",
                            @"user":[MainModel sharedInstances].userID,
                            @"pagesize":self.pageSize,
                            @"pageindex":self.pageIndex,
                            @"sftype":@(self.type),
                            @"querystring":self.searchText
                            };
    return param;
}
@end
