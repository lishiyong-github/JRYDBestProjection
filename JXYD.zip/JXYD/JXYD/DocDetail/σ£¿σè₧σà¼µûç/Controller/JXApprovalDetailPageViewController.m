//
//  JXDocumentPageViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXApprovalDetailPageViewController.h"
#import "UIButton+Style.h"
#import "JXPragramView.h"
//controlelr
#import "DocDetailViewController.h"
#import "PTreeViewController.h"
#import "ListViewController.h"
#import "JXMaterialViewController.h"
#import "JXLogViewController.h"
#import "JXDocumentDetailViewController.h"
#import "JXCirculationRecordViewController.h"

@interface JXApprovalDetailPageViewController ()
@property (nonatomic,strong) UIButton *customBtn;
@end

@implementation JXApprovalDetailPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.title = @"项目详情";
    
    self.customBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 25, 25)];
    [self.customBtn setBackgroundImage:[UIImage imageNamed:@"item_more"] forState:UIControlStateNormal];
    @weakify(self);
    [[self.customBtn addAction] subscribeNext:^(id x) {
       @strongify(self);
        [self clicked];
    }];
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithCustomView:self.customBtn];
    [self.navigationItem setRightBarButtonItem:rightBarButton];
}

- (void) clicked {
    //创建一个View
//    [[UIApplication sharedApplication].keyWindow addSubview:self.pragramView];
    @weakify(self);
    [JXPragramView showFinishBlock:^(NSInteger index) {
        @strongify(self);
        if (index == 0) {
            NSLog(@"******************************************项目日志");
            JXLogViewController *controller = [[JXLogViewController alloc] init];
            controller.projectID = self.model.projectId;
            if (self.type.integerValue == 4) {
                controller.projectID = self.model.wfWorkItemId;
            }
            [self.navigationController pushViewController:controller animated:YES];
            
        }else if (index == 1){
            NSLog(@"******************************************项目树");
            PTreeViewController *controller = [[PTreeViewController alloc] init];
            controller.slbh = self.model.slbh;
            [self.navigationController pushViewController:controller animated:YES];
        }else if (index == 2){
            NSLog(@"******************************************项目表单");
            ListViewController *controller = [[ListViewController alloc] init];
            controller.projectID = self.model.projectId;
            if (self.type.integerValue == 4) {
                controller.projectID = self.model.wfWorkItemId;
            }
            [self.navigationController pushViewController:controller animated:YES];
        }else{
            JXCirculationRecordViewController *controller = [[JXCirculationRecordViewController alloc]init];
            controller.projectID = self.model.wfWorkItemId;
            [self.navigationController pushViewController:controller animated:YES];
        }
    } record:self.type.integerValue == 4];
}

- (NSArray *)titles
{
    if (self.type.integerValue <2) {//审批
        return @[@"项目信息",@"项目材料"];
    }
    return @[@"公文信息",@"材料清单"];
}

- (UIViewController *)viewPager:(MBViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index
{
    if (index == 0) {
        JXDocumentDetailViewController *controller;
        if (self.type.integerValue <2) {//审批
            controller = (id)[[DocDetailViewController alloc]init];
        }else{
            controller = [[JXDocumentDetailViewController alloc]init];
        }
        controller.model = self.model;
        controller.nav = self.navigationController;
        controller.type = self.type;
        return controller;
    }else{
        JXMaterialViewController *controller = [[JXMaterialViewController alloc]init];
        controller.slbh = self.model.slbh;
        controller.nav = self.navigationController;
        return controller;
    }
}

@end
