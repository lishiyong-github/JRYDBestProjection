//
//  JXApprovalListReponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/1.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHListResponseModel.h"
#import "JXProjectProtocol.h"

@interface JXApprovalListReponse : SHListResponseModel
//@property (nonatomic,strong) NSArray *result;
@end

@interface JXApprovalModel : NSObject<JXProjectProtocol>
@property (nonatomic,strong) NSString *projectName;
@property (nonatomic,strong) NSString *xmbh;//BG201702683
@property (nonatomic,strong) NSString *currentOffice;//局办公室
@property (nonatomic,strong) NSString *projectId;
@property (nonatomic,strong) NSString *slbh;

@property (nonatomic,strong) NSString *activityName;//分发
@property (nonatomic,strong) NSString *address;//否
@property (nonatomic,strong) NSString *business;//行政收文
@property (nonatomic,strong) NSString *currentUser;//陈燕红
@property (nonatomic,strong) NSString *flowLeftTime;//超期21天2.1小时
@property (nonatomic,strong) NSString *flowTime;
@property (nonatomic,strong) NSString *hjjs;//在办
@property (nonatomic,strong) NSString *theoryEndTime;
@property (nonatomic,strong) NSString *time;//"2017-08-22 20:51:35
@property (nonatomic,strong) NSString *wfWorkItemId;//8dba1114f3c445a79c503209bbbcecd5
@property (nonatomic,strong) NSString *wfptid;//6c3fd6f180b9454c855387b0cd7dd569
@property (nonatomic,strong) NSString *ID;

@end
