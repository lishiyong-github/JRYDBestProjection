//
//  JXApprovalListReponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/1.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXApprovalListReponse.h"

@implementation JXApprovalListReponse
+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"result":@"JXApprovalModel"};
}

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"count":@"recoedCount"};
}
@end


@implementation JXApprovalModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}

- (NSString *)projectId
{
    if (!_projectId && _ID) {
        return _ID;
    }
    return _projectId;
}
@end
