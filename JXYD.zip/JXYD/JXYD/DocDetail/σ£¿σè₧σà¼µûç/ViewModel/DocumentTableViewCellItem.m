//
//  DocumentTableViewCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DocumentTableViewCellItem.h"

@implementation DocumentTableViewCellItem

- (instancetype) initWithModel:(id<JXProjectProtocol>) model;
{
    if (self = [super init]) {
        self.leftImage = @"eventIcon";
        self.leftUpText = model.projectName;
        self.leftBottomtext = model.xmbh;
        self.rightBottomText = model.currentOffice;
        self.cellHeight = 60;
    }
    return self;
}

@end
