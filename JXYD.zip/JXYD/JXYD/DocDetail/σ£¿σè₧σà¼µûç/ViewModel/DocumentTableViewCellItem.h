//
//  DocumentTableViewCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewItem.h"
#import "JXProjectProtocol.h"
@interface DocumentTableViewCellItem : RETableViewItem
@property (nonatomic,strong) NSString *leftImage;
@property (nonatomic,strong) NSString *leftUpText;
@property (nonatomic,strong) NSString *leftBottomtext;
@property (nonatomic,strong) NSString *rightBottomText;
- (instancetype) initWithModel:(id<JXProjectProtocol>) model;
@end
