//
//  DocumentTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewCell.h"
#import "DocumentTableViewCellItem.h"
@interface DocumentTableViewCell : RETableViewCell
@property (nonatomic,strong) UIImageView *leftImageView;
@property (nonatomic,strong) UILabel *leftUpLabel;
@property (nonatomic,strong) UILabel *leftBottomLabel;
@property (nonatomic,strong) UILabel *rightBottomLabel;
@property (nonatomic,strong) DocumentTableViewCellItem *item;
@end
