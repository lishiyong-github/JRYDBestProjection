//
//  JXPragramView.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXPragramView.h"
#import "UIButton+Style.h"
#import "JXLogViewController.h"

@interface JXPragramView()
@property (nonatomic,strong) UIButton *journalButton;//日志
@property (nonatomic,strong) UIButton *treeButton;
@property (nonatomic,strong) UIButton *formButton;
@property (nonatomic,strong) UIView *buttonView;
@property (nonatomic,strong) UIImageView *triangleImage;
@property (nonatomic,strong) UIButton *recordButton;//传阅记录
@property (nonatomic,assign) BOOL record;
@end
@implementation JXPragramView
- (instancetype) initWithRecord:(BOOL)record {
    if (self = [super init]) {
        self.record = record;
        [self addSubview:self.buttonView];
        [self setBackgroundColor:[[UIColor blackColor] colorWithAlphaComponent:0.3]];
        if (!record) {
            [self.recordButton setHidden:YES];
        }
    }
    return self;
}

+ (void)showFinishBlock:(Clicked)clicked
{
    [self showFinishBlock:clicked record:NO];
}

+ (void)showFinishBlock:(Clicked)clicked record:(BOOL)record
{
    JXPragramView *view = [[JXPragramView alloc]initWithRecord:record];
    [[UIApplication sharedApplication].keyWindow addSubview:view];
    view.clicked = clicked;
    [view autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
}

- (UIView *) buttonView {
    if (!_buttonView) {
        _buttonView = [UIView newAutoLayoutView];
        _buttonView.backgroundColor = [UIColor clearColor];
        [_buttonView addSubview:self.triangleImage];
        [_buttonView addSubview:self.journalButton];
        [_buttonView addSubview:self.treeButton];
        [_buttonView addSubview:self.formButton];
        [_buttonView addSubview:self.recordButton];
    }
    return _buttonView;
}

- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self removeFromSuperview];
}

- (UIImageView *) triangleImage {
    if (!_triangleImage) {
        _triangleImage = [UIImageView newAutoLayoutView];
        _triangleImage.image = [UIImage imageNamed:@"triangle"];
    }
    return _triangleImage;
}

- (RACSubject *)clickSignal
{
    if (!_clickSignal) {
        _clickSignal = [RACSubject subject];
    }
    return _clickSignal;
}

- (UIButton *) journalButton {
    if (!_journalButton) {
        _journalButton = [UIButton newAutoLayoutView];
        [_journalButton setImageEdgeInsets:UIEdgeInsetsMake(5, 0, 5, 80)];
        [_journalButton setImage:[UIImage imageNamed:@"dots"] forState:UIControlStateNormal];
        [_journalButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        _journalButton.titleLabel.textAlignment = NSTextAlignmentLeft;
        [_journalButton setTitle:@"项目日志" forState:UIControlStateNormal];
        [_journalButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _journalButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [_journalButton setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal];
        @weakify(self);
        [[_journalButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self removeFromSuperview];
            self.clicked(0);
        }];
    }
    return _journalButton;
}

- (UIButton *) treeButton {
    if (!_treeButton) {
        _treeButton = [UIButton newAutoLayoutView];
        [_treeButton setImageEdgeInsets:UIEdgeInsetsMake(5, 0, 5, 80)];
        [_treeButton setImage:[UIImage imageNamed:@"dots"] forState:UIControlStateNormal];
        [_treeButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -30, 0, 0)];
        _treeButton.titleLabel.textAlignment = NSTextAlignmentLeft;
        [_treeButton setTitle:@"项目树" forState:UIControlStateNormal];
        [_treeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _treeButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [_treeButton setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal];
        @weakify(self);
        [[_treeButton addAction] subscribeNext:^(id x){
            @strongify(self);
            [self removeFromSuperview];
            self.clicked(1);
        }];
    }
    return _treeButton;
}

- (UIButton *) formButton {
    if (!_formButton) {
        _formButton = [UIButton newAutoLayoutView];
        [_formButton setImageEdgeInsets:UIEdgeInsetsMake(5, 0, 5, 80)];
        [_formButton setImage:[UIImage imageNamed:@"dots"] forState:UIControlStateNormal];
        [_formButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        _formButton.titleLabel.textAlignment = NSTextAlignmentLeft;
        [_formButton setTitle:@"项目表单" forState:UIControlStateNormal];
        [_formButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _formButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [_formButton setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal];
        @weakify(self);
        [[_formButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self removeFromSuperview];
            self.clicked(2);
        }];
    }
    return _formButton;
}

- (UIButton *) recordButton {
    if (!_recordButton) {
        _recordButton = [UIButton newAutoLayoutView];
        [_recordButton setImageEdgeInsets:UIEdgeInsetsMake(5, 0, 5, 80)];
        [_recordButton setImage:[UIImage imageNamed:@"dots"] forState:UIControlStateNormal];
        [_recordButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
        _recordButton.titleLabel.textAlignment = NSTextAlignmentLeft;
        [_recordButton setTitle:@"传阅记录" forState:UIControlStateNormal];
        [_recordButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _recordButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [_recordButton setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal];
        @weakify(self);
        [[_recordButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self removeFromSuperview];
            self.clicked(3);
        }];
    }
    return _recordButton;
}

- (void) myUpdateViewConstraints {    
    //布局
    [self.triangleImage autoSetDimensionsToSize:CGSizeMake(20, 16)];
    [self.triangleImage autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.triangleImage autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:-15];
    
    [self.buttonView autoSetDimensionsToSize:CGSizeMake(100, 120)];
    [self.buttonView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:80];
    [self.buttonView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    
    [@[self.journalButton,self.formButton,self.treeButton,self.recordButton] autoSetViewsDimension:ALDimensionHeight toSize:30];
    [@[self.journalButton,self.formButton,self.treeButton,self.recordButton] autoAlignViewsToEdge:ALEdgeLeft];
    [@[self.journalButton,self.formButton,self.treeButton,self.recordButton] autoAlignViewsToEdge:ALEdgeRight];
    [self.journalButton autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
    
    [self.treeButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.journalButton];
    [self.formButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.treeButton];
    [self.recordButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.formButton];
    
}
@end
