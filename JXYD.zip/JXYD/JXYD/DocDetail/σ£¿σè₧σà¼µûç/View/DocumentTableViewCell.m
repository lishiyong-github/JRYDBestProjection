//
//  DocumentTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DocumentTableViewCell.h"
#import "UIView+Line.h"
@implementation DocumentTableViewCell
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftImageView];
        [self.contentView addSubview:self.leftUpLabel];
        [self.contentView addSubview:self.leftBottomLabel];
        [self.contentView addSubview:self.rightBottomLabel];
        [self.contentView addBottomLine];
    }
    return self;
}

- (void) cellWillAppear {
    self.leftBottomLabel.text = self.item.leftBottomtext;
    self.leftImageView.image = [UIImage imageNamed:self.item.leftImage];
    self.leftUpLabel.text = self.item.leftUpText;
    self.rightBottomLabel.text = self.item.rightBottomText;
}

- (UIImageView *) leftImageView {
    if (!_leftImageView) {
        _leftImageView = [UIImageView newAutoLayoutView];
//        _leftImageView.backgroundColor = [UIColor redColor];
    }
    return _leftImageView;
}

- (UILabel *) leftUpLabel {
    if (!_leftUpLabel) {
        _leftUpLabel = [UILabel newAutoLayoutView];
        [_leftUpLabel setFont:[UIFont systemFontOfSize:16]];
    }
    return _leftUpLabel;
}

- (UILabel *) leftBottomLabel {
    if (!_leftBottomLabel) {
        _leftBottomLabel = [UILabel newAutoLayoutView];
        [_leftBottomLabel setFont:[UIFont systemFontOfSize:10]];
    }
    return _leftBottomLabel;
}

- (UILabel *) rightBottomLabel {
    if (!_rightBottomLabel) {
        _rightBottomLabel = [UILabel newAutoLayoutView];
        [_rightBottomLabel setFont:[UIFont systemFontOfSize:10]];
        [_rightBottomLabel setTextColor:[UIColor colorWithRed:40.0/255 green:160.0/255 blue:244.0/255 alpha:1.0]];
    }
    return _rightBottomLabel;
}

- (void) myUpdateViewConstraints {
    //布局leftImageVeiw与父视图的位置
    [self.leftImageView autoSetDimensionsToSize:CGSizeMake(20, 20)];
    [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    
    //布局leftUpLabel与父视图的位置
    [self.leftUpLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
    [self.leftUpLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:45];
    [self.leftUpLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    
    //布局leftBottom与父视图的相对位置
    [self.leftBottomLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];
    [self.leftBottomLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:45];

    //布局rightBottomLabel与父视图的相对位置
    [self.rightBottomLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];
    [self.rightBottomLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:5];
    
    
}

@end
