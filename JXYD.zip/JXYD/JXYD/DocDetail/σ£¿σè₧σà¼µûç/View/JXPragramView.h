//
//  JXPragramView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^Clicked)(NSInteger index);
@interface JXPragramView : UIView

@property (nonatomic,strong) RACSubject *clickSignal;
@property (nonatomic,copy) Clicked clicked;
+ (void)showFinishBlock:(Clicked)clicked;
//添加传阅记录
+ (void)showFinishBlock:(Clicked)clicked record:(BOOL)record;
@end
