//
//  PTreeTableViewResponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXResponse.h"
//#import "PTreeItemListResponse.h"

@interface PTreeTableViewResponse : JXResponse
@property (nonatomic,strong) NSArray *result;
@end

@interface PTreeModel : NSObject
@property (nonatomic,strong) NSString *group;
@property (nonatomic,strong) NSString *groupid;
@property (nonatomic,strong) NSArray *items;
@property (nonatomic,assign) BOOL close;
@end

@interface ItemModel : NSObject
@property (nonatomic,strong) NSString *name;
@end

