//
//  JXJournalResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXJournalResponse.h"

@implementation JXJournalResponse

@end
