//
//  JXProjectDetailViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXMaterialViewController.h"
#import "JXMaterialTableViewItem.h"
#import "JXMaterialTableViewCell.h"
#import "JXMaterialTableViewResponse.h"
#import "JXMaterialHeaderView.h"

@interface JXMaterialViewController ()
@property (nonatomic,strong) JXMaterialTableViewResponse *response;
@property (nonatomic,strong) JXMaterialHeaderView *customHeaderView;
@end

@implementation JXMaterialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"项目材料";
    
    //添加TableView
    
    //添加manager
    [self addManager];
    [self requestData];
}

- (void) requestData {
    if (!self.slbh) {
        [self showEmptyView];
        return;
    }
    //请求数据
    NSDictionary *parama =  @{@"type":@"smartplan",
                              @"action":@"materials",
                              @"slbh":self.slbh,
                              @"isFilter":@"true"};
    
    @weakify(self);
    [self postUrl:[JXApiHelper serverAddress]  param:parama success:^(NSDictionary *json) {
        @strongify(self);
        self.response = [JXMaterialTableViewResponse mj_objectWithKeyValues:json];
        if (self.response.result.count) {
            [self hideEmptyView];
        }else{
            [self showEmptyView];
        }
        [self configTable];
    } failed:^{
        @strongify(self);
        [self showEmptyView];
        NSLog(@"****项目材料请求失败！");
    } showIndicator:YES];
}

- (void) configTable {
    [self.manager removeAllSections];
    //添加item
    @weakify(self);
    for (JXMaterialModel *model in self.response.result) {
        [self.response.result count];
        RETableViewSection *section = [RETableViewSection section];
        JXMaterialHeaderView *headerView = [self getSectionHeaderView];
        NSString *appendString = [NSString stringWithFormat:@"%@(%ld)",model.Name,[model.Children count]];
        [headerView.leftLabel setText:appendString];
        [headerView setClicked:^{
            @strongify(self);
            model.open = !model.open;
            [self configTable];
        }];
        [section setHeaderView:headerView];
        if (model.open) {
            for (JXMaterialModel *materialModel in model.Children) {
                materialModel.Level = [@(model.Level.integerValue+1) stringValue];
                [section addItemsFromArray:[self getItemsWith:materialModel]];
            }
        }
        [self.manager addSection:section];
    }
    [self.tableView reloadData];
}

- (NSArray *)getItemsWith:(JXMaterialModel *)materialModel
{
    NSMutableArray *items = [NSMutableArray array];
    @weakify(self);
    if (materialModel.Children.count || !materialModel.Extension.length) {//文件夹
        //add folder item
        JXMaterialTableViewItem *item = [[JXMaterialTableViewItem alloc] init];
        NSString *appendString = [NSString stringWithFormat:@"%@(%ld)",materialModel.Name,[materialModel.Children count]];
        item.leftText = appendString;
        item.level = materialModel.Level.integerValue;
        [item setDefaultFileType];
        [item setSelectionHandler:^(id x){
            @strongify(self);
            materialModel.open = !materialModel.open;
            [self configTable];
        }];
        [items addObject:item];
        if (materialModel.open) {
            for (JXMaterialModel *subMaterialModel in materialModel.Children) {
                subMaterialModel.Level = [@(materialModel.Level.integerValue+1) stringValue];
                [items addObjectsFromArray:[self getItemsWith:subMaterialModel]];
            }
        }
    }else{
        JXMaterialTableViewItem *item = [[JXMaterialTableViewItem alloc] init];
        item.leftText = materialModel.Name;
        item.level = materialModel.Level.integerValue;
        [items addObject:item];
        [item setSelectionHandler:^(JXMaterialTableViewItem *item){
            @strongify(self);
            [item deselectRowAnimated:YES];
            NSString *url = [JXApiHelper serverAddress];
            NSDictionary *param = @{@"type":@"smartplan",
                                    @"action":@"downloadMaterial",
                                    @"fileId":materialModel.Id};
            url = [url stringByAppendingString:[param urlEncodedString]];
            [self.nav openFileWithName:materialModel.fileName path:url materialID:materialModel.Id local:NO];
        }];
    }
    return items;
}

- (JXMaterialHeaderView *) getSectionHeaderView
{
    return [[JXMaterialHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
}

- (JXMaterialHeaderView *) customHeaderView
{
    if (!_customHeaderView) {
        _customHeaderView = [[JXMaterialHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
        @weakify(self);
        [self.customHeaderView setClicked:^{
            @strongify(self);
            [self configTable];
        }];
    }
    return _customHeaderView;
}

- (void) addManager {
    self.manager[@"JXMaterialTableViewItem"] = @"JXMaterialTableViewCell";
}
@end
