//
//  PTreeTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "PTreeTableViewCell.h"
#import "UIView+Line.h"

@implementation PTreeTableViewCell
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftImageView];
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addBottomLine];
    }
    return self;
}

- (void) cellWillAppear {
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    self.leftLabel.text = self.item.leftText;
    self.leftImageView.image = [UIImage imageNamed:self.item.leftImage];
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
        [_leftLabel setFont:[UIFont systemFontOfSize:12]];
    }
    return _leftLabel;
}

- (UIImageView *) leftImageView {
    if (!_leftImageView) {
        _leftImageView = [UIImageView newAutoLayoutView];
    }
    return _leftImageView;
}

- (void) myUpdateViewConstraints {
    //布局leftImageView
    [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.leftImageView autoSetDimensionsToSize:CGSizeMake(24, 24)];
    
    //布局leftLabel
    [self.leftLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftImageView withOffset:10];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];
}


@end
