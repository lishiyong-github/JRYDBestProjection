//
//  JXJournalTableViewItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//


@interface JXJournalTableViewItem : RETableViewItem
@property (nonatomic,strong) NSString *imageName;
@property (nonatomic,strong) NSString *timeText;
@property (nonatomic,strong) NSString *fromText;
@property (nonatomic,strong) NSString *toText;
@property (nonatomic,strong) NSString *rightText;

/**
 备注
 */
@property (nonatomic,strong) NSString *remark;

@property (nonatomic,strong) NSString *time;
- (instancetype) initWithModel:(id) Model;
- (instancetype) initWithFirstModel:(id) Model;
@end
