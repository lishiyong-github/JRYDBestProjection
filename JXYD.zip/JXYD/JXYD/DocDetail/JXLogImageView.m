//
//  JXLogImageView.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/18.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXLogImageView.h"

@interface JXLogImageView ()
@property (nonatomic,strong) UIView *verticalView;
@property (nonatomic,strong) UIView *circleView;
@end
@implementation JXLogImageView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.verticalView];
        [self addSubview:self.circleView];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void)myUpdateViewConstraints
{
    [self.verticalView autoPinEdgeToSuperviewEdge:ALEdgeTop];
    [self.verticalView autoSetDimension:ALDimensionWidth toSize:2];
//    [self.verticalView autoPinEdgeToSuperviewEdge:ALEdgeBottom];
    [self.verticalView autoCenterInSuperview];
    [self.circleView autoCenterInSuperview];
    [self.circleView autoSetDimensionsToSize:CGSizeMake(10, 10)];
}

- (UIView *)verticalView
{
    if (!_verticalView) {
        _verticalView = [UIView newAutoLayoutView];
        [_verticalView setBackgroundColor:[UIColor blueColor]];
    }
    return _verticalView;
}

- (UIView *)circleView
{
    if (!_circleView) {
        _circleView = [UIView newAutoLayoutView];
        [_circleView setBackgroundColor:[UIColor blueColor]];
        [_circleView.layer setMasksToBounds:YES];
        [_circleView.layer setCornerRadius:5];
    }
    return _circleView ;
}

@end
