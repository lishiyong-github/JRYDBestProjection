//
//  ListResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "ListResponse.h"

@implementation ListResponse

@end
