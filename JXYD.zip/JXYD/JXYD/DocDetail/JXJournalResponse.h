//
//  JXJournalResponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JXJournalResponse : NSObject
@property (nonatomic,strong)  NSString *success;
@end
