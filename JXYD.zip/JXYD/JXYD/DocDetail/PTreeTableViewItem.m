//
//  PTreeTableViewItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "PTreeTableViewItem.h"

@implementation PTreeTableViewItem
- (instancetype) initWithModel:(id) model{
    if (self = [super init]) {
        
        
    }
    return self;
}
@end
