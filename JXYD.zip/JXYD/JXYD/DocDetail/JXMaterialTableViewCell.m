//
//  JXProjectDetailTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXMaterialTableViewCell.h"
#import "UIView+Line.h"
@implementation JXMaterialTableViewCell
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftImageView];
        [self.contentView addSubview:self.leftLabel];
        self.leftSpaceConstraints =  [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
        [self.contentView addBottomLine];
    }
    return self;
}

- (void) cellWillAppear {
    self.leftLabel.text = self.item.leftText;
    self.leftImageView.image = [UIImage imageNamed:self.item.fileType];
//    self.indentationLevel = 10;
    self.leftSpaceConstraints.constant = self.item.level*40+15;
}

- (UIImageView *) leftImageView {
    if (!_leftImageView) {
        _leftImageView = [UIImageView newAutoLayoutView];
    }
    return _leftImageView;
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
        [_leftLabel setFont:[UIFont systemFontOfSize:12]];
    }
    return _leftLabel;
}

- (void) myUpdateViewConstraints {
    //布局
//    [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.leftImageView autoSetDimensionsToSize:CGSizeMake(22, 22)];
    
    [self.leftLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftImageView withOffset:10];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];

}



@end
