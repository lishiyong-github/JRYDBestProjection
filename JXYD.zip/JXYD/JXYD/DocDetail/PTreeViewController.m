//
//  PTreeViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "PTreeViewController.h"
#import "PTreeTableViewItem.h"
#import "PTreeHeaderView.h"
#import "PTreeTableViewResponse.h"

@interface PTreeViewController ()
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) RETableViewManager *manager;
@property (nonatomic,strong) PTreeTableViewResponse *response;
@end

@implementation PTreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"项目树";
    // 添加tableView
    [self.view addSubview:self.tableView];
    //添加manager
    [self addManager];
    //请求数据
    [self requestData];
}

- (void) requestData {
    NSDictionary *parama =  @{@"type":@"smartplan",
                              @"action":@"projecttree",
                              @"showType":@"1",
                              @"slbh":self.slbh,//市SW201707280018
                              @"includeAllResources":@"false"};
    @weakify(self);
    [self postUrl:[JXApiHelper serverAddress]  param:parama success:^(NSDictionary *json) {
        @strongify(self);
        self.response = [PTreeTableViewResponse mj_objectWithKeyValues:json];
        [self configTable];
        if (!self.response.result.count) {
            [self showEmptyView];
        }
    } failed:^{
        
        NSLog(@"****项目表单请求失败！");
    } showIndicator:YES];
}

- (void) configTable {
    [self.manager removeAllSections];
    //添加item
    @weakify(self);
    for (PTreeModel *model in self.response.result) {
        RETableViewSection *section = [RETableViewSection section];
        PTreeHeaderView *headerView = [self getSectionHeaderView];
        headerView.close = model.close;
        [headerView.leftLabel setText:model.group];
        [headerView setClicked:^{
            @strongify(self);
            model.close = !model.close;
            [self configTable];
        }];
        [section setHeaderView:headerView];
        if (!model.close) {
            for (ItemModel *itemModel in model.items) {
                //创建Item
                PTreeTableViewItem *item = [[PTreeTableViewItem alloc] init];
                item.leftImage = @"yuandian";
                item.leftText = itemModel.name;
                [section addItem:item];
            }
        }
        [self.manager addSection:section];
    }
    [self.tableView reloadData];
}

- (void) addManager {
    self.manager = [[RETableViewManager alloc] initWithTableView:self.tableView];
    self.manager[@"PTreeTableViewItem"] = @"PTreeTableViewCell";
}

#pragma mark --getter

- (UITableView *) tableView {
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    return _tableView;
}
- (PTreeHeaderView *)getSectionHeaderView
{
    return [[PTreeHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
}
- (void) myUpdateViewConstraints {
    [super myUpdateViewConstraints];
    [self.tableView autoPinEdgesToSuperviewEdges];
}

@end
