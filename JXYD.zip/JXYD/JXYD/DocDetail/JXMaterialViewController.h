//
//  JXProjectDetailViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTableViewController.h"

@interface JXMaterialViewController : JXTableViewController
/**
 项目编号
 审批：slbh
 公文：projectNo
 */
@property (nonatomic,strong) NSString *slbh;
@property (nonatomic,strong) UINavigationController *nav;
@end
