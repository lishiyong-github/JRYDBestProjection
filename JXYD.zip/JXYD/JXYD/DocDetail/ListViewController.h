//
//  ListViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListViewController : SHNetWorkViewController
@property (nonatomic,strong) NSString *projectID;
@end
