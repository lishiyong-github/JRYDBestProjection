//
//  JXJournalTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXJournalTableViewCell.h"
#import "UIView+Line.h"
@implementation JXJournalTableViewCell
@dynamic item;
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.logImageView];
        [self.contentView addSubview:self.timelabel];
        [self.contentView addSubview:self.toLabel];
        [self.contentView addSubview:self.fromLabel];
        [self.contentView addSubview:self.remarkLabel];
        [self setNeedsUpdateConstraints];
//        [self.contentView addBottomLine];
    }
    return self;
}

- (void) cellWillAppear {
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.timelabel.text = self.item.time;
    self.fromLabel.text = self.item.fromText;
    self.toLabel.text = self.item.toText;
    self.remarkLabel.text = self.item.remark;
}

- (JXLogImageView *)logImageView
{
    if (!_logImageView) {
        _logImageView = [JXLogImageView newAutoLayoutView];
    }
    return _logImageView;
}

- (UILabel *) timelabel {
    if (!_timelabel) {
        _timelabel = [UILabel newAutoLayoutView];
        [_timelabel setFont:[UIFont systemFontOfSize:15]];
    }
    return _timelabel;
}

- (UILabel *)fromLabel
{
    if (!_fromLabel) {
        _fromLabel = [UILabel newAutoLayoutView];
        [_fromLabel setFont:[UIFont systemFontOfSize:15]];
    }
    return _fromLabel;
}

- (UILabel *)toLabel
{
    if (!_toLabel) {
        _toLabel = [UILabel newAutoLayoutView];
        [_toLabel setFont:[UIFont systemFontOfSize:15]];
        _toLabel.numberOfLines = 0;
    }
    return _toLabel;
}

- (UILabel *)remarkLabel
{
    if (!_remarkLabel) {
        _remarkLabel = [UILabel newAutoLayoutView];
        [_remarkLabel setFont:[UIFont systemFontOfSize:15]];
        _remarkLabel.numberOfLines = 0;
    }
    return _remarkLabel;
}

- (void) myUpdateViewConstraints {
    
    [self.logImageView autoPinEdgeToSuperviewEdge:ALEdgeBottom];
    [self.logImageView autoPinEdgeToSuperviewEdge:ALEdgeTop];
    [self.logImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.logImageView autoSetDimension:ALDimensionWidth toSize:10];
    
    [self.timelabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.logImageView withOffset:40];
    [self.timelabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [@[self.timelabel,self.fromLabel,self.toLabel,self.remarkLabel] autoAlignViewsToAxis:ALAxisHorizontal];
    [NSLayoutConstraint autoSetPriority:UILayoutPriorityRequired forConstraints:^{
        [self.timelabel setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    }];
    [self.fromLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.timelabel withOffset:20];
    [self.timelabel autoSetDimension:ALDimensionWidth toSize:90];
    [self.fromLabel autoSetDimension:ALDimensionWidth toSize:180];
    [self.toLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.fromLabel withOffset:20];
    [self.remarkLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.toLabel withOffset:20];
    [self.remarkLabel autoSetDimension:ALDimensionWidth toSize:150];
    [self.remarkLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    
}

@end
