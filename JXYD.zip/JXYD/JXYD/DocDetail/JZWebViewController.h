//
//  JZWebViewController.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SHBaseViewController.h"

@interface JZWebViewController : SHBaseViewController
@property (nonatomic,strong) UIWebView *webView;
- (instancetype)initWithUserID:(NSString *)userID projectId:(NSString *)projectID formID:(NSString *)formID;
- (void)configWebView;
@end
