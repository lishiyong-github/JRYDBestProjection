//
//  PTreeTableViewItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//



@interface PTreeTableViewItem : RETableViewItem
@property (nonatomic,strong) NSString *leftImage;
@property (nonatomic,strong) NSString *leftText;
- (instancetype) initWithModel:(id) model;

@end
