//
//  PTreeHeaderView.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "PTreeHeaderView.h"
#import "UIButton+Style.h"
#import "UIView+Line.h"

@interface PTreeHeaderView()
@property (nonatomic,strong) UITapGestureRecognizer *gesture;
@property (nonatomic,strong) UIButton *leftButton;
@end

@implementation PTreeHeaderView
- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.leftLabel];
        [self addSubview:self.leftButton];
        [self addGestureRecognizer:self.gesture];
        [self addBottomLine];
        [self setBackgroundColor:[UIColor whiteColor]];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (UIButton *) leftButton {
    if (!_leftButton) {
        _leftButton = [UIButton newAutoLayoutView];
//        [_leftButton setNormalImage:@"down" selectedImage:@"up"];
        [_leftButton setUserInteractionEnabled:NO];
    }
    return _leftButton;
}

- (void)setClose:(BOOL)close
{
    if (close) {
        [_leftButton setBackgroundImage:[UIImage imageNamed:@"ptree_right"] forState:UIControlStateNormal];
    }else{
        [_leftButton setBackgroundImage:[UIImage imageNamed:@"ptree_down"] forState:UIControlStateNormal];
    }
}

- (UITapGestureRecognizer *)gesture
{
    if (!_gesture) {
        _gesture = [[UITapGestureRecognizer alloc]init];
        @weakify(self);
        [[_gesture rac_gestureSignal] subscribeNext:^(id x) {
            @strongify(self);
            if (self.clicked) {
                self.clicked();
            }
         }];
    }
    return _gesture;
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
        [_leftLabel setTextColor:[UIColor blackColor]];
        [_leftLabel setFont:[UIFont systemFontOfSize:15]];
        [_leftLabel setTextColor:[UIColor colorWithRed:0.0/255 green:146.0/255 blue:243.0/255 alpha:1.0f]];
    }
    return _leftLabel;
}

- (void) myUpdateViewConstraints {
    //布局
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:40];
    [self.leftLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    
    [self.leftButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.leftButton autoSetDimensionsToSize:CGSizeMake(15, 15)];
}

@end
