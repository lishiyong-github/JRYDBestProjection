//
//  ListTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//


#import "ListTableViewItem.h"
@interface ListTableViewCell : RETableViewCell
@property (nonatomic,strong) UIImageView *leftImageView;
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) ListTableViewItem *item;
@end
