//
//  JXProjectDetailTableViewItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXMaterialTableViewItem.h"

@implementation JXMaterialTableViewItem
- (instancetype) initWithModel {
    if (self = [super init]) {
//        self.leftConstraint = 100;
        self.level = 0;
    }
    return self;
}

- (NSString *) fileType {
    if (_fileType.length) {
        return _fileType;
    }
    //判断文件类型
    if ([self.leftText containsString:@".pdf"] || [self.leftText containsString:@".PDF"]) {
        return  @"file_pdf";
    }else if ([self.leftText containsString:@".image"]){
        return  @"image";
    }else if ([self.leftText containsString:@".doc"] || [self.leftText containsString:@".docx"]){
        return  self.fileType = @"doc";
    }else if ([self.leftText containsString:@"folder"]){
        return  @"folder";
    }else if ([self.leftText containsString:@"dwg"]){
        return @"file_dwg";
    }
    return  @"file_default";
}

- (void)setDefaultFileType
{
    _fileType = @"folder";
}
//- (void) judgeFileType:(NSString *)fileName withItem:(JXProjectDetailTableViewItem *)item {
//    //判断是否是文件
//    if ([fileName containsString:@".pdf"]) {
//        item.leftImage = @"file_pdf";
//    }else if ([fileName containsString:@".image"]){
//        item.leftImage = @"image";
//    }else if ([fileName containsString:@".doc"] || [fileName containsString:@".docx"]){
//        item.leftImage = @"doc";
//    }else{
//        item.leftImage = @"folder";
//    }
//}

@end
