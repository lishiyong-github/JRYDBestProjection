//
//  NewsViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/27.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "NewsViewController.h"
#import "RETableViewManager.h"
#import "NewsTableViewCell.h"
#import "NewsTableViewCellItem.h"
#import "ListViewController.h"
#import "JXLogViewController.h"
#import "JXMaterialViewController.h"

@interface NewsViewController ()
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) RETableViewManager *manager;
@end

@implementation NewsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:[UIColor mainColor]] forBarMetrics:UIBarMetricsDefault];
    //添加tableView
    [self.view addSubview:self.tableView];
    [self addSection];
    [self.view setNeedsUpdateConstraints];
}

- (void) viewWillAppear:(BOOL)animated{
    [self.navigationController setNavigationBarHidden:NO];
}

- (void) addSection {
    //创建manager、section
    self.manager = [[RETableViewManager alloc] initWithTableView:self.tableView];
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    
    //注册item、cell
    self.manager[@"NewsTableViewCellItem"] = @"NewsTableViewCell";
    
    for (int i=0; i<6; i++) {
        NewsTableViewCellItem *item = [[NewsTableViewCellItem alloc] init];
        @weakify(self);
        [item setSelectionHandler:^(id x){
            @strongify(self);
//            ListViewController *listVC = [[ListViewController alloc] init];
            JXMaterialViewController *controller = [[JXMaterialViewController alloc] init];
            controller.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:controller animated:YES];
        }];
        item.cellHeight = 80.0f;
        item.leftTitle=@"彭高峰主任与市教育局进行座谈的画教育局进行座谈的画面";
        item.leftImage=@"wlf3.jpg";
        item.rightTitle = @"2017-2-20";
        [section addItem:item];
    }
}

- (UITableView *) tableView {
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    return _tableView;
}

- (void) myUpdateViewConstraints {
    //设置tableView与父视图的位置
    [self.tableView autoPinEdgesToSuperviewEdges];
}

@end
