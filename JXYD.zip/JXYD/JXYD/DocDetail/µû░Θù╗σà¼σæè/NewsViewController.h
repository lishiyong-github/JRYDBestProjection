//
//  NewsViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/27.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsViewController : UIViewController




@end
