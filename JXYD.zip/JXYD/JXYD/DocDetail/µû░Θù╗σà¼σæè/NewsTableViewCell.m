//
//  NewsTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/27.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "NewsTableViewCell.h"
#import "UIView+Line.h"
@implementation NewsTableViewCell
@dynamic item;

- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftImageView];
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addSubview:self.rightLabel];
        //添加customLine
        [self.contentView addBottomLine];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void) cellWillAppear {
    NSLog(@"打印——cellWillAppear");
    self.leftLabel.text = self.item.leftTitle;
    self.leftImageView.image = [UIImage imageNamed:self.item.leftImage];
    self.rightLabel.text = self.item.rightTitle;
}

- (UIImageView *) leftImageView {
    if (!_leftImageView) {
        _leftImageView = [UIImageView newAutoLayoutView];
//        _leftImageView.backgroundColor = [UIColor redColor];
    }
    return _leftImageView;
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
        _leftLabel.numberOfLines = 0;
//        [_leftLabel sizeToFit];
//        [_leftLabel setContentMode:UIViewContentModeTopLeft];
        [_leftLabel setTextColor:[UIColor blackColor]];
        [_leftLabel setFont:[UIFont systemFontOfSize:12]];
    }
    return _leftLabel;
}

- (UILabel *) rightLabel {
    if (!_rightLabel) {
        _rightLabel = [UILabel newAutoLayoutView];
//        _rightLabel.backgroundColor = [UIColor redColor];
        [_rightLabel setFont:[UIFont systemFontOfSize:12]];
        [_rightLabel setTextColor:[UIColor blackColor]];
    }
    return _rightLabel;
}

- (void) myUpdateViewConstraints {
    //布局leftImageView与父视图的位置
    [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5];
    [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];
    [self.leftImageView autoSetDimension:ALDimensionWidth toSize:100];
    
    //布局leftLabel与父视图的位置
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5];
    [self.leftLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftImageView withOffset:10];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    /*indicate*/
    [self.leftLabel autoPinEdge:ALEdgeBottom toEdge:ALEdgeTop ofView:self.rightLabel withOffset:0 relation:NSLayoutRelationLessThanOrEqual];
    
    //布局rightLabel与父视图的位置
    [self.rightLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.rightLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];
}

@end
