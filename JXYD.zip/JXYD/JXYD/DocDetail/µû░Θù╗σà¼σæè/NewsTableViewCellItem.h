//
//  NewsTableViewCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/27.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewItem.h"

@interface NewsTableViewCellItem : RETableViewItem
@property (nonatomic,copy) NSString *leftImage;
@property (nonatomic,copy) NSString *leftTitle;
@property (nonatomic,copy) NSString *rightTitle;
- (instancetype) initWithModel:(id) model;
@end
