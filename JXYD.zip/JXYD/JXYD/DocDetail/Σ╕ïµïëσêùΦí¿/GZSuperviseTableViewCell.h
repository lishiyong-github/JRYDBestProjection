//
//  GZSuperviseTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//



//#import <UIKit/UIKit.h>
#import <UIKit/UIKit.h>
#import "RETableViewCell.h"
#import "GZSuperviseTableViewCellItem.h"
@interface GZSuperviseTableViewCell : RETableViewCell
@property (strong,nonatomic) UIImageView *iconImageView;
@property (strong,nonatomic) UILabel *titleLabel;
@property (strong,nonatomic) UILabel *detailLabel;
@property (strong,nonatomic) UILabel *timeLable;
@property (strong,nonatomic) GZSuperviseTableViewCellItem *item;
@end
