//
//  CustomSectionView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/23.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomSectionView : UIView

@property (nonatomic,strong) UIButton *headerButton;
@property (nonatomic,strong) UILabel *sectionHeaderTitle;
@property(nonatomic,strong) UIImageView *rightIcon;

@end
