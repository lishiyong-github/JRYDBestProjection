
//
//  RootViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/16.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RootViewController.h"
#import "CustomTableViewCell.h"
#import "CustomSectionView.h"

@interface RootViewController ()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic, strong)UITableView *tableView;
@property(nonatomic, strong)NSMutableArray *sectionArray;//section标题
@property(nonatomic, strong)NSMutableArray *rowInSectionArray;//section中的cell个数
@property(nonatomic, strong)NSMutableArray *selectedArray;//是否被点击
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addTableView];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    
    _sectionArray = [NSMutableArray arrayWithObjects:@"局领导",@"调研员",@"住建部督查员室",@"办公室",@"机关党委",@"人事处",@"技术处",@"审批处", nil];//每个section的标题
    _rowInSectionArray = [NSMutableArray arrayWithObjects:@"6",@"6",@"6",@"6",@"6",@"6",@"6",@"6", nil];//每个section中cell的个数
    _selectedArray = [NSMutableArray arrayWithObjects:@"0",@"0",@"0",@"0",@"0",@"0",@"0",@"0", nil];//这个用于判断展开还是缩回当前section的cell
}

- (void) addTableView{
    UITableView *tableView = [UITableView newAutoLayoutView];
    tableView.delegate = self;
    tableView.dataSource = self;
    self.tableView = tableView;
    [self.view setNeedsUpdateConstraints];
}

- (UITableView *) tableView {
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
    }
    return _tableView;
}

- (void) myUpdateViewConstraints{
    [_tableView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
    [_tableView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [_tableView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [_tableView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
}

#pragma mark section的个数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _sectionArray.count;
}

#pragma mark cell的行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //判断section的标记是否为1,如果是说明为展开,就返回真实个数,如果不是就说明是缩回,返回0.
    if ([_selectedArray[section] isEqualToString:@"1"]) {
        return [_rowInSectionArray[section] integerValue];
    }
    return 0;
}

#pragma mark cell的内容
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[CustomTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.iconImageView.image = [UIImage imageNamed:@"wlf.jpg"];
    cell.phoneContent.text = @"13061904379";
    cell.nameContent.text = @"哈哈";
    cell.shortContent.text = @"770112";
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //拨打电话功能
    NSMutableString *telStr = [[NSMutableString alloc] initWithFormat:@"tel:%@",@"13061904379"];
    //    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:telStr]];
    UIWebView *webView = [[UIWebView alloc] init];
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:telStr]]];
    [self.view addSubview:webView];
}


#pragma cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}

#pragma mark - section内容
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    //每个section上面有一个button,给button一个tag值,用于在点击事件中改变_selectedArray[button.tag - 1000]的值
    CustomSectionView *sectionView = [[CustomSectionView alloc] init];
//    sectionView.backgroundColor = [UIColor grayColor];
    sectionView.sectionHeaderTitle.text = _sectionArray[section];
    [sectionView.headerButton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    sectionView.headerButton.tag = 1000+section;
    return sectionView;
}
#pragma mark button点击方法
-(void)buttonAction:(UIButton *)button
{
    if ([_selectedArray[button.tag - 1000] isEqualToString:@"0"]) {
        
        //如果缩回,点击后展开,是_selectedArray对应的值为1,这样当前section返回cell的个数就变为真实个数,然后刷新这个section就行了
        [_selectedArray replaceObjectAtIndex:button.tag - 1000 withObject:@"1"];
        [_tableView reloadSections:[NSIndexSet indexSetWithIndex:button.tag - 1000] withRowAnimation:UITableViewRowAnimationFade];
    }
    else
    {
        //如果展开,点击后缩回,使_selectedArray对应的值为0,这样当前section返回cell的个数变成0,然后刷新这个section就行了
        [_selectedArray replaceObjectAtIndex:button.tag - 1000 withObject:@"0"];
        [_tableView reloadSections:[NSIndexSet indexSetWithIndex:button.tag - 1000] withRowAnimation:UITableViewRowAnimationFade];
    }
}

@end
