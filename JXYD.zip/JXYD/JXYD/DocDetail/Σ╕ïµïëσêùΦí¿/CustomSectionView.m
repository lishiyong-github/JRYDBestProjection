//
//  CustomSectionView.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/23.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "CustomSectionView.h"
@interface CustomSectionView ()
@property(nonatomic,strong) UIView *bottomLine;
@end

@implementation CustomSectionView

- (instancetype) init{
    if (self = [super init]) {
        [self addSubview:self.headerButton];
        [self addSubview:self.sectionHeaderTitle];
        [self addSubview:self.rightIcon];
        [self addSubview:self.bottomLine];
        [self setNeedsUpdateConstraints];
        [self setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}

- (void) myUpdateViewConstraints{
    //布局sectionHeader
    [self.sectionHeaderTitle autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.sectionHeaderTitle autoAlignAxisToSuperviewAxis:ALAxisHorizontal];

    //布局button位置
    [self.headerButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.headerButton autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self ];
    [self.headerButton autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self];

    //布局rightIcon与父视图的位置
    [self.rightIcon autoSetDimensionsToSize:CGSizeMake(20, 20)];
    [self.rightIcon autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.rightIcon autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    
    //布局bottomLine与父视图的位置
    [self.bottomLine autoSetDimension:ALDimensionHeight toSize:1];
    [self.bottomLine autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    [self.bottomLine autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.bottomLine autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    
}

- (UIView *) bottomLine {
    if (!_bottomLine) {
        _bottomLine = [UIView newAutoLayoutView];
        _bottomLine.alpha = 0.1;
        _bottomLine.backgroundColor = [UIColor blackColor];
    }
    return _bottomLine;
    
}

- (UIImageView *) rightIcon{
    if (!_rightIcon) {
        _rightIcon = [UIImageView newAutoLayoutView];
        _rightIcon.backgroundColor = [UIColor redColor];
    }
    return _rightIcon;
}


- (UILabel *)sectionHeaderTitle {
    if (!_sectionHeaderTitle) {
        _sectionHeaderTitle = [UILabel newAutoLayoutView];
        _sectionHeaderTitle.textAlignment = NSTextAlignmentLeft;
        _sectionHeaderTitle.textColor = [UIColor blackColor];
        _sectionHeaderTitle.font = [UIFont systemFontOfSize:13];
    }
    return _sectionHeaderTitle;
}

- (UIButton *) headerButton {
    if (!_headerButton) {
        _headerButton = [UIButton newAutoLayoutView];
    }
    return _headerButton;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
