//
//  GZSuperviseTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "CustomTableViewCell.h"
#import "UIView+Line.h"

@interface CustomTableViewCell ()
@property (strong,nonatomic) UILabel *nameLabel;
@property (strong,nonatomic) UILabel *phoneLabel;
@property (strong,nonatomic) UILabel *shortLabel;
@end

@implementation CustomTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.iconImageView];
        [self.contentView addSubview:self.nameLabel];
        [self.contentView addSubview:self.phoneLabel];
        [self.contentView addSubview:self.shortLabel];
        [self.contentView addSubview:self.phoneContent];
        [self.contentView addSubview:self.shortContent];
        [self.contentView addSubview:self.nameContent];
        [self.contentView addBottomLine];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void)myUpdateViewConstraints
{
    //显示姓名
    [self.nameLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:3];
    [self.nameLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    
    //显示姓名内容
    [self.nameContent autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:3];
    [self.nameContent autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.nameLabel withOffset:0];
    
    
    //显示手机号
    [self.phoneLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.phoneLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:3];
    
    //显示手机号内容
    [self.phoneContent autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:3];
    [self.phoneContent autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.phoneLabel withOffset:0];
    
    //显示短号
    [self.shortLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.phoneContent withOffset:7];
    [self.shortLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:3];
    
    //显示短号内容
    [self.shortContent autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:3];
    [self.shortContent autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.shortLabel];
    
    //显示单元格左侧的图标
    [self.iconImageView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.iconImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.iconImageView autoSetDimensionsToSize:CGSizeMake(20, 20)];
}

- (UILabel *) nameContent {
    if (!_nameContent) {
        _nameContent = [UILabel newAutoLayoutView];
        _nameContent.textAlignment = NSTextAlignmentLeft;
        _nameContent.font = [UIFont systemFontOfSize:11];
        _nameContent.textColor = [UIColor grayColor];
    }
    return _nameContent;
}

- (UILabel *) phoneContent {
    if (!_phoneContent) {
        _phoneContent = [UILabel newAutoLayoutView];
        _phoneContent.textAlignment = NSTextAlignmentLeft;
        _phoneContent.textColor = [UIColor grayColor];
        _phoneContent.font = [UIFont systemFontOfSize:11];
    }
    return _phoneContent;
}

- (UILabel *) shortContent{
    if (!_shortContent) {
        _shortContent = [UILabel newAutoLayoutView];
        _shortContent.textAlignment = NSTextAlignmentLeft;
        _shortContent.textColor = [UIColor grayColor];
        _shortContent.font = [UIFont systemFontOfSize:11];
    }
    return _shortContent;
}

- (UILabel *)nameLabel  {
    if (!_nameLabel) {
        _nameLabel = [UILabel newAutoLayoutView];
        [_nameLabel setTextAlignment:NSTextAlignmentLeft];
        [_nameLabel setTextColor:[UIColor grayColor]];
        _nameLabel.text = @"姓名:";
        [_nameLabel setFont:[UIFont systemFontOfSize:11]];
    }
    return _nameLabel;
}

- (UILabel *) phoneLabel {
    if (!_phoneLabel) {
        _phoneLabel = [UILabel newAutoLayoutView];
        [_phoneLabel setTextColor:[UIColor grayColor]];
        _phoneLabel.text = @"手机号:";
        [_phoneLabel setFont:[UIFont systemFontOfSize:11]];
    }
    return _phoneLabel;
}

- (UILabel *) shortLabel {
    if (!_shortLabel) {
        _shortLabel = [UILabel newAutoLayoutView];
        [_shortLabel setTextColor:[UIColor grayColor]];
        _shortLabel.text = @"短号:";
        [_shortLabel setFont:[UIFont systemFontOfSize:11]];
    }
    return _shortLabel;
}

#pragma mark - getter
- (UIImageView *)iconImageView
{
    if (!_iconImageView) {
        _iconImageView = [UIImageView newAutoLayoutView];
//        [_iconImageView setBackgroundColor:[UIColor redColor]];
    }
    return _iconImageView;
}

@end
