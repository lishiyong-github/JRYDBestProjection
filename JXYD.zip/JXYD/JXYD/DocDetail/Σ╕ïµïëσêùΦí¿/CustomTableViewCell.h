//
//  GZSuperviseTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//



//#import <UIKit/UIKit.h>
#import <UIKit/UIKit.h>
@interface CustomTableViewCell : UITableViewCell
@property (strong,nonatomic) UIImageView *iconImageView;
@property (strong,nonatomic) UILabel *nameContent;
@property (strong,nonatomic) UILabel *phoneContent;
@property (strong,nonatomic) UILabel *shortContent;

@end
