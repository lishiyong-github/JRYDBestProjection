//
//  JZWebViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JZWebViewController.h"
#import <AFNetworking/UIWebView+AFNetworking.h>
@interface JZWebViewController ()
@property (nonatomic,strong) NSString *userID;
@property (nonatomic,strong) NSString *projectID;
@property (nonatomic,strong) NSString *formID;
@end

@implementation JZWebViewController

- (void)dealloc
{
    NSLog(@"******************************************\n %@",@"JZWebViewController");
}
- (instancetype)initWithUserID:(NSString *)userID projectId:(NSString *)projectID formID:(NSString *)formID
{
    self = [super init];
    if (self) {
        self.userID = userID;
        self.projectID = projectID;
        self.formID = formID;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.webView];
    [self configWebView];
}

- (void)configWebView
{
    NSString *url=[NSString stringWithFormat:@"%@type=formpage&r=%f",[JXApiHelper serverAddress],roundf(3.1415)];
    // Do any additional setup after loading the view.
    @weakify(self);
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] progress:nil success:^NSString * _Nonnull(NSHTTPURLResponse * _Nonnull response, NSString * _Nonnull HTML) {
        NSLog(@"******************************************\n %@",@"加载成功");;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            @strongify(self);
            NSString *method = [NSString stringWithFormat:@"window.loadForm('%@','%@','%@')",self.userID,self.projectID,self.formID];
            [self.webView stringByEvaluatingJavaScriptFromString:method];
        });
        return @"";
    } failure:^(NSError * _Nonnull error) {
        NSLog(@"******************************************\n %@",@"加载失败");;
    }];
}

- (void)myUpdateViewConstraints
{
    [self.webView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
}
- (UIWebView *)webView
{
    if (!_webView) {
        _webView = [UIWebView newAutoLayoutView];
        _webView.scalesPageToFit = YES;
    }
    return _webView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
