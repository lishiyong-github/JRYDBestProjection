//
//  JXProjectDetailTableViewResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXMaterialTableViewResponse.h"

@implementation JXMaterialTableViewResponse
+(NSDictionary *) mj_objectClassInArray {
    return @{@"result":@"JXMaterialModel"};
}
@end

@implementation JXMaterialModel
+(NSDictionary *) mj_objectClassInArray {
    return @{@"Children":@"JXMaterialModel"};
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.open = YES;
    }
    return self;
}
@end
