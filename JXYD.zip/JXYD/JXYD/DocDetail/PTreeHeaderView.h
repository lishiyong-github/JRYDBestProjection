//
//  PTreeHeaderView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PTreeHeaderView : UIView
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) UIImageView *leftImageView;
@property (nonatomic,assign) BOOL close;
@property (nonatomic,copy)  void (^clicked)();
@end
