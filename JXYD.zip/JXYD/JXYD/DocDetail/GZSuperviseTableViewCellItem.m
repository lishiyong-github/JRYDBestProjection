//
//  GZSuperviseTableViewCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/17.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "GZSuperviseTableViewCellItem.h"

@implementation GZSuperviseTableViewCellItem

- (instancetype)initViewModel:(id)model
{
    self = [super init];
    if (self) {
//        self.imageName = model.name;
        
    }
    return self;
}
@end
