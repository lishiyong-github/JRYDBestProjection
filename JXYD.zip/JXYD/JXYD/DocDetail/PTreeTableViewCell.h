//
//  PTreeTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//


#import "PTreeTableViewItem.h"
@interface PTreeTableViewCell : RETableViewCell
@property (nonatomic,strong) UIImageView *leftImageView;
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) PTreeTableViewItem *item;
@end
