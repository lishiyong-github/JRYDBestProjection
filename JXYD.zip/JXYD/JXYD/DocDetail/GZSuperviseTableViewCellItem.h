//
//  GZSuperviseTableViewCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/17.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewItem.h"

@interface GZSuperviseTableViewCellItem : RETableViewItem
@property (strong,nonatomic) NSString *imageName;
@property (strong,nonatomic) NSString *titieName;
@property (strong,nonatomic) NSString *subTitmeName;
@property (strong,nonatomic) NSString *time;
- (instancetype)initViewModel:(id)model;
@end
