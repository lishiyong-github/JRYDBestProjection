//
//  JXJournalTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//


#import "JXJournalTableViewItem.h"
#import "JXLogImageView.h"
@interface JXJournalTableViewCell : RETableViewCell
@property (nonatomic,strong) JXLogImageView *logImageView;
@property (nonatomic,strong) UILabel *timelabel;
@property (nonatomic,strong) UILabel *fromLabel;
@property (nonatomic,strong) UILabel *toLabel;
@property (nonatomic,strong) UILabel *remarkLabel;
@property (nonatomic,strong) JXJournalTableViewItem *item;
@end
