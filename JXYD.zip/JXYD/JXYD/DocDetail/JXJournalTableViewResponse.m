//
//  JXJournalTableViewResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXJournalTableViewResponse.h"

@implementation JXJournalTableViewResponse
+(NSDictionary *) mj_objectClassInArray {
    return @{@"result":@"JXJournalModel"};
}
@end

@implementation JXJournalModel
- (NSString *)Opinion
{
    if (!_Opinion.length) {
        _Opinion = @"无";
    }
    return _Opinion;
}
@end

