//
//  JXLogViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXLogViewController.h"
#import "JXJournalTableViewItem.h"
#import "JXJournalTableViewCell.h"
#import "JXJournalTableViewResponse.h"
#import "JXLogImageView.h"
@interface JXLogViewController ()
@property (nonatomic,strong) UITableView  *tableView;
@property (nonatomic,strong) RETableViewManager *manager;
@property (nonatomic,strong) JXJournalTableViewResponse *response;
@property (nonatomic,strong) NSMutableArray *dataSources;
@property (nonatomic,strong) NSMutableArray *sectionSources;
@end

@implementation JXLogViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"项目日志";
    [self.view addSubview:self.tableView];
    [self addManager];
    [self requestData];
}

//- (NSString *)projectID
//{
//    //test
//    return @"638995";
//}

- (void) addManager {
    RETableViewManager *manager = [[RETableViewManager alloc] initWithTableView:self.tableView];
    //注册item、cell
    manager[@"JXJournalTableViewItem"] = @"JXJournalTableViewCell";
    self.manager = manager;
}

- (void) requestData {
    NSDictionary *parama =  @{@"type":@"smartplan",
                              @"action":@"projectlog",
                              @"projectId":self.projectID};
    @weakify(self);
    NSLog(@"******************************************\n %@",[NSString stringWithFormat:@"%@%@",[JXApiHelper serverAddress],[parama urlEncodedString]]);
    [self postUrl:[JXApiHelper serverAddress]  param:parama success:^(NSDictionary *json) {
        @strongify(self);
        self.response = [JXJournalTableViewResponse mj_objectWithKeyValues:json];
        [self configTable];
        if (!self.response.result.count) {
            [self showEmptyView];
        }
    } failed:^{
        [self showEmptyView];
        NSLog(@"****项目日志请求失败！");
    } showIndicator:YES];
}

- (void)caculaterDate
{
    self.dataSources = [NSMutableArray array];
    self.sectionSources = [NSMutableArray array];
    NSMutableArray *array;
    for (JXJournalModel *model in self.response.result) {
        NSString *time = [self getTimeWithDate:model.StartTime];
        if (![self.sectionSources containsObject:time]) {
            [self.sectionSources addObject:time];
            array = [NSMutableArray array];
            [array addObject:model];
            [self.dataSources addObject:array];
        }else{
            [array addObject:model];
        }
    }
}

- (void) configTable {
    [self caculaterDate];
    for (NSInteger i = 0; i<self.sectionSources.count; i++) {
        
        //创建section
        RETableViewSection *section = [RETableViewSection section];
        [self.manager addSection:section];
        [section setHeaderView:[self getHeaderViewWithString:self.sectionSources[i]]];
        [section setHeaderHeight:40];
        if (i == 0) {//add start item
            if ([self.dataSources.firstObject count]) {
                //创建item
                JXJournalTableViewItem *item = [[JXJournalTableViewItem alloc] initWithFirstModel:[self.dataSources.firstObject firstObject]];
                [section addItem:item];
            }
        }
        for (JXJournalModel *model in self.dataSources[i]) {
            //创建item
            JXJournalTableViewItem *item = [[JXJournalTableViewItem alloc] initWithModel:model];
            [section addItem:item];
        }
        
    }
    [self.tableView reloadData];
}

- (NSString *)getTimeWithDate:(NSString *)dateString
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *date = [formatter dateFromString:dateString];
    [formatter setDateFormat:@"yyyy年MM月"];
    return [formatter stringFromDate:date];
}

- (UITableView *) tableView {
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        [_tableView setSeparatorColor:[UIColor redColor]];
    }
    return _tableView;
}

- (UIView *)getHeaderViewWithString:(NSString *)title
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
    [view setBackgroundColor:[UIColor colorWithRed:0.9608 green:0.9608 blue:0.9608 alpha:1]];
    JXLogImageView *imageView = [JXLogImageView newAutoLayoutView];
    [view addSubview:imageView];
    [imageView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(0, 10, 0, 0) excludingEdge:ALEdgeRight];
    [imageView autoSetDimension:ALDimensionWidth toSize:10];
    
    UILabel *label = [UILabel newAutoLayoutView];
    label.text = title;
    [label setFont:[UIFont boldSystemFontOfSize:15]];
    [view addSubview:label];
    [label autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [label autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:imageView withOffset:10];
    return view;
}

- (void) myUpdateViewConstraints {
    [super myUpdateViewConstraints];
    [self.tableView autoPinEdgesToSuperviewEdges];
}
@end
