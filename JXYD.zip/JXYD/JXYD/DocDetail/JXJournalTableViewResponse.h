//
//  JXJournalTableViewResponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXJournalResponse.h"

@interface JXJournalTableViewResponse : JXJournalResponse
@property (nonatomic,strong) NSArray *result;
@end

@interface JXJournalModel : NSObject
@property (nonatomic,strong) NSString *EndTime;
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *LogName;
@property (nonatomic,strong) NSString *Remark;
@property (nonatomic,strong) NSString *StartTime;
@property (nonatomic,strong) NSString *Type;
@property (nonatomic,strong) NSString *UserName;
@property (nonatomic,strong) NSString *Opinion;
@end

