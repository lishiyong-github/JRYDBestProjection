//
//  ListTableViewItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "ListTableViewItem.h"

@implementation ListTableViewItem
- (instancetype) initWithModel:(id) model {
    if (self = [super init]) {
        
        
    }
    return self;
}
@end
