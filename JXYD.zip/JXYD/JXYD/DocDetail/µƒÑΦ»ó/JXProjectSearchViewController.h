//
//  SearchViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//公文查询

#import "SHRefreshViewController.h"

typedef NS_ENUM(NSInteger,JXProjectSearch) {
    JXProjectSearchApproval,
    JXProjectSearchDocument
};
@interface JXProjectSearchViewController : SHRefreshViewController
//@property (nonatomic,assign) JXProjectSearch searchType;//0—项目查询，1—公文查询
@property (nonatomic,assign) NSInteger index;

@end
