//
//  SearchTableViewCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewItem.h"

@interface SearchTableViewCellItem : RETableViewItem
@property (nonatomic,strong) NSString *leftText;
@property (nonatomic,strong) NSString *rightText;
@property (nonatomic,strong) NSString *placeHolder;
@property (nonatomic,strong) NSString *searchKey;
@property (nonatomic,strong) UIColor *titleColor;

- (instancetype)initWithModel:(id)model;
@end
