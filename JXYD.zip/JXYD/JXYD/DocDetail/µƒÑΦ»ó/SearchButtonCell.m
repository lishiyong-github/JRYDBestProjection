//
//  SearchButtonCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SearchButtonCell.h"

@implementation SearchButtonCell
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.searchButton];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (UIButton *) searchButton {
    if (!_searchButton) {
        _searchButton = [UIButton newAutoLayoutView];
        [_searchButton  setTitle:@"查询" forState:UIControlStateNormal];
        _searchButton.titleLabel.font = [UIFont systemFontOfSize:16]; ;
        [_searchButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_searchButton setBackgroundColor:[UIColor colorWithRed:0.000 green:0.5765 blue:0.9529 alpha:1.0]];
        _searchButton.layer.cornerRadius = 3.0 ;
        @weakify(self);
        [[_searchButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            if (self.item.clicked) {
                self.item.clicked();
            }
        }];
    }
    return _searchButton;
}

- (void) myUpdateViewConstraints {
    //布局按钮与父视图的关系
    [self.searchButton autoCenterInSuperview];
    [self.searchButton autoSetDimensionsToSize:CGSizeMake(500, 40)];
}

@end
