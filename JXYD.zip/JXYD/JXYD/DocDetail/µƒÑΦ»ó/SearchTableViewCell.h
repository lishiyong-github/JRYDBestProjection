//
//  SearchTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RETableViewCell.h"
#import "SearchTableViewCellItem.h"
@interface SearchTableViewCell : RETableViewCell
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) UITextField *contentTextField;
@property (nonatomic,strong) SearchTableViewCellItem *item;

@end
