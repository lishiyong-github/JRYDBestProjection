//
//  SearchViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXProjectSearchViewController.h"
#import "SearchTableViewCell.h"
#import "RETableViewManager.h"
#import "SearchTableViewCellItem.h"
#import "SearchButtonCell.h"
#import "SearchButtonCellItem.h"
#import "JXApprovalListReponse.h"
#import "DocumentTableViewCellItem.h"
#import "JXApprovalDetailPageViewController.h"
#import "UIView+Line.h"

//
#import "JXDocumentResponse.h"
#import "JXProjectSearchResponse.h"

@interface JXProjectSearchViewController ()
/*@property (nonatomic,strong) UILabel *titleLabel;
 @property (nonatomic,strong) UILabel *documentLable;
 @property (nonatomic,strong) UITextField *titleTextField;
 @property (nonatomic,strong) UITextField *documentTextfield;
 @property (nonatomic,strong) UIButton *searchButton;*/


@property (nonatomic,strong) UITableView *tableViewSearch;
@property (nonatomic,strong) RETableViewManager *managerSearch;
@property (nonatomic,strong) NSArray *titleArray;

@property (nonatomic,strong) JXProjectSearchResponse *model;
@property (nonatomic,strong) NSString *searchName;
@property (nonatomic,strong) NSString *searchProjectNO;

@end

@implementation JXProjectSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"公文查询";
    //添加TableView
    [self.view addSubview:self.tableViewSearch];
    //创建manager、section
    [self addSection];
    
    
    [self.view setNeedsUpdateConstraints];
    
    
    
    //add tableview
//    self.manager = [[RETableViewManager alloc]initWithTableView:self.tableView];
    self.manager[@"DocumentTableViewCellItem"] = @"DocumentTableViewCell";
    
}

- (UITableView *) tableViewSearch {
//自动布局tablewView与父视图的位置
    if (!_tableViewSearch) {
        _tableViewSearch = [UITableView newAutoLayoutView];
        [_tableViewSearch setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        _tableViewSearch.scrollEnabled = NO;
    }
    return _tableViewSearch;
}

#pragma mark - tableview1
- (void) addSection {
    //创建manager及section
    self.managerSearch  = [[RETableViewManager alloc] initWithTableView:self.tableViewSearch];
    RETableViewSection *section = [RETableViewSection section];
    section.style.defaultCellSelectionStyle = UITableViewCellSelectionStyleNone;
    [self.managerSearch addSection:section];
    
    //注册item与cell
    self.managerSearch[@"SearchTableViewCellItem"] = @"SearchTableViewCell";
    self.managerSearch[@"SearchButtonCellItem"]   = @"SearchButtonCell";
    SearchTableViewCellItem *item = [[SearchTableViewCellItem alloc] init];
    item.cellHeight = 60;
    item.leftText = @"公文标题";
    item.placeHolder = @"请输入公文标题";
    [section addItem:item];
    
    SearchTableViewCellItem *item1 = [[SearchTableViewCellItem alloc] init];
    item1.cellHeight = 60;
    item1.leftText = @"公文文号";
    item1.placeHolder = @"请输入公文文号";
    [section addItem:item1];
    
    SearchButtonCellItem *searchItem = [[SearchButtonCellItem alloc] init];
    searchItem.cellHeight = 100;
    @weakify(self);
    searchItem.clicked = ^{
        @strongify(self);
        [self.view endEditing:YES];
        [self beginRefreshing];
    };
    [section addItem:searchItem];
    [self.tableViewSearch reloadData];
    
    [[RACObserve(item, searchKey) distinctUntilChanged] subscribeNext:^(id x) {
        @strongify(self);
        self.searchName = x;
    }];
    
    [[RACObserve(item1, searchKey) distinctUntilChanged] subscribeNext:^(id x) {
        @strongify(self);
        self.searchProjectNO = x;
    }];
}

- (void)configTable
{
    [self.manager removeAllSections];
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    
    //注册item、cell
    @weakify(self);
    //添加item
    for (JXProjectSearchModel *model in self.model.result) {
        //创建item
        DocumentTableViewCellItem *item = [DocumentTableViewCellItem itemWithTitle:nil accessoryType:UITableViewCellAccessoryNone selectionHandler:^(RETableViewItem *item) {
            [item deselectRowAnimated:YES];
            @strongify(self);
            JXApprovalDetailPageViewController *controller = [[JXApprovalDetailPageViewController alloc] init];
//            controller.hidesBottomBarWhenPushed = YES;
            controller.model = model;
            if (model.swrq.length) {//收文
                controller.type = @"2";
            }else{
                controller.type = @"3";
            }
            controller.title = @"公文详情";
            [self.navigationController pushViewController:controller animated:YES];
            [JXLogManager WriteLog:@"搜索公文详情"  logLevel:@2];
        }];
        item.leftImage = @"eventIcon";
        item.leftUpText = model.bt;
        item.leftBottomtext = model.wh;
        item.rightBottomText = model.blzt;
        item.cellHeight = 60;
        [section addItem:item];
    }
    [self.tableView reloadData];
}

- (NSDictionary *)getParams
{
    NSDictionary *param = @{@"type":@"smartplan",
              @"action":@"getOfficeList",
              @"pagesize":self.pageSize,
              @"pageindex":self.pageIndex,
              @"officeName":checkNullString(self.searchName),
              @"bh":checkNullString(self.searchProjectNO)
              };
    return param;
}

- (Class)resultClass
{
    return [JXProjectSearchResponse class];
}

#pragma mark - tableView

- (void) myUpdateViewConstraints {
    //布局TableView与父视图的位置关系
    [self.tableViewSearch autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
    [self.tableViewSearch autoSetDimension:ALDimensionHeight toSize:220];
    
    [self.tableView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
    [self.tableView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.tableViewSearch withOffset:50];
}


@end
