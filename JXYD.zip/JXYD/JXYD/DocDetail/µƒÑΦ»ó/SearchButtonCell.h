//
//  SearchButtonCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RETableViewCell.h"
#import "SearchButtonCellItem.h"
@interface SearchButtonCell : RETableViewCell
@property (nonatomic,strong) UIButton *searchButton;
@property (nonatomic,strong) SearchButtonCellItem *item;
@end
