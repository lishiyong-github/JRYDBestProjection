//
//  SearchButtonCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewItem.h"

@interface SearchButtonCellItem : RETableViewItem
@property (nonatomic,copy) void (^clicked)();
@end
