//
//  SearchTableViewCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/25.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SearchTableViewCellItem.h"

@implementation SearchTableViewCellItem

- (instancetype)initWithModel:(id)model{
    if (self = [super init]) {
        
        
    }
    return self;
}
@end
