//
//  ListViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "ListViewController.h"
#import "ListTableViewItem.h"
#import "ListTableViewResponse.h"
#import "JZWebViewController.h"


@interface ListViewController ()
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) RETableViewManager *manager;
@property (nonatomic,strong) ListTableViewResponse *response;
@end

@implementation ListViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"项目表单";
    //添加TableView
    [self.view addSubview:self.tableView];
    
    //创建manager、section
    [self addManager];
    [self requestData];
}

- (void)requestData{
    NSDictionary *parama =  @{@"type":@"smartplan",
                            @"action":@"formlist",
                            @"projectId":self.projectID};
    @weakify(self);
    [self postUrl:[JXApiHelper serverAddress]  param:parama success:^(NSDictionary *json) {
        @strongify(self);
        self.response = [ListTableViewResponse mj_objectWithKeyValues:json];
        [self configTable];
        if (!self.response.result.count) {
            [self showEmptyView];
        }
    } failed:^{
        
        NSLog(@"****项目表单请求失败！");
    } showIndicator:YES];
}

- (void) configTable {
    //创建section
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    
    //注册item、cell
    @weakify(self);
    //添加item
    for (ListModel *model in self.response.result) {
        //创建item
        ListTableViewItem *item = [ListTableViewItem itemWithTitle:nil accessoryType:UITableViewCellAccessoryNone selectionHandler:^(RETableViewItem *item) {
            [item deselectRowAnimated:YES];
            @strongify(self);
            
            JZWebViewController *controller = [[JZWebViewController alloc]initWithUserID:[MainModel sharedInstances].userID projectId:self.projectID formID:model.identity];
            controller.title = model.name;
            [self.navigationController pushViewController:controller animated:YES];
        }];
        item.leftImage = @"eventIcon";
        item.leftText  = model.name;
        [section addItem:item];
    }
    [self.tableView reloadData];
}

- (void) addManager {
    //创建manager
    self.manager = [[RETableViewManager alloc] initWithTableView:self.tableView];
    self.manager[@"ListTableViewItem"] = @"ListTableViewCell";//一个item对应一个cell}
}

- (UITableView *) tableView {
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    return _tableView;
}

- (void) myUpdateViewConstraints {
    [super myUpdateViewConstraints];
    //布局tableView
    [self.tableView autoPinEdgesToSuperviewEdges];
}

@end
