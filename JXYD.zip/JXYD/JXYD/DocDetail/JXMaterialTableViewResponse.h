//
//  JXProjectDetailTableViewResponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/7.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXResponse.h"

@interface JXMaterialTableViewResponse : JXResponse
@property (nonatomic,strong) NSArray *result;
@end

@interface JXMaterialModel : NSObject
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *Name;
@property (nonatomic,strong) NSArray *Children;
@property (nonatomic,strong) NSString *Level;

//file message
@property (nonatomic,strong) NSString *addDate;
@property (nonatomic,strong) NSString *Description;
@property (nonatomic,strong) NSString *Extension;
@property (nonatomic,strong) NSString *fileName;
@property (nonatomic,strong) NSString *templateId;
@property (nonatomic,strong) NSString *instanceId;
@property (nonatomic,strong) NSString *userId;
@property (nonatomic,strong) NSString *fullPath;
@property (nonatomic,strong) NSString *ftpPath;
@property (nonatomic,strong) NSString *fileSize;
@property (nonatomic,assign) BOOL open;
@end

