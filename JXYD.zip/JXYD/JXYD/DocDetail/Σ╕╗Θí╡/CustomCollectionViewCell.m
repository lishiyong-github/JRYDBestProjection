//
//  CustomCollectionViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/27.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "CustomCollectionViewCell.h"

@implementation CustomCollectionViewCell
- (id) initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.backgroundImageView];
        [self addSubview:self.bottomLable];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (UIImageView *) backgroundImageView {
    if (!_backgroundImageView) {
        _backgroundImageView = [UIImageView newAutoLayoutView];
        _backgroundImageView.clipsToBounds = YES;
    }
    return _backgroundImageView;
}

- (UILabel *) bottomLable {
    if (!_bottomLable) {
        _bottomLable = [UILabel newAutoLayoutView];
        _bottomLable.textColor = [UIColor blackColor];
        _bottomLable.font = [UIFont systemFontOfSize:20];
        _bottomLable.textAlignment = NSTextAlignmentCenter;
    }
    return _bottomLable;
}

- (void) myUpdateViewConstraints {
    //布局backGroundImage与父视图的位置
    [self.backgroundImageView autoSetDimensionsToSize:CGSizeMake(70, 70)];
    [self.backgroundImageView autoPinEdgeToSuperviewEdge:ALEdgeTop];
    [self.backgroundImageView autoAlignAxisToSuperviewMarginAxis:ALAxisVertical];

    //布局bottomLabel与父视图的位置关系
    [self.bottomLable autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.bottomLable autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [self.bottomLable autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.backgroundImageView withOffset:5];
}

@end
