//
//  JXOpinionCellItem.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <RETableViewManager-Simple/RETableViewManager-Simple.h>

@interface JXOpinionCellItem : RETableViewItem
@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *time;
- (instancetype)initWithModel:(id)model;
@end
