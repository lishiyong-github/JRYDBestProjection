//
//  JXOpinionCellItem.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXOpinionCellItem.h"
#import "JXSignModel.h"
#import "NSString+SizeAddtion.h"
@implementation JXOpinionCellItem
- (instancetype)initWithModel:(id)model
{
    self = [super init];
    if (self) {
        self.cellIdentifier = @"JXOpinionCell";
        JXSignModel *signModel = model;
        self.title = [signModel.activityName stringByAppendingString:@":"];
        self.content = signModel.text.value;
        self.userName = signModel.user.value;
        
        //formatter time
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy/MM/dd"];//yyyy年MM月dd日
        NSString *dateString = signModel.date.value;
        dateString = [dateString substringToIndex:10];
        NSDate *date = [formatter dateFromString:dateString];
        [formatter setDateFormat:@"yyyy年MM月dd日"];
        self.time = [formatter stringFromDate:date];
        
        
        [self configCellHeight];
    }
    return self;
}

- (void)configCellHeight
{
    CGSize size = [self.content sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(SCREEN_WIDTH-30, MAXFLOAT)];
    self.cellHeight = size.height + 17.9*2+10+10+10+6+10;
    
}
@end
