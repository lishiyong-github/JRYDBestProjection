//
//  DocDetailTableViewCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewItem.h"

@interface DocDetailTableViewCellItem : RETableViewItem
@property (nonatomic,strong) NSString *leftText;
@property (nonatomic,strong) NSString *rightText;
- (instancetype) initWithModel:(id) model;
@end
