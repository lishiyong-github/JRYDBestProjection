//
//  JXOpinionHeaderCellItem.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXOpinionHeaderCellItem.h"

@implementation JXOpinionHeaderCellItem
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.cellIdentifier = @"JXOpinionHeaderCell";
//        self.imageName = @"down";
        self.open = YES;
    }
    return self;
}

- (void)setOpen:(BOOL)open
{
    _open = open;
    if (open) {
        self.imageName = @"up";
    }else{
        self.imageName = @"down";
    }
}
@end
