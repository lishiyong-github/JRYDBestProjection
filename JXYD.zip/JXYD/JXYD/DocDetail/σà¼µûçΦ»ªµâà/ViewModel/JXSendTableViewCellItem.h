//
//  JXSendTableViewCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//


@interface JXSendTableViewCellItem : RETableViewItem
@property (nonatomic,strong) NSString *leftText;
@property (nonatomic,strong) NSString *rightImage;
@property (nonatomic,strong) UIColor *selectedColor;
@property (nonatomic,assign) BOOL isSelectedCell;
@property (nonatomic,assign) BOOL isAutoChoose;
@property (nonatomic,assign) BOOL isHight;

- (instancetype) initWithModel:(id) model;
@end
