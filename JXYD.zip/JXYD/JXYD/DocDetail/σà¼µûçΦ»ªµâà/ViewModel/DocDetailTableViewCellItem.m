//
//  DocDetailTableViewCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DocDetailTableViewCellItem.h"
#import "NSString+SizeAddtion.h"
@implementation DocDetailTableViewCellItem
- (instancetype) initWithModel:(id) model{
    if (self = [super init]) {
        
        
    }
    return self;
}

- (void)setRightText:(NSString *)rightText
{
    _rightText = rightText;
    CGSize size = [rightText sizeWithFont:[UIFont systemFontOfSize:13] constrainedToSize:CGSizeMake(SCREEN_WIDTH - 130 - 15, MAXFLOAT)];
    self.cellHeight = MAX(44,size.height + 24);
}

@end
