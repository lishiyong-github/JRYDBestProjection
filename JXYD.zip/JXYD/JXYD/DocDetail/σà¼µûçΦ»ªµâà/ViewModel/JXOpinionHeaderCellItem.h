//
//  JXOpinionHeaderCellItem.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DocDetailTableViewCellItem.h"

@interface JXOpinionHeaderCellItem : DocDetailTableViewCellItem
@property (nonatomic,assign) BOOL open;
@property (nonatomic,strong) NSString *imageName;
@end
