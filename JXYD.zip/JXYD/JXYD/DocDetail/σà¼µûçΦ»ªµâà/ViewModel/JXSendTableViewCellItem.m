//
//  JXSendTableViewCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSendTableViewCellItem.h"
#import "JXSendResponse.h"
@implementation JXSendTableViewCellItem
- (instancetype) initWithModel:(id) model{
    if (self = [super init]) {
        JXUsersModel *userModel = model;
        self.leftText = userModel.userName;
        self.isHight = userModel.isHight.boolValue;
//        self.selectedColor = [UIColor colorWithRed:0.9255 green:0.9255 blue:0.9255 alpha:1.0f];
//        self.selectedLine = YES;
    }
    return self;
}
@end
