//
//  DocDetailViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DocDetailViewController.h"
#import "RETableViewManager.h"
#import "DocDetailTablevViewCell.h"
#import "DocDetailTableViewCellItem.h"
#import "InputDetailTableViewCell.h"
#import "InputDetailTableViewCellItem.h"
#import "bottomView.h"
#import "CustomHeaderView.h"
#import "DocDetailViewController.h"
#import "JXDocDetailResponse.h"
#import "SendToViewController.h"
#import "JXDocumentPageViewController.h"
#import "UIButton+Style.h"

#import "JXOpinionHeaderCellItem.h"
#import "JXOpinionCellItem.h"
//model
#import "JXSignResponse.h"
@interface DocDetailViewController ()
@property (nonatomic,strong) NSArray     *leftDataArray;
@property (nonatomic,strong) NSArray     *rightDataArray;
@property (nonatomic,strong) JXDocDetailResponse *projectInfoResponse;
@property (nonatomic,strong) JXSignResponse *signResponse;
@property (nonatomic,strong) JXSignModel *signModel;

@end

@implementation DocDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    //添加btmView
    [self.view addSubview:self.btmView];
    
    //add keyboard
    [LSYKeyBoardManager keyboadWithObserverView:self.tableView];
    
    [self getDetailInfo];
    //注册cell、item
    self.manager[@"DocDetailTableViewCellItem"]     = @"DocDetailTablevViewCell";
    self.manager[@"InputDetailTableViewCellItem"]   = @"InputDetailTableViewCell";
    self.manager[@"JXOpinionHeaderCellItem"] = @"JXOpinionHeaderCell";
    self.manager[@"JXOpinionCellItem"] = @"JXOpinionCell";
}

- (void)configData
{
    NSString *name = checkNullString(self.projectInfoResponse.name);
    NSString *constructOrg = checkNullString(self.projectInfoResponse.constructOrg);
    NSString *businessName = checkNullString(self.projectInfoResponse.businessName);
    NSString *projectNo = checkNullString(self.projectInfoResponse.projectNo);
    NSString *totalSerialNo = checkNullString(self.projectInfoResponse.totalSerialNo);
    NSString *prjState = checkNullString(self.projectInfoResponse.prjState);
    NSString *buildAddress = checkNullString(self.projectInfoResponse.buildAddress);
    switch (self.projectInfoResponse.businessId.integerValue) {
        case 22:
        case 321:
            self.leftDataArray = @[@"用途（项目名称）",@"申请单位名称",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[name,constructOrg,businessName,projectNo,totalSerialNo,prjState];
            break;
            
        case 23:
            self.leftDataArray = @[@"申请单位（人）",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[constructOrg,businessName,projectNo,totalSerialNo,prjState];
            break;
            
        case 24:
            self.leftDataArray = @[@"项目名称",@"申请单位（人）",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[name,constructOrg,businessName,projectNo,totalSerialNo,prjState];
            break;
            
        case 25:
            self.leftDataArray = @[@"地图名称",@"申请单位",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[name,constructOrg,businessName,projectNo,totalSerialNo,prjState];
            break;
            
        case 94:
            self.leftDataArray = @[@"项目名称",@"测绘单位",@"测绘位置",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[name,constructOrg,buildAddress,businessName,projectNo,totalSerialNo,prjState];
            break;
            
        case 121:
        case 161:
            self.leftDataArray = @[@"申请单位名称",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[constructOrg,businessName,projectNo,totalSerialNo,prjState];
            break;
            
        case 122:
            self.leftDataArray = @[@"申请单位名",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[constructOrg,businessName,projectNo,totalSerialNo,prjState];
            break;
            
        case 181:
            self.leftDataArray = @[@"申请科室",@"申请科室经办人",@"成果使用单位",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[checkNullString(self.projectInfoResponse.sqks),checkNullString(self.projectInfoResponse.sqksjbr),constructOrg,businessName,projectNo,totalSerialNo,prjState];
            break;
            
            
        default:
            self.leftDataArray = @[@"项目名称",@"申请单位(个人)",@"建设地址",@"业务类型",@"案卷编号",@"项目编号",@"办理状态"];
            self.rightDataArray = @[name,constructOrg,buildAddress,businessName,projectNo,totalSerialNo,prjState];
            break;
    }
}

- (void) configTableView {
    [self configData];
    //添加manager
    [self.manager removeAllSections];
    
    //添加section
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    
    @weakify(self);
    //    if (!self.sectionHeaderView.close) {
    for (int i=0; i<self.leftDataArray.count; i++) {
        DocDetailTableViewCellItem *item    = [[DocDetailTableViewCellItem alloc] init];
        item.leftText                       = _leftDataArray[i];
        item.rightText                      = _rightDataArray[i];
        [section addItem:item];
        item.selectionHandler = ^(id item) {
            @strongify(self);
            [self.view endEditing:YES];
        };
    }
    [section addItemsFromArray:[self getOpinionCellItems]];
    if (self.type.integerValue != 1) {
        self.btmView.hidden = NO;
        [section addItem:self.inputItem];
    }
    [self.tableView reloadData];
}

- (NSArray *)getOpinionCellItems
{
    NSMutableArray *items = [NSMutableArray array];
    if (self.signResponse.result.count) {
        JXOpinionHeaderCellItem *item = [[JXOpinionHeaderCellItem alloc]init];
        item.open = self.signResponse.open;
        item.leftText = [NSString stringWithFormat:@"项目意见（%@）",@(self.signResponse.result.count)];
        @weakify(self);
        item.selectionHandler = ^(JXOpinionHeaderCellItem *item) {
            @strongify(self);
            self.signResponse.open = !self.signResponse.open;
            [self configTableView];
        };
        [items addObject:item];
        if (self.signResponse.open) {
            for (JXSignModel *model in self.signResponse.result) {
                JXOpinionCellItem *item = [[JXOpinionCellItem alloc] initWithModel:model];
                [items addObject:item];
            }
        }
    }
    return items;
}

#pragma mark - send or back
- (void)sendWithProcessingType:(JXProcessType)processType
{
    [self.view endEditing:YES];
    if (!self.inputItem.inputText.length) {
        [MBProgressHUD showError:@"意见不能为空" toView:self.view];
        return;
    }
    SendToViewController *controller = [[SendToViewController alloc] init];
    controller.processType = processType;
    controller.wfWorkId = self.model.wfWorkItemId;
    controller.projectID = self.model.projectId;
    controller.datefield = self.signModel.dateField;
    controller.userfield = self.signModel.userField;
    controller.userTable = self.signModel.userTable;
    controller.fildName  =  self.signModel.textField;
    controller.opinion = self.inputItem.inputText;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - request data
- (void)getDetailInfo
{
    dispatch_group_t group = dispatch_group_create();
    self.group = group;
    
    //first request
    dispatch_group_enter(group);
    [self requestData];
    
    //second request
    dispatch_group_enter(group);
    [self requestSignInfo];
    
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        [self configTableView];
    });
}

- (void) requestData
{
    
    NSDictionary *param = @{@"type":@"smartplan",
                            @"action":@"projectBaseinfo",
                            @"projectId":self.model.projectId,
                            @"includeDetails":@"false",
                            @"wfworkItemId":checkNullString(self.model.wfWorkItemId)};
    @weakify(self);

    [self postUrl:[JXApiHelper serverAddress] param:param success:^(NSDictionary *json) {
        @strongify(self);
        if ([json[@"success"] isEqualToString:@"true"]) {
            self.projectInfoResponse = [JXDocDetailResponse mj_objectWithKeyValues:json[@"result"]];
            self.btmView.rightButton.enabled = !self.projectInfoResponse.isStartActivity;
            dispatch_group_leave(self.group);
        }
    } failed:^{
        NSLog(@"******************************************公文详情页请求数据失败！");
    } showIndicator:YES];
}

/**
 * 获取签名
 */
- (void) requestSignInfo
{
//    if (self.type.integerValue == 4) {
//        dispatch_group_leave(self.group);
//        return;
//    }
    NSDictionary *param = @{@"type":@"smartplan",
                            @"action":@"signInfo",
                            @"user":[MainModel sharedInstances].userID,
                            @"project":self.model.projectId};//self.model.projectId
    @weakify(self);
    [self postUrl:[JXApiHelper serverAddress] param:param success:^(NSDictionary *json) {
        @strongify(self);
        NSLog(@"******************************************获取签名成功\n %@",json);
        self.signResponse = [JXSignResponse mj_objectWithKeyValues:json];
        if ([self.signResponse.success isEqualToString:@"true"]) {
            [self configSignModel];
            if (!self.signModel.userTable.length) {
                NSLog(@"******************************************获取签名为空！！");
            }
        }
        dispatch_group_leave(self.group);
    } failed:^{
        NSLog(@"******************************************获取签名失败！！");
    } showIndicator:YES];
}

- (void)configSignModel
{
    NSMutableArray *array = [NSMutableArray array];
    for (JXSignModel *model in self.signResponse.result) {
        if (model.isCurrent) {
            self.signModel = model;
            self.inputItem.inputText = self.signModel.text.value;
        }
        if (model.text.value.length) {
            [array addObject:model];
        }
    }
    self.signResponse.result = array;
}

- (void) myUpdateViewConstraints {
    // 布局tableView与父视图的位置
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:70];
    
    [self.btmView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.btmView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [self.btmView autoSetDimension:ALDimensionHeight toSize:70];
    [self.btmView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.tableView withOffset:0];
}

#pragma mark -- getter

- (bottomView *) btmView {
    if (!_btmView) {
        _btmView = [bottomView newAutoLayoutView];
        _btmView.hidden = YES;
        @weakify(self);
        [[_btmView.leftButton addAction] subscribeNext:^(id x) {
            @strongify(self);
             [JXLogManager WriteLog:@"发送"  logLevel:@2];
            [self sendWithProcessingType:JXProcessTypeSend];
        }];
        [[_btmView.rightButton addAction] subscribeNext:^(id x) {
            @strongify(self);
             [JXLogManager WriteLog:@"回退"  logLevel:@2];
            [self sendWithProcessingType:JXProcessTypeBack];
        }];
    }
    return _btmView;
}

- (InputDetailTableViewCellItem *)inputItem
{
    if (!_inputItem) {
        _inputItem = [[InputDetailTableViewCellItem alloc]init];
        _inputItem.cellHeight = 150;
    }
    return _inputItem;
}

- (UINavigationController *)navigationController
{
    return self.nav;
}

@end
