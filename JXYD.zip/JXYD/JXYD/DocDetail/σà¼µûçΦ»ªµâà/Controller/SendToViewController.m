//
//  SendToViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "SendToViewController.h"
#import "JXSendBottomView.h"
#import "JXSendHeaderView.h"
#import "JXSendTableViewCellItem.h"
#import "JXSendTableViewCell.h"
#import "JXSendResponse.h"
@interface SendToViewController ()
@property (nonatomic,strong) UITableView *tableView;
@property (strong, readwrite, nonatomic) RETableViewManager *manager;
@property (nonatomic,strong) JXSendBottomView *btmView;
@property (nonatomic,strong) JXSendHeaderView *sectionHeaderView;
@property (nonatomic,strong) JXSendResponse *response;
@property (nonatomic,strong) JXSendTableViewCellItem *selectedItem;
@property (nonatomic,strong) NSString *nameID;
@property (nonatomic,strong) NSMutableArray *mutipleSelectedIDArray;
@property (nonatomic,strong) NSString *remark;
@end

@implementation SendToViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.mutipleSelectedIDArray = [NSMutableArray array];
    if (self.processType == JXProcessTypeSend) {
        self.title = @"发送至";
    }else{
        self.title = @"回退至";
    }
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.btmView];
    [self requestData];
}
- (void)setTitle{
    NSString *appendStr;
    if (self.multiSelected) {
        appendStr = @"(多选)";
    }else{
        appendStr = @"(单选)";
    }
    self.title = [self.title stringByAppendingString:appendStr];
}

- (void)setMultiSelected:(BOOL)multiSelected
{
    _multiSelected = multiSelected;
    [self setTitle];
}

- (void) requestData {
    [self hideEmptyView];
    NSString *sendType = self.processType == JXProcessTypeSend?@"send":@"sendback";
    NSDictionary *parama =  @{@"type":@"smartplan",
                              @"action":@"sendlist",
                              @"sendtype":sendType,
                              @"project":self.projectID,
                              @"wfWorkItemId":checkNullString(self.wfWorkId)};
    @weakify(self);
    [MBProgressHUD showMessage:@"加载中……" toView:self.view];
    [self postUrl:[JXApiHelper serverAddress] param:parama success:^(NSDictionary *json) {
        @strongify(self);
        [MBProgressHUD hideHUDForView:self.view];
        self.response = [JXSendResponse mj_objectWithKeyValues:json];
        if (!self.response.result.count) {
            [self showEmptyView];
        }
        self.multiSelected = [self.response.IsMultiselected boolValue];
        [self configTableView];
    } failed:^{
        [MBProgressHUD hideHUDForView:self.view];
        NSLog(@"****发送、回退请求失败！");
    }];
}

- (void) configTableView {
    self.manager= [[RETableViewManager alloc] initWithTableView:self.tableView];
    self.manager.delegate = self;
    self.manager[@"JXSendTableViewCellItem"] = @"JXSendTableViewCell";
    //添加section
    for (JXSendModel *model in self.response.result) {
        RETableViewSection *section = [RETableViewSection section];
        JXSendHeaderView *sectionHeaderView = [[JXSendHeaderView alloc] init];
        sectionHeaderView.leftDownLabel.text = model.activityName;
        [section setHeaderView:sectionHeaderView];
        section.headerHeight = 45.0f;
        [self.manager addSection:section];
        for (JXUsersModel *userModel in model.users) {
            JXSendTableViewCellItem *item = [[JXSendTableViewCellItem alloc] initWithModel:userModel];
            
            RACChannelTo(userModel,selected) = RACChannelTo(item,isSelectedCell);
            @weakify(self);
            [item setSelectionHandler:^(JXSendTableViewCellItem *item){
                @strongify(self);
                [item deselectRowAnimated:YES];
                
                if (!self.multiSelected) {
                    //set selected
                    if (self.selectedItem) {
                        self.selectedItem.isSelectedCell = NO;
                    }
                    self.selectedItem = item;
                    userModel.selected = YES;
                    self.nameID = userModel.userId;
                }else{
                    userModel.selected = !userModel.selected;
                    if (userModel.selected) {
                        [self.mutipleSelectedIDArray addObject:userModel.userId];
                    }else{
                        [self.mutipleSelectedIDArray removeObject:userModel.userId];
                    }
                }
                
                //set button enable
                [self.btmView.button setEnabled:YES];
                //set activityID
                
                self.activityID = model.activityID;
            }];
            //选中后触发事件
            [section addItem:item];
        }
    }
    [self.tableView reloadData];
}

- (JXSendHeaderView *)sectionHeaderView
{
    if (!_sectionHeaderView) {
        _sectionHeaderView = [[JXSendHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
        _sectionHeaderView.backgroundColor = [UIColor colorWithRed:0.9373 green:0.9333 blue:0.9569 alpha:1.0f];
    }
    return _sectionHeaderView;
}

- (JXSendBottomView *) btmView {
    if (!_btmView) {
        _btmView = [JXSendBottomView newAutoLayoutView];
        _btmView.backgroundColor = [UIColor whiteColor];
        @weakify(self);
        [[_btmView.button addAction] subscribeNext:^(id x) {
            @strongify(self);
            [self addRemark];
        }];
    }
    return _btmView;
}

//添加备注
- (void)addRemark
{
    NSString *saveText = self.processType == JXProcessTypeSend?@"发送":@"回退";
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"请输入备注" message:nil delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:saveText, nil];
    [alertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [[alertView textFieldAtIndex:0] setPlaceholder:@"请输入备注"];
    onMainThread(
                 [alertView show];
                 )
    @weakify(self);
    [[alertView rac_buttonClickedSignal] subscribeNext:^(id x) {
        @strongify(self);
        if ([x integerValue] == 1) {//保存
            NSString *text = [[alertView textFieldAtIndex:0] text];
            self.remark = text;
            if (self.processType == JXProcessTypeBack && !text.length) {
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"备注不可为空！" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                [alertView show];
                [[alertView rac_buttonClickedSignal] subscribeNext:^(id x) {
                    @strongify(self);
                    [self addRemark];
                }];
            }else{
                [self requestSendData];
            }
        }
    }];
}


/** @周金满
 opt:回退意见的值，发送可以不传
 yj：发送意见的值，回退可以不传
 isYJempty：如果发送的时候签名值拿不到 这儿就穿空：“true”
 发送回退 都要的
 type
 action
 sendType
 project
 fromUser
 wfWorkItemId
 activityID
 toUser
 
 发送
 isYJempty
 table
 fildName
 yj
 userfield
 username ／／自己的
 datefield
 
 回退
 opt
 */
- (NSString *)getToUser
{
    if (!self.multiSelected) {
        return self.nameID;
    }
    return [self.mutipleSelectedIDArray componentsJoinedByString:@","];
}

- (void) requestSendData {
    
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"wfWorkItemId":checkNullString(self.wfWorkId),
                                                                               @"type":@"smartplan",
                                                                               @"action":@"signandsend",
                                                                               @"project":self.projectID,
                                                                               @"fromUser":[MainModel sharedInstances].userID,
                                                                               @"toUser":[self getToUser],
                                                                               @"activityID":self.activityID,
                                                                                @"remark":self.remark
                                                                               }];
    //设置发送参数
    if (self.processType == JXProcessTypeSend) {
        [params addEntriesFromDictionary:@{@"sendtype":@"send",
                                           @"username":[MainModel sharedInstances].user,
                                           @"yj":self.opinion,
                                           @"table":checkNullString(self.userTable),
                                           @"fildName":checkNullString(self.fildName),
                                           @"userfield":checkNullString(self.userfield),
                                           @"datefield":checkNullString(self.datefield)
                                           }];
        if (self.fildName.length) {
            [params setObject:@"false" forKey:@"isYJempty"];
        }else{//签名为空
            [params setObject:@"true" forKey:@"isYJempty"];
        }
    }else{
        //设置回退参数
        [params addEntriesFromDictionary:@{@"sendtype":@"sendback",
                                           @"opt":self.opinion}];
        
    }
    @weakify(self);
    [MBProgressHUD showMessage:@"提交中……" toView:self.view];
    [self postUrl:[JXApiHelper serverAddress] param:params success:^(NSDictionary *json) {
        @strongify(self);
        [MBProgressHUD hideHUDForView:self.view animated:NO];
        if ([[json objectForKey:@"success"] boolValue]) {
            UINavigationController *nav = self.navigationController;
            [nav popViewControllerAnimated:NO];
            [nav popViewControllerAnimated:YES];
            [[NSNotificationCenter defaultCenter]postNotificationName:SendSuccessNotification object:nil];
        }else{
            [MBProgressHUD showError:@"提交失败" toView:self.view];
        }
    } failed:^{
        [MBProgressHUD hideHUDForView:self.view];
        NSLog(@"******************************************点击完成发送失败！！");
    }];
    
}

- (UITableView *) tableView {
    if (!_tableView) {
        _tableView = [UITableView newAutoLayoutView];
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    return _tableView;
}

- (void) myUpdateViewConstraints {
    [super myUpdateViewConstraints];
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
    [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:70];
    
    [self.btmView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.btmView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [self.btmView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    [self.btmView autoSetDimension:ALDimensionHeight toSize:70];
}

@end
