//
//  SendToViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger,JXProcessType) {
    JXProcessTypeSend,
    JXProcessTypeBack
};
@interface SendToViewController : SHNetWorkViewController<RETableViewManagerDelegate>
@property (nonatomic,assign) JXProcessType processType;
@property (nonatomic,strong) NSString *wfWorkId;
@property (nonatomic,strong) NSString *projectID;
@property (nonatomic,strong) NSString *activityID;

//签名参数
@property (nonatomic,strong) NSString *datefield;
@property (nonatomic,strong) NSString *userfield;
@property (nonatomic,strong) NSString *userTable;
@property (nonatomic,strong) NSString *fildName;

//意见
@property (nonatomic,strong) NSString *opinion;
@property (nonatomic,assign) BOOL multiSelected;


@end
