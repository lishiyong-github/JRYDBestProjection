//
//  DocDetailViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTableViewController.h"
#import "JXApprovalListReponse.h"
#import "InputDetailTableViewCellItem.h"
#import "bottomView.h"
@interface DocDetailViewController : JXTableViewController
@property (nonatomic,strong) NSString *projectId;
@property (nonatomic,strong) id<JXProjectProtocol> model;
@property (nonatomic,strong) UINavigationController *nav;
@property (nonatomic,strong) NSString *type;//0-在办 1-已办 2-收文 3-发文 4阅文

@property (nonatomic,strong) dispatch_group_t group;

//view
@property (nonatomic,strong) InputDetailTableViewCellItem *inputItem;
@property (nonatomic,strong) bottomView         *btmView;
- (NSArray *)getOpinionCellItems;
@end
