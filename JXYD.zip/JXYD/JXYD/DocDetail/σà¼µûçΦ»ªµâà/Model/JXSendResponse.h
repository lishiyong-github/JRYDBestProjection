//
//  JXSendResponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXResponse.h"

@interface JXSendResponse : JXResponse
@property (nonatomic,strong) NSArray *result;
@property (nonatomic,strong) NSString *IsMultiselected;
@end

@interface JXSendModel : NSObject
@property (nonatomic,strong) NSString *activityID;
@property (nonatomic,strong) NSString *activityName;
@property (nonatomic,strong) NSArray *users;

@end

@interface JXUsersModel : NSObject
@property (nonatomic,strong) NSString *autoChoose;
@property (nonatomic,strong) NSString *isHight;
@property (nonatomic,strong) NSString *userId;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,assign) BOOL selected;

@end

