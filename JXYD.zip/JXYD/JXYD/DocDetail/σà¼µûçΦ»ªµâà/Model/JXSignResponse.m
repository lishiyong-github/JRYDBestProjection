//
//  JXSignResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSignResponse.h"

@implementation JXSignResponse
+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"result":@"JXSignModel"};
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.open = YES;
    }
    return self;
}
@end
