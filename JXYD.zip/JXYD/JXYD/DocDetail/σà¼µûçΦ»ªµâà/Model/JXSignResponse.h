//
//  JXSignResponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXResponse.h"
#import "JXSignModel.h"
@interface JXSignResponse : JXResponse
@property (nonatomic,strong) NSMutableArray *result;
@property (nonatomic,assign) BOOL open;
@end

