//
//  JXSendResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSendResponse.h"

@implementation JXSendResponse
+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"result":@"JXSendModel"};
}
@end

@implementation JXSendModel
+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"users":@"JXUsersModel"};
}
@end

@implementation JXUsersModel
- (BOOL)selected
{
    if ([_autoChoose boolValue]) {
        _autoChoose = @"0";
        _selected = YES;
    }
    return _selected;
}
@end





