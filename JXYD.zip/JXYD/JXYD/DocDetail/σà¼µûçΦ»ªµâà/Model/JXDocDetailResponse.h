//
//  JXDocDetailResponse.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXResponse.h"

@interface JXDocDetailResponse : JXResponse
@property (nonatomic,strong) NSString *buildAddress;
@property (nonatomic,strong) NSString *buildArea;
@property (nonatomic,strong) NSString *businessName;
@property (nonatomic,strong) NSString *prjState;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *projectName;
@property (nonatomic,strong) NSString *projectNo;
@property (nonatomic,strong) NSString *registerTime;
@property (nonatomic,strong) NSString *totalSerialNo;
@property (nonatomic,strong) NSString *wfProcessInstanceId;
@property (nonatomic,strong) NSString *id;
@property (nonatomic,strong) NSString *constructOrg;
@property (nonatomic,strong) NSString *businessId;

@property (nonatomic,assign) BOOL isStartActivity;//是否显示回退

//181
@property (nonatomic,strong) NSString *sqks;//申请科室
@property (nonatomic,strong) NSString *sqksjbr;//申请科室经办人

@end


