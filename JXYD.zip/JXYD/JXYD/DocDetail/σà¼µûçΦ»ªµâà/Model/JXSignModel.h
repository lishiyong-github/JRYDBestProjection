//
//  JXSignModel.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <Foundation/Foundation.h>
@class JXTableModel;
@interface JXSignModel : NSObject
@property (nonatomic,strong) NSString *dateField;
@property (nonatomic,strong) NSString *textField;
@property (nonatomic,strong) NSString *userField;
@property (nonatomic,strong) NSString *userTable;


//add lishy
@property (nonatomic,strong) NSString *activityName;
@property (nonatomic,assign) BOOL isCurrent;
@property (nonatomic,strong) JXTableModel *text;
@property (nonatomic,strong) JXTableModel *date;
@property (nonatomic,strong) JXTableModel *user;


@end

@interface JXTableModel : NSObject;
@property (nonatomic,strong) NSString *table;
@property (nonatomic,strong) NSString *field;
@property (nonatomic,strong) NSString *value;
@end

