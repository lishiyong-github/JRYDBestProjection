//
//  JXSignModel.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/14.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSignModel.h"

@implementation JXSignModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"dateField":@"date.field",
             @"textField":@"text.field",
             @"userField":@"user.field",
             @"userTable":@"user.table"};
}
@end

@implementation JXTableModel



@end

