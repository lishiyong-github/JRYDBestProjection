//
//  JXDocDetailResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXDocDetailResponse.h"

@implementation JXDocDetailResponse



@end
