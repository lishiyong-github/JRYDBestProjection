//
//  DocDetailTablevViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DocDetailTablevViewCell.h"
#import "UIView+Line.h"
@implementation DocDetailTablevViewCell
@dynamic item;
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addSubview:self.rightLable];
        [self.contentView addBottomLine];
    }
    return self;
}

- (void) cellWillAppear {
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.leftLabel.text = self.item.leftText;
    self.rightLable.text = self.item.rightText;
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
        [_leftLabel setFont:[UIFont systemFontOfSize:15]];
    }
    return _leftLabel;
}

- (UILabel *) rightLable {
    if (!_rightLable) {
        _rightLable = [UILabel newAutoLayoutView];
        [_rightLable setFont:[UIFont systemFontOfSize:13]];
        [_rightLable setTextColor:[UIColor grayColor]];
        [_rightLable setTextAlignment:NSTextAlignmentLeft];
        [_rightLable setNumberOfLines:0];
    }
    return _rightLable;
}

- (void) myUpdateViewConstraints {
    //布局与父视图的位置
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.leftLabel autoSetDimension:ALDimensionWidth toSize:130];
//    [self.leftLabel autoPinEdge:ALEdgeRight toEdge:ALEdgeLeft ofView:self.rightLable withOffset:10];
   
   
    [self.rightLable autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.rightLable autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.rightLable autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftLabel withOffset:10];
    [NSLayoutConstraint autoSetPriority:UILayoutPriorityRequired forConstraints:^{
        [self.leftLabel autoSetContentCompressionResistancePriorityForAxis:ALAxisHorizontal];
    }];
}

@end
