//
//  bottomView.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/29.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "bottomView.h"
#import "UIButton+Style.h"
#import "SendToViewController.h"
@implementation bottomView

- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.leftButton];
        [self addSubview:self.rightButton];
    }
    return self;
}

- (UIButton *) leftButton {
    if (!_leftButton) {
        _leftButton = [UIButton newAutoLayoutView];
        _leftButton.backgroundColor = [UIColor colorWithRed:0.0/255 green:146.0/255 blue:243.0/255 alpha:1.0f];
        [_leftButton setTitle:@"发送" forState:UIControlStateNormal];
        _leftButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [_leftButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    return _leftButton;
}

- (UIButton *) rightButton {
    if (!_rightButton) {
        _rightButton = [UIButton newAutoLayoutView];
//        _rightButton.backgroundColor = [UIColor colorWithRed:0.0/255 green:146.0/255 blue:243.0/255 alpha:1.0f];
        _rightButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [_rightButton setTitle:@"回退" forState:UIControlStateNormal];
        [_rightButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_rightButton setBackgroundImage:[UIImage imageWithColor:[UIColor lightGrayColor]] forState:UIControlStateDisabled];
         [_rightButton setBackgroundImage:[UIImage imageWithColor:[UIColor blueColor]] forState:UIControlStateNormal];
    }
    return _rightButton;
}

- (void) myUpdateViewConstraints {
    [self.leftButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:30];
    [self.leftButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:20];
    [self.leftButton autoSetDimension:ALDimensionHeight toSize:40];
    
    [self.rightButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:30];
    [self.rightButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:20];
    [self.rightButton autoSetDimension:ALDimensionHeight toSize:40];
    [self.rightButton autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftButton withOffset:20];
    [self.rightButton autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.leftButton];
}

@end
