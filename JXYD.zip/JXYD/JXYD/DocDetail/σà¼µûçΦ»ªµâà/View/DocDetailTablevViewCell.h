//
//  DocDetailTablevViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewCell.h"
#import "DocDetailTableViewCellItem.h"
@interface DocDetailTablevViewCell : RETableViewCell
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) UILabel *rightLable;
@property (nonatomic,strong) DocDetailTableViewCellItem *item;
@end
