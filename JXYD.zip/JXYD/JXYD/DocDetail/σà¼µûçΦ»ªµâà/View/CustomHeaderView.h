//
//  CustomHeaderView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/29.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomHeaderView : UIView
@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) UIImageView *rightImageView;
@property (nonatomic,assign) BOOL close;
@property (nonatomic,copy)  void (^clicked)();
@end
