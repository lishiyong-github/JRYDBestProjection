//
//  bottomView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/29.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface bottomView : UIView
@property (nonatomic,strong) UIButton *leftButton;
@property (nonatomic,strong) UIButton *rightButton;

@end
