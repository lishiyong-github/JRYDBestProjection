//
//  JXSendBottomView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXSendBottomView : UIView
@property (nonatomic,strong) UIButton *button;

@end
