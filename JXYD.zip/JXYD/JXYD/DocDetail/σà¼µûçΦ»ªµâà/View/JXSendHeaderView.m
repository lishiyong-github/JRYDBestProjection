//
//  JXSendHeaderView.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSendHeaderView.h"

@implementation JXSendHeaderView
- (instancetype) initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.leftDownLabel];
        self.backgroundColor = [UIColor headerColor];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (UILabel *) leftDownLabel {
    if (!_leftDownLabel) {
        _leftDownLabel = [UILabel newAutoLayoutView];
        [_leftDownLabel setTextColor:[UIColor blackColor]];
        [_leftDownLabel setFont:[UIFont systemFontOfSize:15]];
    }
    return _leftDownLabel;
}

- (void) myUpdateViewConstraints {
    //布局
    [self.leftDownLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftDownLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
}

@end
