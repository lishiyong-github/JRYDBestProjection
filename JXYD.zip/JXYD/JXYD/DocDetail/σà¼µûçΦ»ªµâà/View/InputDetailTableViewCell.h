//
//  InputDetailTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewCell.h"
#import "InputDetailTableViewCellItem.h"
#import "MBPlaceholderTextView.h"

@interface InputDetailTableViewCell : RETableViewCell<UITextViewDelegate>
@property (nonatomic,strong) MBPlaceholderTextView *textView;
@property (nonatomic,strong) InputDetailTableViewCellItem *item;
@end
