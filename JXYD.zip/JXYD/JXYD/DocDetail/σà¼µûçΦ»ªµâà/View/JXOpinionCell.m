//
//  JXOpinionCell.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXOpinionCell.h"
#import "UIView+Line.h"
@interface JXOpinionCell ()
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UILabel *contentLabel;
@property (nonatomic,strong) UILabel *userNameLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@end

@implementation JXOpinionCell
@dynamic item;

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.contentLabel];
        [self.contentView addSubview:self.userNameLabel];
        [self.contentView addSubview:self.timeLabel];
        [self.contentView addBottomLine];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void)cellWillAppear
{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self.titleLabel setText:self.item.title];
    [self.contentLabel setText:self.item.content];
    [self.userNameLabel setText:self.item.userName];
    [self.timeLabel setText:self.item.time];
}

- (void)myUpdateViewConstraints
{
    [self.titleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.titleLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
    
    [self.contentLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.contentLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.titleLabel withOffset:8];
    [self.contentLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.userNameLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
    [self.timeLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
    [self.timeLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.timeLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.userNameLabel withOffset:20];
}

#pragma mark - getter
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [UILabel newAutoLayoutView];
        [_titleLabel setTextColor:[UIColor blackColor]];
    }
    return _titleLabel;
}

- (UILabel *)contentLabel
{
    if (!_contentLabel) {
        _contentLabel = [UILabel newAutoLayoutView];
        _contentLabel.numberOfLines = 0;
        [_contentLabel setTextColor:[UIColor grayColor]];
    }
    return _contentLabel;
}

- (UILabel *)userNameLabel
{
    if (!_userNameLabel) {
        _userNameLabel = [UILabel newAutoLayoutView];
        [_userNameLabel setTextColor:[UIColor grayColor]];
    }
    return _userNameLabel;
}

- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [UILabel newAutoLayoutView];
        [_timeLabel setTextColor:[UIColor grayColor]];
    }
    return _timeLabel;
}
@end
