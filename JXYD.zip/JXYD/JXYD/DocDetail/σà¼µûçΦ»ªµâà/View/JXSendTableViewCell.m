//
//  JXSendTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSendTableViewCell.h"
#import "UIView+Line.h"
@implementation JXSendTableViewCell
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addBottomLine];
        [self.contentView addSubview:self.rightButton];

        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (UIButton *) rightButton {
    if (!_rightButton) {
        _rightButton = [UIButton newAutoLayoutView];
        _rightButton.userInteractionEnabled = NO;
        [_rightButton setBackgroundImage:[UIImage imageNamed:@"send_choices"] forState:UIControlStateSelected];
    }
    return _rightButton;
}

- (void) cellWillAppear {
    self.leftLabel.text = self.item.leftText;
    [self.rightButton setBackgroundImage:[UIImage imageNamed:self.item.rightImage] forState:UIControlStateNormal];
    
    self.rightButton.selected = self.item.isAutoChoose;
    @weakify(self);
    [[RACObserve(self.item, isSelectedCell) takeUntil:[self rac_prepareForReuseSignal]] subscribeNext:^(id x) {
        @strongify(self);
        self.rightButton.selected = [x boolValue];
    }];
    if (self.item.isHight) {
        [self.leftLabel setTextColor:[UIColor blueColor]];
    }else{
        [self.leftLabel setTextColor:[UIColor blackColor]];
    }
//    RACChannelTo(self.rightButton,selected) = RACChannelTo(self.item,isSelectedCell);
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
    }
    return _leftLabel;
}

- (void) myUpdateViewConstraints {
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:40];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5];
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];
    
    [self.rightButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.rightButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:15];
    [self.rightButton autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:15];
    [self.rightButton autoSetDimension:ALDimensionWidth toSize:20];
    
}

@end
