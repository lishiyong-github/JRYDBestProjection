//
//  JXOpinionCell.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <RETableViewManager-Simple/RETableViewManager-Simple.h>
#import "JXOpinionCellItem.h"
@interface JXOpinionCell : RETableViewCell
@property (nonatomic,strong) JXOpinionCellItem *item;
@end
