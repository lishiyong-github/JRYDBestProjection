//
//  JXSendHeaderView.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JXSendHeaderView : UIView
@property (nonatomic,strong) UILabel *leftDownLabel;
@property (nonatomic,strong) UIButton *rightButton;
@end
