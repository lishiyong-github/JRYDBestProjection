//
//  InputDetailTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "InputDetailTableViewCell.h"

@implementation InputDetailTableViewCell

- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.textView];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void) cellWillAppear {
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.textView.text = self.item.inputText;
}

- (MBPlaceholderTextView *) textView {
    if (!_textView) {
        _textView = [MBPlaceholderTextView newAutoLayoutView];
        _textView.layer.cornerRadius = 4.0f;
        _textView.layer.borderWidth = 1.0f;
        _textView.layer.borderColor = [[[UIColor grayColor] colorWithAlphaComponent:0.3] CGColor];
        _textView.delegate = self;
        _textView.placeholder = @"请输入您的意见";
        [_textView setFont:[UIFont systemFontOfSize:13]];
    }
    return _textView;
}

- (void) textViewDidEndEditing:(UITextView *)textView {
    self.item.inputText = textView.text;
}

- (void) myUpdateViewConstraints {
    [self.textView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.textView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.textView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:15];
    [self.textView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:15];
}


@end
