//
//  MBPlaceholderTextView.h
//  nbOneMap
//
//  Created by shiyong_li on 17/3/28.
//  Copyright © 2017年 dist. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MBPlaceholderTextView : UITextView

@property(nonatomic,copy)NSString * placeholder;
@property(nonatomic,strong)UIColor * placeholderColor;


@end
