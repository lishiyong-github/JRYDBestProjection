//
//  JXSendBottomView.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/11.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSendBottomView.h"
#import "UIButton+Style.h"
@implementation JXSendBottomView
- (instancetype) initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.button];
    }
    return self;
}

- (UIButton *) button {
    if (!_button) {
        _button = [UIButton newAutoLayoutView];
        [_button setTitle:@"完成" forState:UIControlStateNormal];
        _button.titleLabel.font = [UIFont systemFontOfSize:17];
        [_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_button setBackgroundImage:[UIImage imageWithColor:BLUECOLOR] forState:UIControlStateNormal];
        [_button setBackgroundImage:[UIImage imageWithColor:[UIColor grayColor]] forState:UIControlStateDisabled];
        _button.enabled = NO;
        _button.layer.cornerRadius = 5;
        _button.layer.masksToBounds = YES;
    }
    return _button;
}

- (void) myUpdateViewConstraints {
    [self.button autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:100];
    [self.button autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:100];
    [self.button autoSetDimension:ALDimensionHeight toSize:40];
    [self.button autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    
}


@end
