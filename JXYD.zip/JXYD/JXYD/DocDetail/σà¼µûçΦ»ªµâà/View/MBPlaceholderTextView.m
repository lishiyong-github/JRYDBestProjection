//
//  MBPlaceholderTextView.m
//  nbOneMap
//
//  Created by shiyong_li on 17/3/28.
//  Copyright © 2017年 dist. All rights reserved.
//

#import "MBPlaceholderTextView.h"

@implementation MBPlaceholderTextView

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textChange) name:UITextViewTextDidChangeNotification object:self];
    }
    
    return self;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textChange) name:UITextViewTextDidChangeNotification object:self];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)textChange{
    
    [self setNeedsDisplay];
    
}

-(void)setPlaceholderColor:(UIColor *)placeholderColor{
    _placeholderColor = placeholderColor;
    
    [self setNeedsDisplay];
}

-(void)setPlaceholder:(NSString *)placeholder{
    _placeholder = [placeholder copy];
    
    [self setNeedsDisplay];
    
}

-(void)setFont:(UIFont *)font{
    
    [super setFont:font];
    
    [self setNeedsDisplay];
    
}

-(void)setText:(NSString *)text{
    [super setText:text];
    
    [self setNeedsDisplay]; //会在下一个消息循环 调用drawRect
}

-(void)drawRect:(CGRect)rect{
    if (self.hasText) {
        return;
    }
    
    NSMutableDictionary * attributes = [NSMutableDictionary dictionary];
    attributes[NSFontAttributeName] = self.font;
    attributes[NSForegroundColorAttributeName] = self.placeholderColor ? self.placeholderColor : [UIColor lightGrayColor];
    
    CGFloat  x = 5;
    CGFloat  y = 8;
    CGFloat width = rect.size.width - 2*x;
    CGFloat heigth = rect.size.height - 2*y;
    CGRect placeholderRect = CGRectMake(x, y, width, heigth);
    [self.placeholder drawInRect:placeholderRect withAttributes:attributes];
}

@end
