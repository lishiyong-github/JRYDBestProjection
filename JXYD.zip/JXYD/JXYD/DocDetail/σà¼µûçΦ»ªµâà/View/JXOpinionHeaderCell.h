//
//  JXOpinionHeaderCell.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DocDetailTablevViewCell.h"
#import "JXOpinionHeaderCellItem.h"
@interface JXOpinionHeaderCell : DocDetailTablevViewCell
@property (nonatomic,strong) UIImageView *openImageView;
@property (nonatomic,strong) JXOpinionHeaderCellItem *item;
@end
