//
//  JXOpinionHeaderCell.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXOpinionHeaderCell.h"

@implementation JXOpinionHeaderCell
@dynamic item;

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.openImageView];
    }
    return self;
}

- (void)myUpdateViewConstraints
{
    [super myUpdateViewConstraints];
    [self.openImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.openImageView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.openImageView autoSetDimensionsToSize:CGSizeMake(30, 30)];
    
    [NSLayoutConstraint autoSetPriority:UILayoutPriorityRequired forConstraints:^{
        [self.leftLabel autoSetContentHuggingPriorityForAxis:ALAxisHorizontal];
    }];
}

- (void)cellWillAppear
{
    [super cellWillAppear];
    [self.openImageView setImage:[UIImage imageNamed:self.item.imageName]];
}

- (UIImageView *)openImageView
{
    if (!_openImageView) {
        _openImageView = [UIImageView newAutoLayoutView];
    }
    return _openImageView;
}

@end
