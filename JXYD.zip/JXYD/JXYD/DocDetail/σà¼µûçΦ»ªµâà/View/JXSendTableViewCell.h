//
//  JXSendTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/9/12.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXSendTableViewCellItem.h"
@interface JXSendTableViewCell : RETableViewCell
@property (nonatomic,strong) UILabel  *leftLabel;
@property (nonatomic,strong) UIButton *rightButton;
@property (nonatomic,strong) JXSendTableViewCellItem *item;
@end
