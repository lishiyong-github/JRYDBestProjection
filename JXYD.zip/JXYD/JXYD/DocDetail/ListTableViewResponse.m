//
//  ListTableViewResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "ListTableViewResponse.h"

@implementation ListTableViewResponse
+(NSDictionary *) mj_objectClassInArray {
    return @{@"result":@"ListModel"};
}
@end

@implementation ListModel

@end
