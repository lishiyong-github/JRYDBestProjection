//
//  JXModifyButtonCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXModifyButtonCellItem.h"

@implementation JXModifyButtonCellItem
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.cellHeight = 140;
    }
    return self;
}
@end
