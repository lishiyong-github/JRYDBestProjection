//
//  MoreViewController.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTableViewController.h"

@interface MoreViewController : JXTableViewController

@end
