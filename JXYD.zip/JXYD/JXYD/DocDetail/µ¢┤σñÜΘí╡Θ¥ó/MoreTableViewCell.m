//
//  MoreTableViewCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "MoreTableViewCell.h"
#import "UIView+Line.h"
@implementation MoreTableViewCell
@dynamic item;
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftImageView];
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addSubview:self.rightImageView];
        
        //添加底部线
        [self.contentView addBottomLine];
    }
    return self;
}

- (UIImageView *) leftImageView {
    if (!_leftImageView) {
        _leftImageView = [UIImageView newAutoLayoutView];
    }
    return _leftImageView;
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
        [_leftLabel setFont:[UIFont systemFontOfSize:15]];
        [_leftLabel setTextColor:[UIColor grayColor]];
    }
    return _leftLabel;
}

- (UIImageView *) rightImageView {
    if (!_rightImageView) {
        _rightImageView = [UIImageView newAutoLayoutView];
    }
    return _rightImageView;
}

- (void) cellWillAppear {
    self.leftImageView.image = [UIImage imageNamed:self.item.leftImage];
    self.leftLabel.text = self.item.leftTitle;
    self.rightImageView.image = [UIImage imageNamed:self.item.rightImage];
}

- (void) myUpdateViewConstraints {
    //布局视图
    [self.leftImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftImageView autoSetDimensionsToSize:CGSizeMake(26, 26)];
    [self.leftImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];

    //布局leftLabel与父视图的位置
    [self.leftLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftImageView withOffset:5];
    [self.leftLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];

    //布局rightImageView与父视图的位置
    [self.rightImageView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:15];
    [self.rightImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.rightImageView autoSetDimensionsToSize:CGSizeMake(15, 15)];
    
}

@end
