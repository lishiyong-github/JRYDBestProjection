//
//  JXCorrectPassword.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXCorrectPasswordController.h"
#import <RETableViewManager.h>
#import "JXCorrectPasswordCell.h"
#import "JXCorrectPasswordCellItem.h"
#import "JXModifyButtonCell.h"
#import "JXModifyButtonCellItem.h"
#import "JXTabBarController.h"
#import "MainModel.h"
#import "MessageLabel.h"
@interface JXCorrectPasswordController ()
@property (nonatomic,strong) NSArray *dataArray;
@property (nonatomic,strong) NSArray *inputArray;
@property (nonatomic,strong) JXCorrectPasswordCellItem *item1;
@property (nonatomic,strong) JXCorrectPasswordCellItem *item2;
@property (nonatomic,strong) JXCorrectPasswordCellItem *item3;
@property (nonatomic,strong) JXModifyButtonCellItem *item4;
@end

@implementation JXCorrectPasswordController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArray = @[@"当前登录密码",@"新密码",@"确认密码"];
    self.inputArray = @[@"请输入原始密码",@"请设置新密码",@"请再次输入"];
    self.title = @"修改密码";
    
    //注册cell、item
    self.manager[@"JXCorrectPasswordCellItem"] = @"JXCorrectPasswordCell";
    
    self.manager[@"JXModifyButtonCellItem"]  = @"JXModifyButtonCell";
    
    //创建manager
    [self addManager];
}

- (void) addManager {
    RETableViewSection *section = [RETableViewSection section];
    [self.manager addSection:section];
    
    //创建item
    JXCorrectPasswordCellItem *item1 = [[JXCorrectPasswordCellItem alloc] init];
    item1.leftText                   = @"当前登录密码";
    item1.leftSpace                  = 120.0f;
    self.item1 = item1;
    [section addItem:self.item1];
    
    JXCorrectPasswordCellItem *item2 = [[JXCorrectPasswordCellItem alloc] init];
    item2.warningText = @"新密码应当原密码不一致!";
    item2.leftText                   = @"新密码";
    item2.leftSpace                  = 120.0f;
    self.item2                       = item2;
    [section addItem:self.item2];
    
    JXCorrectPasswordCellItem *item3 = [[JXCorrectPasswordCellItem alloc] init];
    item3.warningText = @"新密码不一致!";
    item3.leftText                   = @"确认密码";
    item3.leftSpace                  = 120.0f;
    self.item3                       = item3;
    [section addItem:self.item3];

    JXModifyButtonCellItem *item4    = [[JXModifyButtonCellItem alloc] init];
    @weakify(self);
    item4.clicked = ^{
        @strongify(self);
        [self.view endEditing:YES];
        [self loginWithCurrentPassWord:item1.inputText withNewPassWord:item2.inputText withEnsurePassWord:item3.inputText];
    };
    self.item4                      = item4;
    [section addItem:self.item4];
    
    [[RACSignal combineLatest:@[RACObserve(item1,inputText),RACObserve(item2,inputText),RACObserve(item3,inputText)] reduce:^id(NSString *text1,NSString *text2,NSString *text3){
        if ([text1 isEqualToString:text2]) {
            item2.showWarningText = YES;
            return @0;
        }else{
            item2.showWarningText = NO;
        }
        if (![text2 isEqualToString:text3] && text2.length && text3.length) {
            item3.showWarningText = YES;
            return @0;
        }else{
            item3.showWarningText = NO;
        }
        if (!text1.length || !text2.length || !text3.length) {
            return @0;
        }
        return @1;
    }]subscribeNext:^(id x) {
        BOOL enable = [x boolValue];
        item4.enabled = enable;
    }];;
}

- (void) loginWithCurrentPassWord:(NSString *) value1  withNewPassWord:(NSString *) value2 withEnsurePassWord:(NSString *) value3{
    NSString *url = [JXApiHelper serverAddress];
    NSDictionary *parama = @{
                             @"type":@"smartplan",
                             @"action":@"modifypwd",
                             @"userID":[MainModel sharedInstances].userID,
                             @"sourPwd":value1,
                             @"newPwd":value2
                             };
    @weakify(self);
    [self postUrl:url param:parama success:^(NSDictionary *json) {
        @strongify(self);
        NSString *message = @"原密码错误";//@"密码修改成功"
        BOOL success = NO;
        if (![json[@"result"] isEqualToString:message]) {
            [[NSUserDefaults standardUserDefaults] setValue:value2 forKey:kPassWord];
            message = @"密码修改成功";
            success = YES;
        }
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:message message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            @strongify(self);
            if (success) {
                [self.navigationController popViewControllerAnimated:YES];
            }
        }];
        [alert addAction:action];
        [self presentViewController:alert animated:YES completion:nil];
    } failed:^{
        NSLog(@"********请求网络失败！");
        
    }];
}
@end
