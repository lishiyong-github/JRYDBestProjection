//
//  MoreTableViewCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "RETableViewCell.h"
#import "MoreTableViewCellItem.h"
@interface MoreTableViewCell : RETableViewCell
@property(nonatomic,strong) UIImageView *leftImageView;
@property(nonatomic,strong) UILabel *leftLabel;
@property(nonatomic,strong) UIImageView *rightImageView;
@property(nonatomic,strong) MoreTableViewCellItem *item;
@end
