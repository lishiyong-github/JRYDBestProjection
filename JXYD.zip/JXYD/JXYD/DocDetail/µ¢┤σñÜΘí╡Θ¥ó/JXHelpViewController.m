//
//  JXHelpViewController.m
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXHelpViewController.h"

@interface JXHelpViewController ()

@end

@implementation JXHelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"帮助";
    // Do any additional setup after loading the view.
}

- (void)configWebView
{
    NSString *path = [[NSBundle mainBundle]pathForResource:@"嘉兴移动办公使用说明手册" ofType:@"doc"];
    NSURL *url = [NSURL fileURLWithPath:path isDirectory:YES];
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
}

@end
