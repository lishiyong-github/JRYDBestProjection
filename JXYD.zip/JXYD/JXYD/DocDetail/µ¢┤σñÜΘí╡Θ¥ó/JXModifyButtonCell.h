//
//  JXModifyButtonCell.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXModifyButtonCellItem.h"
@interface JXModifyButtonCell : RETableViewCell
@property (nonatomic,strong) UIButton *modifyButton;
@property (nonatomic,strong) JXModifyButtonCellItem *item;
@end
