//
//  JXModifyButtonCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

@interface JXModifyButtonCellItem : RETableViewItem

@property (nonatomic,strong) RACSubject *clickSignal;
//@property (nonatomic,assign) BOOL enable;
@property (nonatomic,copy) void (^clicked)();

@end
