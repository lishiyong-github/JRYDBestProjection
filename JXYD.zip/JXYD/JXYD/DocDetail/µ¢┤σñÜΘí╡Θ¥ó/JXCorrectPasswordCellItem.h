//
//  JXCorrectPasswordCellItem.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//



@interface JXCorrectPasswordCellItem : RETableViewItem
@property (nonatomic,strong) NSString *leftText;
@property (nonatomic,strong) NSString *inputText;
@property (nonatomic,assign) CGFloat leftSpace;//左间距

@property (nonatomic,strong) NSString *warningText;
@property (nonatomic,assign) BOOL showWarningText;

- (instancetype)initWithModel:(id) Model;
@end
