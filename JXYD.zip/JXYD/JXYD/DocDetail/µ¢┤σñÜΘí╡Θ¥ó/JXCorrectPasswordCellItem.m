//
//  JXCorrectPasswordCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXCorrectPasswordCellItem.h"

@implementation JXCorrectPasswordCellItem

-(instancetype) initWithModel:(id) Model{
    if (self = [super init]) {
        self.leftSpace = 100;
        
    }
    return self;
}

@end
