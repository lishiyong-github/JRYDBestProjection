//
//  JXCorrectPassword.h
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXTableViewController.h"

@interface JXCorrectPasswordController : JXTableViewController

@end
