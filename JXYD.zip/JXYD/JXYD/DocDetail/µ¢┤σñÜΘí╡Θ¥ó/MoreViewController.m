//
//  MoreViewController.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "MoreViewController.h"
#import "MoreTableViewCell.h"
#import "MoreTableViewCellItem.h"
#import "DocDetailTableViewCellItem.h"
#import "JXCorrectPasswordController.h"
#import "JXLoginViewController.h"
#import "JXHelpViewController.h"
@interface MoreViewController ()
@property (nonatomic,strong) NSMutableArray *dataArray;
@property (nonatomic,strong) NSMutableArray *leftImageArray;
@property (nonatomic,strong) NSString *org;
@property (nonatomic,assign) BOOL needRefresh;
@end

@implementation MoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:[UIColor mainColor]] forBarMetrics:UIBarMetricsDefault];
    
    self.dataArray = [NSMutableArray arrayWithObjects:@"帮助",@"注销",@"修改密码", nil];
    self.leftImageArray = [NSMutableArray arrayWithObjects:@"help",@"logout",@"correct_password", nil];
    self.title = @"更多";
    
    //创建manager、section
    [self configTable];
    
    self.manager[@"MoreTableViewCellItem"] = @"MoreTableViewCell";//一个item对应一个cell
    self.manager[@"DocDetailTableViewCellItem"]     = @"DocDetailTablevViewCell";
    [self requestData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (self.needRefresh) {
        [self requestData];
        self.needRefresh = NO;
    }
}

- (void)requestData
{
    @weakify(self);
    NSDictionary *param = @{@"type":@"smartplan",
                            @"action":@"userinfo",
                            @"id":[MainModel sharedInstances].userID};
    [self postUrl:[JXApiHelper serverAddress] param:param success:^(NSDictionary *json) {
        @strongify(self);
        if ([json[@"success"] boolValue]) {
            self.org = json[@"result"][@"org"];
            [self configTable];
        }
    } failed:^{
        
    }];
}

//- (void) viewWillAppear:(BOOL)animated{
//    [self.tabBarController.tabBar setHidden:NO];
//}

- (void) configTable {
    [self.manager removeAllSections];
    //创建section
    RETableViewSection *userSection = [RETableViewSection section];
    
    [userSection addItemsFromArray:[self getItems]];
    [self.manager addSection:userSection];
    
    RETableViewSection *section = [RETableViewSection section];
    section.headerHeight = 20.0f;
    [self.manager addSection:section];
    
    //注册cell、item
    //创建item
    @weakify(self);
    for (int i=0; i<2; i++) {
        //创建item
        MoreTableViewCellItem *item = [[MoreTableViewCellItem alloc] init];
        item.leftImage =_leftImageArray[i];
        item.leftTitle = [NSString stringWithFormat:@"%@",_dataArray[i]];
        item.rightImage = @"right";
        [section addItem:item];
        
        [item setSelectionHandler:^(MoreTableViewCellItem *item){
            [item deselectRowAnimated:YES];
            @strongify(self);
            if (i== 0) {
                JXHelpViewController *controller = [[JXHelpViewController alloc]init];
                controller.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:controller animated:YES];
            }else if (i==1) {
                self.needRefresh = YES;
                self.tabBarController.selectedIndex = 0;
                [self presentViewController:[[JXLoginViewController alloc] init] animated:YES completion:nil];
            }else if (i==2){
                JXCorrectPasswordController *vc = [[JXCorrectPasswordController alloc] init];
                vc.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:vc animated:YES];
            }
            [JXLogManager WriteLog:item.leftTitle logLevel:@1];
        }];
    }
    [self.tableView reloadData];
}

- (NSArray *)getItems
{
    NSMutableArray *array = [NSMutableArray array];
    if (!self.org.length) {
        return array;
    }
    DocDetailTableViewCellItem *item1 = [DocDetailTableViewCellItem item];
    item1.leftText = [NSString stringWithFormat:@"            %@",[UserDefaults objectForKey:kUserName]];
    item1.rightText = [NSString stringWithFormat:@"%@           ",self.org];
    item1.cellHeight = 100;
    
    [array addObject:item1];
    return array;
}
@end
