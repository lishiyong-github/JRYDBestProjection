//
//  JXHelpViewController.h
//  JXYD
//
//  Created by shiyong_li on 2017/9/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JZWebViewController.h"

@interface JXHelpViewController : JZWebViewController

@end
