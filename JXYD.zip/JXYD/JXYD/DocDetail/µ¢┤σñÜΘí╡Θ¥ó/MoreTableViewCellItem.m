//
//  MoreTableViewCellItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/28.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "MoreTableViewCellItem.h"

@implementation MoreTableViewCellItem
- (instancetype) initWithModel:(id) model{
    if (self = [super init]) {
        
        
    }
    return self;
}

@end
