//
//  JXCorrectPasswordCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXCorrectPasswordCell.h"
#import "UIView+Line.h"

@implementation JXCorrectPasswordCell
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addSubview:self.leftTextField];
        [self.contentView addSubview:self.rightLabel];
        [self.contentView addBottomLine];
        self.leftSpaceConstraints = [self.leftTextField autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:100];
        [self setNeedsUpdateConstraints];
        [[[[self.leftTextField rac_textSignal] distinctUntilChanged] takeUntil:[self rac_prepareForReuseSignal]] subscribeNext:^(id x) {
            self.item.inputText = x;
        }];
    }
    return self;
}

- (UILabel *) leftLabel {
    if (!_leftLabel) {
        _leftLabel = [UILabel newAutoLayoutView];
        [_leftLabel setTextColor:[UIColor blackColor]];
        [_leftLabel setFont:[UIFont systemFontOfSize:15]];
    }
    return _leftLabel;
}

- (UILabel *)rightLabel
{
    if (!_rightLabel) {
        _rightLabel = [UILabel newAutoLayoutView];
        [_rightLabel setTextColor:[UIColor redColor]];
        [_rightLabel setFont:[UIFont systemFontOfSize:15]];
        [_rightLabel setTextAlignment:NSTextAlignmentCenter];
        [_rightLabel setHidden:YES];
    }
    return _rightLabel;
}

- (void) cellWillAppear {
    self.leftLabel.text = self.item.leftText;
    self.leftTextField.text = self.item.inputText;
    self.rightLabel.text = self.item.warningText;
    NSString *placeHolderString = [self.leftLabel.text stringByReplacingOccurrencesOfString:@":" withString:@""];
    self.leftTextField.placeholder = [NSString stringWithFormat:@"请输入%@",placeHolderString];
    self.leftSpaceConstraints.constant = self.item.leftSpace;
    @weakify(self);
    [[RACObserve(self.item, showWarningText) takeUntil:[self rac_prepareForReuseSignal]] subscribeNext:^(id x) {
        @strongify(self);
        [self.rightLabel setHidden:![x boolValue]];
    }];
}

- (UITextField *) leftTextField {
    if (!_leftTextField) {
        _leftTextField = [UITextField newAutoLayoutView];
        [_leftTextField setFont:[UIFont systemFontOfSize:15]];
        [_leftTextField setTextColor:[UIColor blackColor]];
        [_leftTextField setSecureTextEntry:YES];
    }
    return _leftTextField;
}

- (void) myUpdateViewConstraints {
    [self.leftLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.leftLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];

    [self.rightLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftTextField withOffset:10];
    [self.leftTextField autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
    [self.leftTextField autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    
    [self.rightLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.rightLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.rightLabel autoSetDimension:ALDimensionWidth toSize:200];
}

@end
