//
//  JXModifyButtonCell.m
//  JXYD
//
//  Created by Wu Longfei on 2017/8/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXModifyButtonCell.h"
#import "UIButton+Style.h"

@implementation JXModifyButtonCell

- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.modifyButton];
        [self setNeedsUpdateConstraints];
    }
    return self;
}

- (void)cellWillAppear
{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    @weakify(self);
    [[RACObserve(self.item, enabled)takeUntil:[self rac_prepareForReuseSignal]] subscribeNext:^(id x) {
        @strongify(self);
        self.modifyButton.enabled = [x boolValue];
    }];
}

- (UIButton *) modifyButton {
    if (!_modifyButton) {
        _modifyButton = [UIButton newAutoLayoutView];
        [_modifyButton setTitle:@"修改" forState:UIControlStateNormal];
        [_modifyButton setBackgroundImage:[UIImage imageWithColor:[UIColor blueColor]] forState:UIControlStateNormal];
        [_modifyButton setBackgroundImage:[UIImage imageWithColor:[UIColor mainColor]] forState:UIControlStateHighlighted];
        [_modifyButton setBackgroundImage:[UIImage imageWithColor:[UIColor lightGrayColor]] forState:UIControlStateDisabled];
        [_modifyButton.layer setMasksToBounds:YES];
        [_modifyButton.layer setCornerRadius:5];
        @weakify(self);
        [[_modifyButton addAction] subscribeNext:^(id x) {
          @strongify(self);
            self.item.clicked();
        }];
    }
    return _modifyButton;
}

- (void) myUpdateViewConstraints{
    [self.modifyButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:40];
    [self.modifyButton autoCenterInSuperview];
    [self.modifyButton autoSetDimension:ALDimensionHeight toSize:40];
}




@end
