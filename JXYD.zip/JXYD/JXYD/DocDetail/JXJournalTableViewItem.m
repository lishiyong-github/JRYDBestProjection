//
//  JXJournalTableViewItem.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/6.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "JXJournalTableViewItem.h"
#import "JXJournalTableViewResponse.h"
#import "NSString+SizeAddtion.h"
@implementation JXJournalTableViewItem
- (instancetype) initWithModel:(id) Model{
    if (self = [super init]) {
        JXJournalModel *model = Model;
        self.timeText = model.StartTime;
        self.fromText = [NSString stringWithFormat:@"%@(%@)",model.LogName,model.UserName];
        if ([model.Type isEqualToString:@"创建"]) {
            self.toText = model.Type;
        }else{
            self.toText = [NSString stringWithFormat:@"%@：%@",model.Type,model.Remark];
        }
        if (![model.Type isEqualToString:@"回退"] && ![model.Type isEqualToString:@"创建"]) {
            self.remark = [NSString stringWithFormat:@"备注：%@",model.Opinion];
        }
        [self configCellHeight];
    }
    return self;
}

- (instancetype) initWithFirstModel:(id)Model{
    if (self = [super init]) {
        JXJournalModel *model = Model;
        self.timeText = model.StartTime;
        self.fromText = @"开始";
    }
    return self;
}
- (NSString *)time
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *date = [formatter dateFromString:self.timeText];
    [formatter setDateFormat:@"dd日HH:mm"];
    return [formatter stringFromDate:date];
}

//669 -220
- (void)configCellHeight
{
    CGSize size = [self.toText sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(469, MAXFLOAT)];
//    self.cellHeight = MAX(44, size.height+20);
    CGSize size1 = [self.remark sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(150, MAXFLOAT)];
    self.cellHeight = MAX(MAX(44, size.height+20), size1.height+20);
}

@end
