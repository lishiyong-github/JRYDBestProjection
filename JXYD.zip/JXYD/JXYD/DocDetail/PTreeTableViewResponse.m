//
//  PTreeTableViewResponse.m
//  JXYD
//
//  Created by Wu Longfei on 2017/9/5.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "PTreeTableViewResponse.h"

@implementation PTreeTableViewResponse
+(NSDictionary *) mj_objectClassInArray {
    return @{@"result":@"PTreeModel"};
}
@end

@implementation PTreeModel
+(NSDictionary *) mj_objectClassInArray {
    return @{@"items":@"ItemModel"};
}
@end

@implementation ItemModel
@end
